Struktura CD:
1) readme.txt				popis obsahu paměťové karty
3) src
	3A) impl : 	-ompilancz	zdrojové kódy implementace
			-Makefile	makefile
			-readme.txt	popis testovacího programu
			-run.sh		spouštěcí skript
			-test.cpp	testovací C++ soubor s main funkcí
	3B) thesis			zdrojová forma práce ve formátu LATEX
4) text					
	4A) Zadání_DP.pdf		zadání práce ve formátu PDF
	4B) DP_Matej_Razak_2024.pdf	text práce ve formátu PDF
