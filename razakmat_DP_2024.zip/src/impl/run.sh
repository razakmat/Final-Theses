mpirun -np $1 ./test $2
