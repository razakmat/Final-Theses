#ifndef OMPILANCZ_DETAIL_LAPACK_SYMMETRIC_EIGENSOLVER_H
#define OMPILANCZ_DETAIL_LAPACK_SYMMETRIC_EIGENSOLVER_H

#include <algorithm>
#include <cassert>
#include <cmath>
#include <stdexcept>
#include <vector>

#include "lapack_lamch.h"
#include "../span.h"
#include "block_diagonal_vector.h"

// LAPACK routines interface:
extern "C"
{
   extern void ssyevx_(char*, char*, char*, int*, float*, int*, float*,
         float*, int*, int*, float*, int*, float*, float*, int*,
         float*, int*, int*, int*, int*);
   extern void dsyevx_(char*, char*, char*, int*, double*, int*, double*,
         double*, int*, int*, double*, int*, double*, double*, int*,
         double*, int*, int*, int*, int*);
}

// overloaded LAPACK wrappers:
inline void syevx(char JOBZ, char RANGE, char UPLO, int N, float* A, int LDA,
      float VL, float VU, int IL, int IU, float ABSTOL, int& M, float* W, float* Z, int LDZ,
      float* WORK, int LWORK, int* IWORK, int* IFAIL, int& INFO)
{
   ssyevx_(&JOBZ, &RANGE, &UPLO, &N, A, &LDA, &VL, &VU, &IL, &IU, &ABSTOL,
         &M, W, Z, &LDZ, WORK, &LWORK, IWORK, IFAIL, &INFO);
}

inline void syevx(char JOBZ, char RANGE, char UPLO, int N, double* A, int LDA,
      double VL, double VU, int IL, int IU, double ABSTOL, int& M, double* W, double* Z, int LDZ,
      double* WORK, int LWORK, int* IWORK, int* IFAIL, int& INFO)
{
   dsyevx_(&JOBZ, &RANGE, &UPLO, &N, A, &LDA, &VL, &VU, &IL, &IU, &ABSTOL,
         &M, W, Z, &LDZ, WORK, &LWORK, IWORK, IFAIL, &INFO);
}

namespace ompilancz
{

// Lapack symmetric eigensolver wrapper:

template <typename T>
class symmetric_eigensolver
{
   public:
      symmetric_eigensolver(int s)
      : n_(s * 3), nev_(s)
      {
         // avoid unnecessary reallocations:
         W_.reserve(n_);
         Z_.reserve(n_ * n_);

         WORK_.reserve(8 * n_);
         IWORK_.reserve(5 * n_);
         IFAIL_.reserve(n_);
      }

      // change size after some eigenvalues converged in LOBPCG
      void reset_size(int s)
      {
         n_ = s * 3;
         nev_ = s;
      }

      void solve(std::vector<T> & AB)
      {
         T ABSTOL = Lamch<T>::lamch('S');
         int M, INFO;

         int n;

         // used by LOBPCG, first iteration different size (2 blocks of vectors) than iterations after (3 blocks of vectors)
         if (AB.size() == n_ * n_)
            n = n_;
         else
            n = nev_ * 2;

         W_.resize(nev_);
         Z_.resize(n * nev_);
         WORK_.resize(8 * n);
         IWORK_.resize(5 * n);
         IFAIL_.resize(n);

         syevx('V', 'I', 'L', n, AB.data(), n, (T)0.0, (T)0.0, 1, nev_, ABSTOL, M,
               W_.data(), Z_.data(), n, WORK_.data(), 8 * n, IWORK_.data(), IFAIL_.data(), INFO);
         
         if (INFO)
         {
            throw std::runtime_error("LAPACK ?syevx failed");
         }
      }

      // eigenvalue array:
      span<T> Lambda()
      {
         return span<T>(W_.data(), nev_);
      }

      // i-th (0-indexed) eigenvalue:
      T lambda(int i) const
      {
         assert(i < nev_);

         return W_[i];
      }

      // eigenvectors (2-D column-major) array:
      span<T> X()
      {
         return span<T>(Z_.data(), Z_.size());
      }

      // i-th (0-indexed) eigenvector:
      const span<T> x(int i)
      {
         assert(i < nev_);

         T* begin = Z_.data() + i * n_;
         return span<T>(begin, begin + n_);
      }


   private:
      int n_;    // nubmer of rows/columns
      int nev_;  // number of required eigenpairs

      std::vector<T> W_; // eigenvalue array
      std::vector<T> Z_; // eigenvectors (2-D column-major) array

      std::vector<T> WORK_;
      std::vector<int> IWORK_;
      std::vector<int> IFAIL_;



};

}  // namespace ompilancz

#endif
