#ifndef OMPILANCZ_DETAIL_MATRIX_TIMES_BLOCK_VECTOR_H
#define OMPILANCZ_DETAIL_MATRIX_TIMES_BLOCK_VECTOR_H

#include <algorithm>
#include <cassert>
#include <vector>

#include <mpi.h>

#include "diagonal_vector.h"
#include "block_diagonal_vector.h"
#include "mapping.h"
#include "mpi_datatype.h"
#include "../span.h"

namespace ompilancz
{

// matrix-times-block (diagonal)vector wrapper:

template <typename T>
class matrix_times_block_vector
{
   public:
      matrix_times_block_vector(mapping& map)
         : map_(map), mdt_( mpi_datatype<T>::get() )
      { }

      void set_block_size(uint64_t s)
      {
         x_.resize(map_.n() * s);
         y_.resize(map_.m() * s);

         if (!map_.diag())
         {
            offdiag_xt_.resize(map_.m() * s);
            offdiag_yt_.resize(map_.n() * s);

            xt_ = span<T>( offdiag_xt_.data(), offdiag_xt_.size());
            yt_ = span<T>( offdiag_yt_.data(), offdiag_yt_.size());
         }

         s_ = s;
      }

      void diag_setup_xy( /* const */ block_diagonal_vector<T>* X, block_diagonal_vector<T>* Y)
                          // not const because of MPI API flaw
      {
         assert(map_.diag());
         assert(X != nullptr);
         assert(Y != nullptr);

         diag_X_ = X;
         diag_Y_ = Y;

         xt_ = span<T>( x_.data(), x_.size());
         yt_ = span<T>( y_.data(), y_.size());
      }

      void broadcast_X()
      {
         if (map_.diag())
         {
            // transformation from block-vector to linear array:
            for (uint64_t i = 0; i < map_.n(); i++)
               for (int j = 0; j < s_; j++)
                  x_[i * s_ + j] = (*diag_X_)[j][i];
         }

         MPI_Bcast(x_.data(), s_ * map_.n(), mdt_, 0, map_.vcomm());
         MPI_Bcast(xt_.data(), s_ * map_.m(), mdt_, 0, map_.hcomm());
      }

      template <typename U>
      void multiply(U&& block_vector_matvec_op)
      {
         std::fill(y_.begin(), y_.end(), (T)0.0);
         if (!map_.diag())
            std::fill(yt_.begin(), yt_.end(), (T)0.0);

         span<T> x(x_.data(),x_.size());
         span<T> y(y_.data(),y_.size());

         block_vector_matvec_op(x,y,xt_,yt_, s_);
      }

      void reduce_Y()
      {
         void* sendbuf1 = map_.diag() ? MPI_IN_PLACE : y_.data();
         void* sendbuf2 = map_.diag() ? MPI_IN_PLACE : yt_.data();
         void* recvbuf = map_.diag() ? y_.data() : nullptr;

         MPI_Reduce(sendbuf1, recvbuf, s_ * map_.m(), mdt_, MPI_SUM, 0, map_.hcomm());
         MPI_Reduce(sendbuf2, recvbuf, s_ * map_.n(), mdt_, MPI_SUM, 0, map_.vcomm());

         if (map_.diag())
         {
            // transformation from linear array to block-vector:
            for (uint64_t i = 0; i < map_.m(); i++)
               for (int j = 0; j < s_; j++)
                  (*diag_Y_)[j][i] = y_[i * s_ + j];
         }
      }

   private:
      mapping& map_;
      MPI_Datatype mdt_;

      // data for diagonal processes:
      /* const */ block_diagonal_vector<T>* diag_X_; // not const because of MPI API flaw
      block_diagonal_vector<T>* diag_Y_;

      span<T> xt_,yt_;

      uint64_t s_; // block size

      // data for all processes:
      std::vector<T> x_, y_;
      // additional data for off-diagonal processes:
      std::vector<T> offdiag_xt_, offdiag_yt_;
};

}  // namespace ompilancz

#endif
