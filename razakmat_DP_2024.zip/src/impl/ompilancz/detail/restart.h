#ifndef OMPILANCZ_RESTART_H
#define OMPILANCZ_RESTART_H

#include <cassert>
#include <iomanip>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

#include "block_diagonal_vector.h"
#include "chrono_timer.h"
#include "lapack_tridiagonal_eigensolver.h"
#include "lapack_block_tridiagonal_eigensolver.h"
#include "mapping.h"
#include "matrix_times_vector.h"
#include "mpi_datatype.h"

namespace ompilancz
{

template<typename T>
class restart
{
    public:
        virtual ~restart(){}
        virtual void setup(T eps, int nev, bool locking, int block_size = 1) = 0;
        virtual void execute(std::shared_ptr< block_diagonal_vector<T> > & v,
                                std::shared_ptr< tridiagonal_eigensolver<double> > & tde,
                                int step) = 0;
        virtual void execute(std::vector<block_diagonal_vector<T> > & bv,
                                std::shared_ptr< block_tridiagonal_eigensolver<T> > & btde,
                                int step) = 0;
        virtual int getNewNev() = 0;
        virtual void getEigenvalues(std::vector<T> & Lambda) = 0;
};

template <typename T>
class implicitRestart : public restart<T>
{
    public:
        implicitRestart(int I, int J, int N,
                uint64_t n, uint64_t m)
        : map_(I, J, N, n, m), mdt_( mpi_datatype<T>::get() )
        {
            locking_ = true;
            // if there is more than 1 diagonal proccess calculations will be split between two processes
            (N > 1) ? helper_status_ = true : helper_status_ = false;
        }
        void setup(T eps, int nev, bool locking, int block_size)
        {
            eps_ = eps;
            nev_ = nev;
            locking_ = locking;
            locked_ = 0;
        }

        // returns new number of required eigenvalues - used with locking
        int getNewNev()
        {
            return nev_;
        }

        // returns eigenvalues
        void getEigenvalues(std::vector<T> & Lambda)
        {
            assert(map_.root());

            for (auto & x : ritz_values_)
                Lambda.push_back(x);
        }

        // starts restart calculation
        void execute(std::shared_ptr< block_diagonal_vector<T> > & v,
                        std::shared_ptr< tridiagonal_eigensolver<double> > & tde,
                        int step)
        {
            int final_nev = nev_;
            if (step - locked_ <= nev_)
            {
                nev_ = step - locked_;
            }

            // save last Lanczos vector, will be used as inicial after restart
            diagonal_vector<T> last = std::move((*v)[v->size() - 1]);
            v->remove_last();
            n_ = v->size() - locked_;

            // path for other diagonal processes
            if (!map_.root())
            {
                MPI_Bcast(&newly_converged_, 1, MPI_INT, 0, map_.dcomm());
                nev_ = nev_ - newly_converged_;
                int rank;
                MPI_Comm_rank(map_.dcomm(),&rank);
                if (rank == 1)
                {
                    // main loop for diagonal process with rank 1
                    helperProcess();
                }
                else
                    Q_.resize(n_ * nev_);
                
                MPI_Bcast(Q_.data(), Q_.size(), mdt_, 1, map_.dcomm());

                createNewLanczosVectors(tde,v,last);
                locked_ += newly_converged_;
                nev_ = final_nev - newly_converged_;
                return;
            }

            // calls LAPACK eigensolver
            tde->solve(n_);

            // check if there will be new locking
            newly_converged_ = 0;
            if (locking_)
                checkConverge(tde);
            MPI_Bcast(&newly_converged_, 1, MPI_INT, 0, map_.dcomm());

            int num_shifts;
            std::vector<T> shifts;

            // calculate shifts - undesirable ritz values
            num_shifts = getShifts(shifts, tde);
            
            // get starting alphas and betas for stating Q_
            span<double> Temp = tde->Alpha();
            alpha_.assign(Temp.begin(), Temp.end());
            Temp = tde->Beta();
            beta_.assign(Temp.begin(), Temp.end());

            nev_ = nev_ - newly_converged_;

            // main loop for root process
            QRLoop(num_shifts,shifts);

            Q_.resize(n_* nev_);
            
            if (helper_status_)
            {
                MPI_Bcast(Q_.data(), Q_.size(), mdt_, 1, map_.dcomm());
            }
            else
            {
                linearization_of_QQ_();             
            }
            
            // setup last beta = last_beta * last row and last collumn of Q_
            beta_[nev_ - 1] = beta_[n_ - 1] * Q_[(nev_-1) * n_ + n_ - 1];

            createNewLanczosVectors(tde,v,last);
            
            locked_ += newly_converged_;
            set_tde_(tde);

            nev_ = final_nev - newly_converged_;
        }

        void execute(std::vector<block_diagonal_vector<T> > & bv,
                        std::shared_ptr< block_tridiagonal_eigensolver<T> > & btde,
                        int step)
        {
            throw std::runtime_error("Implicit restart for block-vector Lanczos not implemented.");
        }



    private:
        mapping map_;
        MPI_Datatype mdt_;
        T eps_; // required residual accuracy
        int n_; // size of starting matrix T
        int nev_; // number of desired eigenvalues
        bool helper_status_; // is there more than one diagonal proccess
        int newly_converged_;
        int locked_;
        bool locking_;
        std::vector<T> ritz_values_;
        std::vector<T> alpha_; // results from RQ multiplication - diagonal
        std::vector<T> beta_; // results from RQ multiplication - subdiagonal
        std::vector<T> Q_; // orthonormal matrix - result of QR decomposition
        std::vector<T> R_; // upper triangular matrix - result of QR decomposition
        std::vector< std::vector<T> > QQ_; // holds results of multiplications of Qs

        // setup of Lanczos vectors after restart
        void createNewLanczosVectors(std::shared_ptr< tridiagonal_eigensolver<double> > & tde,
                                    std::shared_ptr< block_diagonal_vector<T> > & v,
                                    diagonal_vector<T> & last)
        {
            block_diagonal_vector<T> tmp(v->get_map());

            // separate locked vectors from rest
            for (int i = locked_; i < n_ + locked_; i++)
            {
                tmp.add_diagonal((*v)[i]);
            }
            for (int i = locked_; i < n_ + locked_; i++)
            {
                v->remove_last();
            }

            std::vector<block_diagonal_vector<T> > newLanczos;
            newLanczos.push_back(v->get_map()); // newly converged vectors
            newLanczos.push_back(v->get_map()); // new Lanczos vectors

            // calculate newly converged vectors
            if (map_.root())
            {
                span<T> X = tde->X();
                span<T> Y(X.data(),n_ * newly_converged_);
                MPI_Bcast(Y.data(), Y.size(), mdt_, 0, map_.dcomm());
                newLanczos[0] = std::move(tmp.right_multiply_by_nxq(Y));
            }
            else
            {
                std::vector<T> Y(n_ * newly_converged_);
                MPI_Bcast(Y.data(), Y.size(), mdt_, 0, map_.dcomm());
                newLanczos[0] = std::move(tmp.right_multiply_by_nxq(Y));
            }

            std::vector<T> Q;
            Q.assign(Q_.begin(), Q_.end());

            // calculate new Lanczos vectors
            newLanczos[1] = std::move(tmp.right_multiply_by_nxq(Q_));

            // move all (locked, newly converged, new Lanczos) together
            v->linearization_vector_of_blocks(newLanczos);
            
            // ortogonalize last against rest
            v->add_span(last.data());
            v->orthonormalize_last();
        }

        // checks if some eigenvalues are converged and should be locked
        void checkConverge(std::shared_ptr< tridiagonal_eigensolver<double> > & tde)
        {
            if (map_.root())
            {
                for (int i = 0; i < nev_; i++)
                    if (tde->res(i) < eps_)
                    {
                        newly_converged_++;
                        ritz_values_.push_back(tde->lambda(i));
                    }
                    else
                        break;
            }
        }

        // calculates shifts - undesirable ritz values
        int getShifts(std::vector<T> & shifts, std::shared_ptr< tridiagonal_eigensolver<double> > & tde)
        {
            if (map_.root())
            {
                for (int i = n_ - 1; i >= nev_; i--)
                    shifts.push_back(tde->lambda(i));
                for (int i = 0; i < newly_converged_; i++)
                    shifts.push_back(tde->lambda(i));
            }
            return shifts.size();
        }

        // used by second diagonal procces with rank 1
        // runs concurently with root proccess in method QRLoop
        void helperProcess()
        {
            QQ_.resize(n_);

            for (int i = 0; i < n_; i++){
                QQ_[i].resize(n_);
                std::fill(QQ_[i].begin(),QQ_[i].end(),0.0);
                QQ_[i][i] = 1;
            }

            Q_.resize(n_ * n_);
            for (uint i = 0; i < n_ - nev_; i++)
            {
                MPI_Recv(Q_.data(), Q_.size(), mdt_, 0, 0, map_.dcomm(), MPI_STATUS_IGNORE);
                multiplyQs();
            }
            Q_.resize(n_* nev_);

            linearization_of_QQ_();
        }

        void linearization_of_QQ_()
        {
            #pragma omp parallel for
            for (int i = 0; i < nev_; i++)
                for (int j = 0; j < n_; j++)
                {
                    Q_[(i * n_) + j] = QQ_[j][i];
                }
        }

        // main loop of algorithm
        void QRLoop(int num_shifts, std::vector<T> & shifts)
        {
            R_.resize(n_ * n_);

            if (!helper_status_)
            {
                QQ_.resize(n_);
                for (int i = 0; i < n_; i++){
                    QQ_[i].resize(n_);
                    std::fill(QQ_[i].begin(),QQ_[i].end(),0.0);
                    QQ_[i][i] = 1;   
                }
            }

            for (uint i = 0; i < num_shifts; i++)
            {
                setQ_();

                std::fill(R_.begin(),R_.end(),0.0);

                shiftedTriQR(shifts[i]);

                if (helper_status_)
                    MPI_Send(Q_.data(),Q_.size(), mdt_, 1, 0, map_.dcomm());
                else
                    multiplyQs();
                
                multiplyRQaddshift(shifts[i]);
                  
            }
        }

        // set newly calculated alphas and betas to eigensolver
        void set_tde_(std::shared_ptr< tridiagonal_eigensolver<double> > & tde)
        {
            tde->reset_size(nev_);
            for (int i = 0; i < nev_; i++)
                tde->alpha(i) = alpha_[i];
            for (int i = 0; i < nev_; i++)
                tde->beta(i) = beta_[i];
        }

        // multiply every Q gained by Shifted QR decomposition
        void multiplyQs()
        {
            #pragma omp parallel
            {
                std::vector<T> loc_res;
                #pragma omp for
                for (int i = 0; i < n_; i++)
                {
                    loc_res.resize(n_);
                    for (int j = 0; j < n_; j++)
                    {
                        T res = 0;
                        for (int k = 0; k < n_; k++)
                            res += QQ_[i][k] * Q_[(j * n_) + k];
                        loc_res[j] = res;                    
                    }
                    QQ_[i].swap(loc_res);    
                }                
            }

        }

/*        void orthonormlizeQQ_()
        {
            int s = QQ_[0].size();
            for (int i = 0; i < s; i++)
	        {
	      	    for (int j = 0; j < i; j++)
                {
                    long double dot = (long double)0.0;
                    for (int k = 0; k < n_; k++)
                        dot += QQ_[k][i] * QQ_[k][j];
                    for (int k = 0; k < n_; k++)
                        QQ_[k][i] -= dot * QQ_[k][j];
                }
                long double dot = (long double)0.0;
                for (int k = 0; k < n_; k++)
                        dot += QQ_[k][i] * QQ_[k][i];
                dot = (long double)1.0 / dot;
                for (int k = 0; k < n_; k++)
                    QQ_[k][i] *= dot;
            }

        }
*/

        // QR decomposition with shift being undesirable ritz value
        void shiftedTriQR(T shift)
        {
            for (int i = 0; i < n_; i++)
                Q_[i * n_ + i] -= shift;

            for (int i = 0; i < n_; i++)
            {

                for (int j = i > 1 ? i - 2 : 0; j < i; j++)
                {
                    R_[j * n_ + i] = dot_product(i,j);
                    scaled_subtract(R_[j * n_ + i],i,j);
                }
                R_[i * n_ + i] = normalize(i);
            }

        }

        T normalize(int i)
        {
            T temp = sqrt(dot_product(i,i));
            if (temp == (T)0.0)
                return temp;
            T mult = (T)1.0 / temp;

            for (uint64_t k = 0; k < n_; k++)
                Q_[i * n_ + k] *= mult;

            return temp;
        }

        T dot_product(int i, int j)
        {
            // every Q_[i * n_ + k] * Q_[j * n_ + k] with k >= min is zero
            int min = std::min(i,j);
            min = std::min(min + 2,n_);
            T res = 0;
            for (uint64_t k = 0; k < min; k++)
                res += Q_[i * n_ + k] * Q_[j * n_ + k];
            return res;
        }

        void scaled_subtract(T dot, int i, int j)
        {
            // every Q_[j * n_ + k] with k >= min is zero
            int min = std::min(j + 2, n_);
            for (int k = 0; k < min; k++)
                Q_[i * n_ + k] -= dot * Q_[j * n_ + k];
        }

        // multiplication of R and Q, results are put in alpha_ and beta_
        void multiplyRQaddshift(T shift)
        {            
            for (int i = 0; i < n_; i++)
                for (int j = i; j <= i + 1; j++)
                {
                    if (j == n_)
                        break;
                    T res = 0.0;
                    for (int k = i; k < i + 3; k++)
                    {
                        if (k == n_)
                            break;
                        res += R_[i * n_ + k] * Q_[j * n_ + k];
                    }
                    if ( i == j)
                        alpha_[i] = res;
                    else
                        beta_[i] = res;
                }
            for (int i = 0; i < n_; i++)
                alpha_[i] += shift;
        }

        // setup Q - tridiagonal matrix for QR decomposition
        void setQ_()
        {
            Q_.resize(n_ * n_);
            std::fill(Q_.begin(),Q_.end(),0.0);
            Q_[0] = alpha_[0];
            Q_[1] = beta_[0];
            Q_[(n_ - 1) * n_ + n_ - 1] = alpha_[n_ - 1];
            Q_[(n_ - 1) * n_ + n_ - 2] = beta_[n_ - 2];

            for (int i = 1; i < n_ - 1; i++)
            {
                Q_[i * n_ + i - 1] =  beta_[i - 1];
                Q_[i * n_ + i] = alpha_[i];
                Q_[i * n_ + i + 1] = beta_[i];
            }
        }

};

template <typename T>
class thickRestart : public restart<T>
{
    public:
        thickRestart(int I, int J, int N,
                uint64_t n, uint64_t m)
        : map_(I, J, N, n, m), mdt_( mpi_datatype<T>::get() )
        {
            locking_ = true;
        }
        void setup(T eps, int nev, bool locking, int block_size)
        {
            eps_ = eps;
            block_size_ = block_size;
            locking_ = locking;
            locked_ = 0;

            // for restart number of desired eigenvalues must be divisible by block_size
            if (nev % block_size != 0)
                nev += (block_size - nev % block_size);
            nev_ = nev;
        }

        // returns new number of required eigenvalues - used with locking
        int getNewNev()
        {
            return nev_;
        }

        // returns eigenvalues
        void getEigenvalues(std::vector<T> & Lambda)
        {
            assert(map_.root());

            for (auto & x : ritz_values_)
                Lambda.push_back(x);
        }

        // starts restart calculation
        void execute(std::shared_ptr< block_diagonal_vector<T> > & v,
                        std::shared_ptr< tridiagonal_eigensolver<double> > & tde,
                        int step)
        {
            int final_nev = nev_;
            if (step - locked_ <= nev_)
            {
                nev_ = step - locked_;
            }

            // save last Lanczos vector, will be used as inicial after restart
            diagonal_vector<T> last = std::move((*v)[v->size() - 1]);

            v->remove_last();
            n_ = v->size() - locked_;

            // path for other diagonal processes
            if (!map_.root())
            {
                MPI_Bcast(&newly_converged_, 1, mdt_, 0, map_.dcomm());

                createNewLanczosVectors(tde,v,last);
                nev_ = final_nev - newly_converged_;
                return;
            }

            // calls LAPACK eigensolver
            tde->solve(n_);

            newly_converged_ = 0;
            if (locking_)
                checkConverge(tde);

            MPI_Bcast(&newly_converged_, 1, mdt_, 0, map_.dcomm());

            span<T> Y = createNewLanczosVectors(tde,v,last);

            // calculate arrow, will be placed in T instead of last beta
            std::vector<T> arrow(nev_, 0);
            T beta_last = tde->beta(n_ - 1);
            GetArrow(arrow, beta_last, Y);

            set_tde_(tde, arrow);

            nev_ = final_nev - newly_converged_;
        }

        // starts restart calculation
        void execute(std::vector<block_diagonal_vector<T> > & bv,
                        std::shared_ptr< block_tridiagonal_eigensolver<T> > & btde,
                        int step)
        {
            int final_nev = nev_;
            if (step  * block_size_ - locked_ <= nev_)
            {
                nev_ = (step * block_size_)  - locked_;
            }
            
            // save last block vector , will be used as inicial after restart
            block_diagonal_vector<T> last = std::move(bv.back());

            bv.pop_back();
            n_ = bv.size() * block_size_ - locked_;

            // path for other diagonal processes
            if (!map_.root())
            {
                MPI_Bcast(&newly_converged_, 1, mdt_, 0, map_.dcomm());

                createNewLanczosVectors(btde,bv,last);
                nev_ = final_nev - newly_converged_;
                return;
            }

            // calls LAPACK eigensolver
            btde->solve(nev_);

            newly_converged_ = 0;
            if (locking_)
                checkConverge(btde);

            MPI_Bcast(&newly_converged_, 1, mdt_, 0, map_.dcomm());

            span<T> Y = createNewLanczosVectors(btde,bv,last);

            // calculate block arrow, will be placed in T instead of last beta
            std::vector<T> arrow(block_size_ * nev_, 0);
            span<T> beta_last = btde->beta((n_ / block_size_) - 1);
            GetArrow(arrow, beta_last, Y);

            // reset alphas and betas
            btde->reset_size(nev_ / block_size_);
            setAlpha(btde);
            setBeta(btde);

            btde->fillArrow(arrow, nev_ / block_size_);

            nev_ = final_nev - newly_converged_;
        }


    private:
        mapping map_;
        MPI_Datatype mdt_;
        T eps_;
        int n_;
        int nev_;
        int block_size_;
        int newly_converged_;
        int locked_;
        bool locking_;
        std::vector<T> ritz_values_;

        // setup of Lanczos vectors after restart
        span<T> createNewLanczosVectors(std::shared_ptr< block_tridiagonal_eigensolver<T> > & btde,
                                    std::vector< block_diagonal_vector<T> > & bv,
                                    block_diagonal_vector<T> & last)
        {
            // linearization of blocks of Lanczos vectors for easier calculations
            block_diagonal_vector<T> tmp(bv[0].get_map());
            tmp.linearization_vector_of_blocks(bv,locked_ / block_size_);

            // multiply Lanczos vectors with selected ritz vectors
            if (map_.root())
            {
                span<T> X = btde->X();
                span<T> Y(X.data(),n_ * nev_);
                MPI_Bcast(Y.data(), Y.size(), mdt_, 0, map_.dcomm());
                tmp = std::move(tmp.right_multiply_by_nxq(Y));                
            }
            else
            {
                std::vector<T> Y(n_ * nev_);
                MPI_Bcast(Y.data(), Y.size(), mdt_, 0, map_.dcomm());
                tmp = std::move(tmp.right_multiply_by_nxq(Y));
            }

            // put Lanczos vectors back to blocks and add last block before restart
            //bv.clear();
            while(bv.size() != locked_ / block_size_)
                bv.pop_back();
            tmp.createBlocks(bv,block_size_);
            bv.push_back(std::move(last));

            // orthonormalization of last block to previous ones
            std::vector<T> temp(block_size_ * block_size_);
            int n = bv.size() - 1;
			for (int i = n - 1; i >= 0; i--)
			{
				temp = bv[i].transposed_times_other(bv[n]);
				bv[n].block_scaled_subtract(temp, bv[i]);
			}
            bv[n].QR_factorization(temp);

            locked_ += newly_converged_;
            nev_ = nev_ - newly_converged_;
            // return of ritz vectors corresponding to active Lanczos vectors
            if (map_.root())
            {
                span<T> X = btde->X();
                span<T> ret(X.data() + newly_converged_ * n_, n_ * nev_);
                return ret;
            }
            span<T> ret;
            return ret;
        }

        // setup of Lanczos vectors after restart
        span<T> createNewLanczosVectors(std::shared_ptr< tridiagonal_eigensolver<T> > & tde,
                                    std::shared_ptr< block_diagonal_vector<T> > & v,
                                    diagonal_vector<T> & last)
        {
            block_diagonal_vector<T> tmp(v->get_map());

            // separate locked vectors from rest
            for (int i = locked_; i < n_ + locked_; i++)
            {
                tmp.add_diagonal((*v)[i]);
            }
            for (int i = locked_; i < n_ + locked_; i++)
            {
                v->remove_last();
            }

            block_diagonal_vector<T> newLanczos(v->get_map());

            // calculate new Lanczos vectors
            if (map_.root())
            {
                span<double> X = tde->X();
                span<T> Y(X.data(),n_ * nev_);
                MPI_Bcast(Y.data(), Y.size(), mdt_, 0, map_.dcomm());
                newLanczos = std::move(tmp.right_multiply_by_nxq(Y));
            }
            else
            {
                std::vector<T> Y(n_ * nev_);
                MPI_Bcast(Y.data(), Y.size(), mdt_, 0, map_.dcomm());
                newLanczos = std::move(tmp.right_multiply_by_nxq(Y));
            }

            // returns new Lanczos vectors back to v
            for (int i = 0; i < nev_; i++)
            {
                v->add_diagonal(newLanczos[i]);
            }

            // ortogonalize last against rest
            v->add_span(last.data());
            v->orthonormalize_last();

            locked_ += newly_converged_;
            nev_ = nev_ - newly_converged_;

            // return of ritz vectors corresponding to active Lanczos vectors
            if (map_.root())
            {
                span<T> X = tde->X();
                span<T> ret(X.data() + newly_converged_ * n_, n_ * nev_);
                return ret;
            }
            span<T> ret;
            return ret;
        }

        // checks if some eigenvalues are converged and should be locked - block Lanczos
        void checkConverge(std::shared_ptr< block_tridiagonal_eigensolver<T> > & btde)
        {
            if (map_.root())
            {
                for (int i = 0; i < nev_; i++)
                    if (btde->res(i) < eps_)
                    {
                        newly_converged_++;
                    }
                    else
                        break;
                newly_converged_ /= block_size_;
                newly_converged_ *= block_size_;
                for (int i = 0; i < newly_converged_; i++)
                    ritz_values_.push_back(btde->lambda(i));
            }
        }

        // checks if some eigenvalues are converged and should be locked - single vector Lanczos
        void checkConverge(std::shared_ptr< tridiagonal_eigensolver<double> > & tde)
        {
            if (map_.root())
            {
                for (int i = 0; i < nev_; i++)
                    if (tde->res(i) < eps_)
                    {
                        newly_converged_++;
                        ritz_values_.push_back(tde->lambda(i));
                    }
                    else
                        break;
            }
        }

        // get block for T (creates arrow matrix) Arrow = beta * last rows of Y
        void GetArrow(std::vector<T> & arrow, span<T> beta, span<T> Y)
        {
            #pragma omp parallel for
            for (int i = 0; i < nev_; i++)
            {
                for (int j = 0; j < block_size_; j++)
                {
                    for (int k = 0; k < block_size_; k++)
                    {
                        arrow[i * block_size_ + j] += beta[(k * block_size_) + j] * Y[(n_ * i) + n_ - block_size_ + k];
                    }
                }
            }
        }

        // get block for T (creates arrow matrix) Arrow = beta * last rows of Y
        void GetArrow(std::vector<T> & arrow, T beta, span<T> Y)
        {
            for (int i = 0; i < nev_; i++)
                arrow[i] = beta * Y[(n_ * i) + n_ - 1];
        }

        // fill alphas on diagonals with ritz values of desired eigenvalues 
        void setAlpha(std::shared_ptr< block_tridiagonal_eigensolver<T> > & btde)
        {
            int conv_blocks = newly_converged_ / block_size_;
            for (int i = 0 ; i < nev_ / block_size_; i++)
            {
                span<T> A = btde->alpha(i);
                std::fill(A.begin(),A.begin() + A.size(),0);

                for (int j = 0; j < block_size_; j++)
                {
                    A[j * block_size_ + j] = btde->lambda((i + conv_blocks) * block_size_ + j); 
                }
            }
        }

        // fill betas with zeros
        void setBeta(std::shared_ptr< block_tridiagonal_eigensolver<T> > & btde)
        {
            span<T> B = btde->Beta();
            std::fill(B.begin(),B.begin() + B.size(),0);
        }

        // set newly calculated alphas and betas to eigensolver
        void set_tde_(std::shared_ptr< tridiagonal_eigensolver<double> > & tde, std::vector<T> & arrow)
        {
            tde->reset_size(nev_);
            tde->setArrow(nev_);
            span<T> A = tde->Alpha();
            for (int i = newly_converged_; i < nev_ + newly_converged_; i++)
                A[i - newly_converged_] = tde->lambda(i);
            span<T> B = tde->Beta();
            for (int i = 0;i < nev_; i++)
                B[i] = arrow[i];
        }

};

}  // namespace ompilancz

#endif