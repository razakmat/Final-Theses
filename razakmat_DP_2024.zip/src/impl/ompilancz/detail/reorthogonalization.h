#ifndef OMPILANCZ_REORTHOGONALIZATION_H
#define OMPILANCZ_REORTHOGONALIZATION_H

#include <cassert>
#include <iomanip>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include <random>
#include <cmath>

#include "block_diagonal_vector.h"
#include "chrono_timer.h"
#include "lapack_tridiagonal_eigensolver.h"
#include "mapping.h"
#include "matrix_times_vector.h"
#include "mpi_datatype.h"
#include "lapack_singular_value_solver.h"

namespace ompilancz
{

template <typename T>
class reorthogonalization
{
    public:
        reorthogonalization(int I, int J, int N,
                uint64_t n, uint64_t m)
        :map_(I, J, N, n, m), mdt_(mpi_datatype<T>::get())
        {}
        virtual ~reorthogonalization(){}
        void setup(std::shared_ptr< tridiagonal_eigensolver<double> > tde)
        {
            tde_ = tde;
        }
        void setup(std::shared_ptr< block_tridiagonal_eigensolver<T> > btde)
        {
            btde_ = btde;
        }
        virtual std::pair<T, T> orthonormalize(std::shared_ptr< block_diagonal_vector<T> > & v) = 0;
        virtual void orthonormalize(std::vector< block_diagonal_vector<T> > & bv,
                                    std::vector<T> & Alpha, std::vector<T> & Beta) = 0;
    protected:
        mapping map_;
        MPI_Datatype mdt_;
        std::shared_ptr< tridiagonal_eigensolver<T> > tde_;
        std::shared_ptr< block_tridiagonal_eigensolver<T> > btde_;
};

template <typename T>
class fullOrtho : public reorthogonalization<T>
{
    public:
        fullOrtho(int I, int J, int N,
                uint64_t n, uint64_t m)
        :reorthogonalization<T>(I,J,N,n,m)
        {}
        std::pair<T, T> orthonormalize(std::shared_ptr< block_diagonal_vector<T> > & v)
        {
            return v->orthonormalize_last();
        }
        void orthonormalize(std::vector< block_diagonal_vector<T> > & bv,
                            std::vector<T> & Alpha, std::vector<T> & Beta)
        {
            int j = bv.size() - 1;

            // diagonal block A_j:
            Alpha = bv[j - 1].transposed_times_other_symmetric(bv[j]);
            bv[j].block_scaled_subtract(Alpha, bv[j - 1]);

            // full block orthogonalization:
			std::vector<T> temp;
			for (int i = j - 2; i >= 0; i--)
			{
				temp = bv[i].transposed_times_other(bv[j]);
				bv[j].block_scaled_subtract(temp, bv[i]);
			}

            // QR-factorization
            bv[j].QR_factorization(Beta);
        }
};

template <typename T>
class fullMultiBlockOrtho : public reorthogonalization<T>
{
    public:
        fullMultiBlockOrtho(int I, int J, int N,
                uint64_t n, uint64_t m, int repeats = 2)
        :reorthogonalization<T>(I,J,N,n,m), repeats_(repeats)
        {
            crit_ = (T)1.0 / sqrt(2);
        }

        // single vector Lanczos
        std::pair<T, T> orthonormalize(std::shared_ptr< block_diagonal_vector<T> > & v)
        {
            int iter = 0;
            int n = v->size() - 1;
            std::vector<T> r(n,0);
            T dot_x;
            T beta = v->ith_vector(n).norm();
            std::vector<T> h;
            h.resize(n);

            do{
                dot_x = beta;
                v->right_multiple_by_last_vector(h);

                v->scaled_subtract_from_last_vector(h);


                for (int i = 0; i < n; i++)
                    r[i] += h[i];

                beta = v->ith_vector(n).norm();
            }while (dot_x * crit_ > beta && iter++ < repeats_);


            beta = v->ith_vector(n).normalize();
            return {r[n - 1], beta};
        }

        // Block Lanczos
        void orthonormalize(std::vector< block_diagonal_vector<T> > & bv,
                            std::vector<T> & Alpha, std::vector<T> & Beta)
        {
            int iter = 0;
            int block_size = bv[0].size();
            block_diagonal_vector<T> v(bv[0].get_map());
            v.linearization_vector_of_blocks(bv);
            int n = v.size();
            std::vector<T> r((n - block_size) * block_size,0);
            T dot_x;
            std::vector<T> norms(block_size,0);
            getNorms(v,block_size,norms);
            T beta_dif;
            std::vector<T> h;
            h.resize((n - block_size) * block_size);
            Alpha.resize(block_size * block_size);

            do{
                v.right_multiple_by_last_block_vector(h,block_size);
                
                v.scaled_subtract_from_last_block_vector(h, block_size);

                #pragma omp parallel for
                for (int i = 0; i < (n - block_size) * block_size; i++)
                    r[i] += h[i];


                beta_dif = getDifNorm(v,block_size,norms);
            }while (crit_ > beta_dif && iter++ < repeats_);
            
            calculateAlpha(r,Alpha,block_size,n);
            bv.clear();
            v.createBlocks(bv,block_size);
            bv[bv.size() - 1].QR_factorization(Beta);
        }
    private:
        int repeats_; // maximal number of repeats of iterations
        T crit_; // critical value for ending loop, set to (T)1.0 / sqrt(2)

        // get norms for final comparison against crit_
        void getNorms(block_diagonal_vector<T> & v, int block_size, std::vector<T> & norms)
        {
            int j = 0;
            for (int i = v.size() - block_size; i < v.size(); i++)
                norms[j++] = v.ith_vector(i).norm();
        }
        
        // get min dif between vector before and after ortogonalization
        T getDifNorm(block_diagonal_vector<T> & v, int block_size, std::vector<T> & norms)
        {
            T min = (T)1.0;
            T dif = (T)1.0;

            for (int i = v.size() - block_size; i < v.size(); i++)
            {
                int tmp = v[i].norm();
                dif = tmp / norms[i - (v.size() - block_size)];
                norms[i - (v.size() - block_size)] = tmp;

                if (dif < min)
                    min = dif;
            }
            return min;
        }

        // calculate Alpha = last block in r
        void calculateAlpha(std::vector<T> & r, std::vector<T> & Alpha, int block_size, int n)
        {
            #pragma omp parallel for
            for (int i = 0; i < block_size; i++)
            {
                for (int j = 0; j < block_size; j++)
                {
                    Alpha[(i * block_size) + j] = r[i * (n - block_size) + n - (2*block_size) + j];
                }
            }
        }
};

template <typename T>
class PartialOrtho : public reorthogonalization<T>
{
    public:
        PartialOrtho(int I, int J, int N,
                uint64_t n, uint64_t m, int size_block = 1)
        :reorthogonalization<T>(I,J,N,n,m)
        {
            if (this->map_.root())
            {
                // sets initial values for calculation of omega
                gen.seed(rd());
                size_of_A_ = N * n;
                first_step = true;
                sqrtEpsilon = sqrt(std::numeric_limits<T>::epsilon());
                interval_limit = pow(std::numeric_limits<T>::epsilon(),0.75);
                w_j1_.resize(2);
                w_j1_[0] = 0;
                w_j1_[1] = std::numeric_limits<T>::epsilon() * size_of_A_ * size_block;                
            }
            block_size_ = size_block;
            svs_ = std::make_shared<singular_value_solver<T>>(block_size_);
        }

        // single vector Lanczos
        std::pair<T, T> orthonormalize(std::shared_ptr< block_diagonal_vector<T> > & v)
        {
            if (w_j1_.size() > v->size())
            {
                throw std::runtime_error("Partial reorthogonalization with restart is not implemented.");
            }
            n_ = v->size() - 1;
            // local ortogonalization
            if (n_ > 1)
            {
               (*v)[n_].scaled_subtract(beta_[n_ - 2],(*v)[n_ - 2]);
            }

            T alpha = (*v)[n_].orthogonalize((*v)[n_ - 1]);
            T beta = (*v)[n_].norm();

            std::vector<T> errorA;
            T errorB;

            saveAlphaBeta(alpha,beta);

            // root process calculates omega recurence 
            if (this->map_.root())
            {
                getErrors(errorA,errorB,beta);
                computeW(errorA,errorB);
            }

            if (n_ < 3)
            {
                
                (*v)[n_].normalize();
                return {alpha,beta};
            }

            // sends non-root processes to diagProcess method
            if (!this->map_.root())
            {
                diagProcess(v);
                beta = (*v)[n_].normalize();
                return {alpha,beta};
            }

            int sent;
            // if first_step calculate intervals for reortogonalization
            if (first_step)
            {
                calculateIntervals();
                sent = intervals_.size();

                // if no ortogonalization
                if (sent == 0)
                {
                    MPI_Bcast(&sent, 1, MPI_INT , 0, this->map_.dcomm());
                    (*v)[n_].normalize();
                    return {alpha,beta};
                }
            }
            else
                sent = intervals_.size();
            MPI_Bcast(&sent, 1, MPI_INT , 0, this->map_.dcomm());

            // ortogonalization
            for (int i = 0; i < intervals_.size() ; i++)
            {
                orthogonalizeInterval(intervals_[i].first,intervals_[i].second, v);
            }

            if (first_step)
            {
                first_step = false;
            }
            else
            {
                first_step = true;
                intervals_.clear();
            }

            // recalculate Beta
            beta = (*v)[n_].normalize();
            return {alpha,beta};
        }

        // Block Lanczos
        void orthonormalize(std::vector< block_diagonal_vector<T> > & bv,
                            std::vector<T> & Alpha, std::vector<T> & Beta)
        {
            assert(block_size_ == bv[0].size());
            if (w_j1_.size() > bv.size())
            {
                throw std::runtime_error("Partial reorthogonalization with restart is not implemented.");
            }
            n_ = bv.size() - 1;

            // local ortogonalization
            Alpha = bv[n_ - 1].transposed_times_other(bv[n_]);
            bv[n_].block_scaled_subtract(Alpha, bv[n_ - 1]);
            if (n_ > 1)
            {
                std::vector<T> temp;
                temp = bv[n_ - 2].transposed_times_other(bv[n_]);
                bv[n_].block_scaled_subtract(temp, bv[n_ - 2]);
            }

            block_diagonal_vector<T> V = bv[n_];
            V.QR_factorization(Beta);

            std::vector<T> errorA;
            T errorB;

            // root process calculates omega recurence
            if (this->map_.root())
            {
                calculateAlphaBeta(Alpha,Beta);
                computeWBlock();
            }

            if (n_ < 3)
            {
                bv[n_] = std::move(V);
                return;
            }

            // sends non-root processes to diagProcessBlock method
            if (!this->map_.root())
            {
                // if there was ortogonalization recalculate Beta
                if (diagProcessBlock(bv))
                {
                    bv[n_].QR_factorization(Beta);
                }
                else
                {
                    bv[n_] = std::move(V);
                }
                return;
            }

            int sent;
            // if first_step calculate intervals for reortogonalization
            if (first_step)
            {
                calculateIntervals();
                sent = intervals_.size();

                // if no ortogonalization
                if (sent == 0)
                {
                    MPI_Bcast(&sent, 1, MPI_INT , 0, this->map_.dcomm());
                    bv[n_] = std::move(V);                    
                    return;
                }
            }
            else
                sent = intervals_.size();

            MPI_Bcast(&sent, 1, MPI_INT , 0, this->map_.dcomm());

            bool ortho = false;
            // ortogonalization
            for (int i = 0; i < intervals_.size() ; i++)
            {
                ortho = orthogonalizeIntervalBlock(intervals_[i].first,intervals_[i].second,bv);
            }

            if (first_step)
            {
                first_step = false;
            }
            else
            {
                first_step = true;
                intervals_.clear();
            }

            // if there was ortogonalization recalculate Beta
            if (ortho)
            {
                bv[n_].QR_factorization(Beta);
            }
            else
            {
                bv[n_] = std::move(V);  
            }
            return;

        }
    private:
        std::vector<T> w_j_; // vector omega j
        std::vector<T> w_j1_; // vector omega j+1
        std::vector<T> alpha_; // single Lanczos - alpha from Lanczos algorithm, block Lanczos largest singular of Alpha
        std::vector<T> beta_; // single Lanczos - beta from Lanczos algorithm, block Lanczos largest singular of Beta
        std::vector<T> low_beta_; // block Lanzos - lowest singular value of Beta
        int n_; // number of Lanczos vectors (or blocks)
        int size_of_A_; // estimate of size input matrix A - for calculating omega recurence 
        T interval_limit; // for calculating omega recurence 
        T sqrtEpsilon; // for calculating omega recurence
        std::random_device rd;
        std::mt19937 gen;
        bool first_step; // intervals for ortogonalization are calculated during first_step = true
        int block_size_; // size of block (for Block Lanczos)
        std::vector<std::pair<int,int> > intervals_; // vectors (blocks) against which will be ortogonalize current vector (block)
        std::shared_ptr<singular_value_solver<T>> svs_; // LAPACK singular decomposition solver - for alpha_, beta_

        void saveAlphaBeta(T alpha, T beta)
        {
            alpha_.push_back(alpha);
            beta_.push_back(beta);
        }

        // calculate singular values
        void calculateAlphaBeta(std::vector<T> & Alpha, std::vector<T> & Beta)
        {
            svs_->solve(Alpha);
            alpha_.push_back(svs_->value(0));
            svs_->solve(Beta);
            beta_.push_back(svs_->value(0));
            low_beta_.push_back(svs_->value(block_size_ - 1));
        }

        // for diagonal processes, receive intervals from root and ortogonalize current vector against them
        void diagProcess(std::shared_ptr< block_diagonal_vector<T> > & v)
        {
            int n;
            MPI_Bcast(&n, 1, MPI_INT , 0, this->map_.dcomm());

            std::vector<int> interval;
            interval.resize(2);

            for (int i = 0; i < n; i++)
            {
                MPI_Bcast(interval.data(), 2, MPI_INT , 0, this->map_.dcomm());
                for (int j = interval[0]; j <= interval[1]; j++)
                    (*v)[n_].orthogonalize((*v)[j - 1]);
            }
        }

        // for diagonal processes, receive intervals from root and ortogonalize current block against them
        bool diagProcessBlock(std::vector< block_diagonal_vector<T> > & bv)
        {
            int n;
            bool ortho = false;
            MPI_Bcast(&n, 1, MPI_INT , 0, this->map_.dcomm());

            std::vector<int> interval;
            interval.resize(2);

            for (int i = 0; i < n; i++)
            {
                MPI_Bcast(interval.data(), 2, MPI_INT , 0, this->map_.dcomm());
                for (int j = interval[0]; j <= interval[1]; j++)
                {
                    std::vector<T> temp;
                    temp = bv[j - 1].transposed_times_other(bv[n_]);
				    bv[n_].block_scaled_subtract(temp, bv[j - 1]);
                    ortho = true;
                }
            }
            return ortho;
        }

        // for root process, sends intervals to other diagonal processes and ortogonalize current vector against them
        void orthogonalizeInterval(int a, int b, std::shared_ptr< block_diagonal_vector<T> > & v)
        {
            std::normal_distribution<T> dist(0, 1.5);
            std::vector<int> interval;
            interval.push_back(a);
            interval.push_back(b);
            MPI_Bcast(interval.data(), 2, MPI_INT , 0, this->map_.dcomm());

            for (int i = a; i <= b; i++)
            {
                (*v)[n_].orthogonalize((*v)[i - 1]);
                w_j1_[i] = std::numeric_limits<T>::epsilon() * dist(gen);
            }
        }

        // for root process, sends intervals to other diagonal processes and ortogonalize current block against them
        bool orthogonalizeIntervalBlock(int a, int b, std::vector< block_diagonal_vector<T> > & bv)
        {
            bool ortho = false;
            std::normal_distribution<T> dist(0, 1.5);
            std::vector<int> interval;
            interval.push_back(a);
            interval.push_back(b);
            MPI_Bcast(interval.data(), 2, MPI_INT , 0, this->map_.dcomm());

            for (int i = a; i <= b; i++)
            {
                std::vector<T> temp;
                temp = bv[i - 1].transposed_times_other(bv[n_]);
				bv[n_].block_scaled_subtract(temp, bv[i - 1]);
                w_j1_[i] = std::numeric_limits<T>::epsilon() * dist(gen) * block_size_;
                ortho = true;
            }
            return ortho;
        }

        // root process calculates which vectors (blocks) should be used in reortogonalization
        void calculateIntervals()
        {
            for (int i = 0; i < n_; i++)
            {
                if (std::abs(w_j1_[i]) > sqrtEpsilon)
                {
                    int tmp = i;
                    
                    while (std::abs(w_j1_[tmp - 1]) > interval_limit)
                    {
                        tmp--;
                    }
                    intervals_.push_back({tmp,0});
                    tmp = i;
                    while (tmp < n_ - 1 && std::abs(w_j1_[tmp + 1]) > interval_limit)
                    {
                        tmp++;
                    }
                    intervals_.back().second = tmp;
                    i = tmp + 1;
                }
            }
        }

        // calculates errors for omega recurence
        void getErrors(std::vector<T> & errorA, T & errorB, T beta)
        {
            errorA.resize(n_);
            errorA[0] = 0;

            for (int i = 1; i < n_; i++)
                calculateErrorA(errorA[i],i,beta);
            calculateErrorB(errorB,beta);
        }

        // single vector Lanczos - calculates omega recurence
        void computeW(std::vector<T> & errorA, T errorB)
        {
            std::vector<T> tmp;
            tmp.resize(n_ + 1);
            tmp[0] = 0;
            w_j1_.resize(n_ + 1);
            w_j1_[n_] = 1;
            for (int k = 1; k <= n_ - 1; k++)
            {
                (k == 1) ? tmp[k] = beta_[k - 1] * w_j1_[k + 1] +
                            (alpha_[k - 1] - alpha_[n_ - 1]) * w_j1_[k] -
                            beta_[n_ - 2] * w_j_[k]
                        :
                tmp[k] = beta_[k - 1] * w_j1_[k + 1] +
                            (alpha_[k - 1] - alpha_[n_ - 1]) * w_j1_[k] +
                            beta_[k - 2] * w_j1_[k - 1] -
                            beta_[n_ - 2] * w_j_[k];
                tmp[k] = tmp[k] / beta_[n_ - 1];
                tmp[k] += errorA[k];
            }
            tmp[n_] = errorB;

            w_j_.swap(w_j1_);
            w_j1_.swap(tmp);
        }

        // Block Lanczos - calculates omega recurence
        void computeWBlock()
        {
            std::vector<T> tmp;
            tmp.resize(n_ + 1);
            tmp[0] = 0;
            w_j1_.resize(n_ + 1);
            w_j1_[n_] = 1;
            for (int k = 1; k <= n_ - 1; k++)
            {
                (k == 1) ? tmp[k] = beta_[k - 1] * w_j1_[k + 1] +
                                     beta_[n_ - 2] * w_j_[k] +
                            (alpha_[k - 1] + alpha_[n_ - 1]) * w_j1_[k]
                        :
                tmp[k] = beta_[k - 1] * w_j1_[k + 1] +
                            beta_[n_ - 2] * w_j_[k] +
                            (alpha_[k - 1] + alpha_[n_ - 1]) * w_j1_[k] +
                            beta_[k - 2] * w_j1_[k - 1];
                tmp[k] = tmp[k] / low_beta_[n_ - 1];
            }
            tmp[n_] = std::numeric_limits<T>::epsilon() * block_size_;
            if (n_ - 1 > 0)
                tmp[n_ - 1] = std::numeric_limits<T>::epsilon() * block_size_;
            if (n_ - 2 > 0)
                tmp[n_ - 2] = std::numeric_limits<T>::epsilon() * block_size_;

            w_j_.swap(w_j1_);
            w_j1_.swap(tmp);
        }

        void calculateErrorA(T & a, int k, T beta)
        {
            std::normal_distribution<T> dista(0, 0.3);
            a = std::numeric_limits<T>::epsilon() * (beta_[k - 1] + beta) * dista(gen) * block_size_;
            
        }
        void calculateErrorB(T & b, T beta)
        {
            std::normal_distribution<T> distb(0, 0.6);
            if (n_ != 1)
                b = std::numeric_limits<T>::epsilon() * size_of_A_ * (beta_[0] / beta) * distb(gen) * block_size_;
            else
                b = std::numeric_limits<T>::epsilon() * size_of_A_ * distb(gen) * block_size_;
            
        }

};

} // namespace ompilancz

#endif