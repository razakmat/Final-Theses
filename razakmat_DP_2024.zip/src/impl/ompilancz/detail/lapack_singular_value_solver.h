#ifndef OMPILANCZ_DETAIL_LAPACK_SINGULAR_VALUE_SOLVER_H
#define OMPILANCZ_DETAIL_LAPACK_SINGULAR_VALUE_SOLVER_H

#include <cassert>
#include <cmath>
#include <stdexcept>
#include <vector>

#include "lapack_lamch.h"
#include "../span.h"

// LAPACK routines interface:
extern "C"
{
   extern void sgesvd_(char*, char*, int*, int*, float*, int*, float*, float*, int*,
         float*, int*, float*, int*, int*);
   extern void dgesvd_(char*, char*, int*, int*, double*, int*, double*, double*, int*,
         double*, int*, double*, int*, int*);
}

// overloaded LAPACK wrappers:
inline void gesvd(char JOBU, char JOBVT, int M, int N, float* A, int LDA, float* S, float* U, int LDU,
   float* VT, int LDVT, float* WORK, int LWORK, int& INFO)
{
   sgesvd_(&JOBU, &JOBVT, &M, &N, A, &LDA, S, U, &LDU, VT, &LDVT, WORK, &LWORK, &INFO);
}
inline void gesvd(char JOBU, char JOBVT, int M, int N, double* A, int LDA, double* S, double* U, int LDU,
   double* VT, int LDVT, double* WORK, int LWORK, int& INFO)
{
   dgesvd_(&JOBU, &JOBVT, &M, &N, A, &LDA, S, U, &LDU, VT, &LDVT, WORK, &LWORK, &INFO);
}


namespace ompilancz
{

// Lapack symmetric singular value wrapper:

template <typename T>
class singular_value_solver
{
   public:
      singular_value_solver(int size)  // size - estimated maximum matrix size
      : n_(size)
      {
         // avoid unnecessary reallocations:

         A_.reserve(size * size);
         S_.reserve(size);
         WORK_.reserve(5 * size);
      }


      void solve(span<T> input)
      {

         fillA(input);
         
         S_.resize(n_);
         WORK_.resize(5 * n_);

         int INFO;

         gesvd('N','N',n_,n_,A_.data(),n_,S_.data(),nullptr,1,nullptr,1,WORK_.data(),WORK_.size(),INFO);

         if (INFO)
         {
            throw std::runtime_error("LAPACK ?gesvd failed");
         }
      }

      T value(int i) 
      {
         assert(i < n_);

         return S_[i];
      }


   private:
      int n_;    // number of rows/columns

      std::vector<T> A_;
      std::vector<T> S_; // singular values

      std::vector<T> WORK_;     // Lapack routine auxiliary space


      void fillA(span<T> input)
      {
         A_.assign(input.begin(),input.end());
      }

};

}  // namespace ompilancz

#endif
