#ifndef OMPILANCZ_DETAIL_BLOCK_DIAGONAL_VECTOR_H
#define OMPILANCZ_DETAIL_BLOCK_DIAGONAL_VECTOR_H

#include <cassert>
#include <iomanip>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include <omp.h>

#include "diagonal_vector.h"
#include "mapping.h"

namespace ompilancz
{

// block of diagonal vectors split across diagonal processes:

template <typename T>
class block_diagonal_vector
{
   public:
      block_diagonal_vector(mapping& map)
         : map_(map), mdt_( mpi_datatype<T>::get() )
      { }

      block_diagonal_vector(mapping& map, size_t s)
         : map_(map), mdt_( mpi_datatype<T>::get() )
      {
         v_.reserve(s);
      }

      // copy semantics:

      block_diagonal_vector(const block_diagonal_vector&) = default;

      block_diagonal_vector& operator=(const block_diagonal_vector& other)
      {
         if (&other != this)
         {
            assert( &map_ == &other.map_ );  // both vectors must operate on same mapping object

            v_ = other.v_;
         }

         return *this;
      }

      // move semantics:

      block_diagonal_vector(block_diagonal_vector&& other) noexcept
         : map_(other.map_), v_(std::move(other.v_)), mdt_(other.mdt_)
      { }

      block_diagonal_vector& operator=(block_diagonal_vector&& other) noexcept
      {
         if (&other != this)
         {
            assert( &map_ == &other.map_ );  // both vectors must operate on same mapping object

            v_ = std::move(other.v_);
         }

         return *this;
      }

      // properties:

      int size() const
      {
         return v_.size();
      }

      mapping & get_map()
      {
         return map_;
      }

      // vector accessors:

      diagonal_vector<T>& operator[](int i)
      {
         return v_[i];
      }

      const diagonal_vector<T>& operator[](int i) const
      {
         return v_[i];
      }

      // named member functions for easier call on pointers:
      diagonal_vector<T>& ith_vector(int i)
      {
         return v_[i];
      }

      const diagonal_vector<T>& ith_vector(int i) const
      {
         return v_[i];
      }

      // vector insrtion and removal:

      // add single with all zero elements
      void add_zero()
      {
         v_.emplace_back(map_);
      }

      // add multiple with all zero elements
      void add_multiple_zero(int n)
      {
         for (int i = 0; i < n; i++)
            v_.emplace_back(map_);
      }

      // add single with random elements
      void add_random(T a = (T)0.0, T b = (T)1.0)
      {
         v_.emplace_back(map_);
         v_.back().random(a, b);
      }

      // add single with values
      template <typename U>
      void add_span(span<U> values)
      {
         v_.emplace_back(map_);

         #pragma omp parallel for
         for (uint64_t i = 0; i < values.size(); i++)
            v_.back()[i] = values[i];
      }

      void add_diagonal(diagonal_vector<T> & other)
      {
         assert(&map_ == &other.get_map());
         v_.push_back(std::move(other));
      }

      void remove_last()
      {
         assert(v_.size() > 0);

         v_.pop_back();
      }

      void clear()
      {
         v_.clear();
      }

      // mathematical operations:

      T normalize_last()
      {
         return v_.back().normalize();
      }

      // orthogonalize last w.r.t. all preivous, and normalize
      std::pair<T, T> orthonormalize_last()
      {
         int n = v_.size();
         assert(n > 1);

         T alpha = v_[n - 1].orthogonalize(v_[n - 2]);

         for (int i = n - 3; i >= 0; i--)
            v_[n - 1].orthogonalize(v_[i]);

         T beta = v_[n - 1].normalize();

         return { alpha, beta };
      }

      std::pair<T, T> orthonormalize(int n)
      {
         assert(n < v_.size());

         T alpha = (T)0.0;
         if (n > 0)
            alpha = v_[n].orthogonalize(v_[n - 1]);

         for (int i = n - 2; i >= 0; i--)
            v_[n].orthogonalize(v_[i]);

         T beta = v_[n].normalize();

         return { alpha, beta };
      }

      // local (for process) dot product from vector other.v_[0] to vector other.v_[to] and v_[pos]
      // every process still has only their data
      void dot_product_vector(int pos, int to, span<T> res, const block_diagonal_vector& other)
      {        
         for (int j = 0; j <= to; j++)   
               res[j] = v_[pos].local_dot_product(other.v_[j]);
      }

      // result = VT*OTHER
      std::vector<T> transposed_times_other(const block_diagonal_vector& other)
      {
         int s_v = v_.size();
         int s_other_v = other.v_.size();

         std::vector<T> local_res(s_v * s_other_v);
         std::vector<T> res(s_v * s_other_v);

         #pragma omp parallel for
         for (int i = 0; i < s_other_v; i++)
            for (int j = 0; j < s_v; j++)
               local_res[s_v * i + j] = v_[j].local_dot_product(other.v_[i]);

         MPI_Allreduce(local_res.data(), res.data(), s_v * s_other_v, mdt_, MPI_SUM, map_.dcomm());
         return res;
      }

      // result = VT*OTHER
      // result is symmetric
      std::vector<T> transposed_times_other_symmetric(const block_diagonal_vector& other)
      {
         int s = v_.size();
         assert(s == other.v_.size());

         std::vector<T> local_res(s * s);
         std::vector<T> res(s * s);

         #pragma omp parallel for
         for (int i = 0; i < s; i++)
            for (int j = 0; j <= i; j++)
            {
               local_res[s * i + j] = v_[j].local_dot_product(other.v_[i]);
               local_res[s * j + i] = local_res[s * i + j];
            }

         MPI_Allreduce(local_res.data(), res.data(), s * s, mdt_, MPI_SUM, map_.dcomm());
         return res;
      }

      // result = V + OTHER
      void add(const block_diagonal_vector& other)
      {
         int m = v_.size();
         assert(v_.size() == other.v_.size());
         assert(v_[0].size() == other.v_[0].size());
         #pragma omp parallel for
         for (int j = 0; j < m; j++)
            v_[j].add(other.v_[j]);
      }

      // result = V - OTHER
      void subtract(const block_diagonal_vector& other)
      {
         int m = v_.size();
         assert(v_.size() == other.v_.size());
         assert(v_[0].size() == other.v_[0].size());
         #pragma omp parallel for
         for (int j = 0; j < m; j++)
            v_[j].subtract(other.v_[j]);
      }

      // result = V - a*OTHER
      // a is single value
      void scaled_subtract(T* alphas, const block_diagonal_vector& other)
      {
         int m = v_.size();
         uint64_t n = v_[0].size();

         #pragma omp parallel for
         for (int j = 0; j < m; j++)
            for (uint64_t i = 0; i < n; i++)
               v_[j][i] -= alphas[j] * other.v_[j][i];
      }

      // result = V - OTHER*A
      // A is matrix s*q
      void block_scaled_subtract(span<T> Alpha, const block_diagonal_vector& other)
      {
         int s = v_.size();
         int q = other.v_.size();
         assert(Alpha.size() == s * q);

         uint64_t n = v_[0].size();

         #pragma omp parallel for
         for (int k = 0; k < s; k++)
            for (uint64_t i = 0; i < n; i++)
               for(int j = 0; j < q; j++)
                  v_[k][i] -= Alpha[k * q + j] * other.v_[j][i];
      }

      // result = VT * v
      // V is v_ without last vector
      // v is last vector of v_
      void right_multiple_by_last_vector(span<T> y) const
      {
         int n = v_.size();
         assert(n > 1);

         std::vector<T> local_res(n-1);

         #pragma omp parallel for
         for (int i = 0; i < n - 1; i++)
            local_res[i] = v_[n - 1].local_dot_product(v_[i]);

         MPI_Allreduce(local_res.data(), y.data(), n - 1, mdt_, MPI_SUM, map_.dcomm());

      }

      // result = VT * U
      // V is v_ without block_size of last vectors
      // U is matrix of last block_size vectors
      void right_multiple_by_last_block_vector(span<T> y, int block_size) const
      {
         int n = v_.size();
         assert(n > 1);
         assert(block_size < n);
         assert(y.size() >= (n - block_size) * block_size);

         std::vector<T> local_res((n - block_size) * block_size);

         #pragma omp parallel for
         for (int i = 0; i < block_size; i++)
         {
            for (int j = 0; j < n - block_size; j++)
               local_res[i * (n - block_size) + j] = v_[i + n - block_size].local_dot_product(v_[j]);
         }

         MPI_Allreduce(local_res.data(), y.data(), (n - block_size) * block_size, mdt_, MPI_SUM, map_.dcomm());
      }

      // result = v - V*y
      // v is last vector of v_
      // V is v_ without last vector
      // y is vector of length size
      void scaled_subtract_from_last_vector(span<T> y)
      {
         int n = v_.back().size();
         int size = v_.size() - 1;
         assert( size == y.size());

         #pragma omp parallel for
         for (int i = 0; i < n; i++)
         {
            T res = 0;
            for (int j = 0; j < size; j++)
               res += v_[j][i] * y[j];

            v_[size][i] -= res;
         }
      }

      // result = U - V*Y
      // U is last block_size vectors of v_
      // V is v_ without last block_size of vectors
      // Y is matrix of size (size - block_size * block_size)
      void scaled_subtract_from_last_block_vector(span<T> y, int block_size)
      {
         int n = v_.back().size();
         int size = v_.size();
         assert( y.size() == (size - block_size) * block_size);

         #pragma omp parallel for
         for (int i = 0; i < block_size; i++)
         {
            for (int j = 0; j < n; j++)
            {
               for (int k = 0; k < size - block_size; k++)
               {
                  v_[i + size - block_size][j] -= v_[k][j] * y[i * (size - block_size) + k];
               }
            }
         }
      }

      // linearization of vector of blocks into one block
      void linearization_vector_of_blocks(std::vector<block_diagonal_vector<T> > & bv, int from = 0)
      {

         for (int i = from; i < bv.size(); i++)
         {            
            for (int j = 0; j < bv[i].size(); j++)
            {
               v_.push_back(std::move(bv[i][j]));
            }
         }
      }

      // return from linearization back to vector of blocks
      void createBlocks(std::vector<block_diagonal_vector<T> > & bv, int block_size)
      {
         assert(v_.size() % block_size == 0);

         int k = 0;
         for (int i = 0; i < v_.size() / block_size; i++)
         {
            bv.push_back(block_diagonal_vector<T>(map_));
            for (int j = 0; j < block_size; j++)
            {
               bv.back().v_.push_back(std::move(v_[k++]));
            }
         }
      }

      // right multiplication by n x q column-major 2-D matrix:
      block_diagonal_vector<T> right_multiply_by_nxq(span<T> Y) const
      {
         uint64_t n = v_.size();

         assert( n > 0 );
         assert( Y.size() % n == 0 );

         int q = Y.size() / n;

         uint64_t m = v_[0].size();

         block_diagonal_vector X(map_);
         X.add_multiple_zero(q);

         #pragma omp parallel for
         for (int k = 0; k < q; k++)
         {
            span<T> y(Y.data() + k * n, n);

            for (uint64_t i = 0; i < m; i++)
               for (int j = 0; j < n; j++)
                  X[k][i] += v_[j][i] * y[j];
         }

         return X;
      }

      // right multiplication by n x q column-major 2-D matrix:
      block_diagonal_vector<T> right_multiply_by_nxq_last_rows(span<T> Y, int size) const
      {
         uint64_t n = v_.size();

         int q = Y.size() / size;

         uint64_t m = v_[0].size();

         block_diagonal_vector X(map_);
         X.add_multiple_zero(q);

         #pragma omp parallel for
         for (int k = 0; k < q; k++)
         {
            span<T> y(Y.data() + k * size, size);

            for (uint64_t i = 0; i < m; i++)
               for (int j = 0; j < n; j++)
                  X[k][i] += v_[j][i] * y[j + size - n];
         }

         return X;
      }

      // right multiplication by n x q column-major 2-D matrix:
      block_diagonal_vector<T> right_multiply_by_nxq_first_rows(span<T> Y, int size) const
      {
         uint64_t n = v_.size();

         int q = Y.size() / size;

         uint64_t m = v_[0].size();

         block_diagonal_vector X(map_);
         X.add_multiple_zero(q);

         #pragma omp parallel for
         for (int k = 0; k < q; k++)
         {
            span<T> y(Y.data() + k * size, size);

            for (uint64_t i = 0; i < m; i++)
               for (int j = 0; j < n; j++)
                  X[k][i] += v_[j][i] * y[j];
         }

         return X;
      }

      // QR-factorization
      void QR_factorization(std::vector<T> & Beta)
      {
         int s = v_.size();
	      for (int i = 0; i < s; i++)
	      {
	      	for (int j = 0; j < i; j++)
	      	{
	      		T dot = v_[i].dot_product(v_[j]);
	      		Beta[i * s + j] = dot;
	      		v_[i].scaled_subtract(dot,v_[j]);
	      	}
            Beta[i * s + i] = v_[i].normalize();
	      }
      }

      // QR-factorization without storing into Beta
      void QR_factorization()
      {
         int s = v_.size();
	      for (int i = 0; i < s; i++)
	      {
	      	for (int j = 0; j < i; j++)
	      	{
	      		T dot = v_[i].dot_product(v_[j]);
	      		v_[i].scaled_subtract(dot,v_[j]);
	      	}
            v_[i].normalize();
	      }
      }
      

      template <typename U = T>
      void store_to_files(const std::string& fileprefix, const std::string& extension, int num_width = 3)
      {
         for (int i = 0; i < v_.size(); i++)
         {
            std::ostringstream os;
            os << fileprefix;
            os << std::setw(num_width) << std::setfill('0') << i + 1;
            os << "." << extension;
            v_[i].template store_to_file<U>(os.str());
         }
      }

   private:
      mapping& map_;
      std::vector< diagonal_vector<T> > v_;
      MPI_Datatype mdt_;
};

}  // namespace ompilancz

#endif
