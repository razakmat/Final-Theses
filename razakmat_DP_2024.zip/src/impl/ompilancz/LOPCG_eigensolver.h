#ifndef OMPILANCZ_LOPCG_EIGENSOLVER_H
#define OMPILANCZ_LOPCG_EIGENSOLVER_H

#include <mpi.h>

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>

#include "detail/block_diagonal_vector.h"
#include "detail/diagonal_vector.h"
#include "detail/chrono_timer.h"
#include "detail/lapack_symmetric_eigensolver.h"
#include "detail/mapping.h"
#include "detail/matrix_times_vector.h"
#include "detail/mpi_datatype.h"
#include "detail/restart.h"
#include "detail/reorthogonalization.h"

namespace ompilancz
{

template <typename T>
class LOPCG_eigensolver
{
    public:
        LOPCG_eigensolver(
                int I, int J, int N,    // process coordinates, number of diagonal processes
                uint64_t n, uint64_t m,  // process-local matrix block dimensions
                std::ostream & os = std::cout
            )
            : map_(I, J, N, n, m), mdt_( mpi_datatype<T>::get() ),
                Converged_(map_), Initial_(map_), os_(&os)
        {}

        template <typename U>
        void solve(
			U&& matvec_operator,        // process-local matrix block x vector operator
			int nev,                    // number of required eigenvalues
			int maxit,                  // maximum number of iterations for one eigenvalue
			T eps)                      // required residual accuracy
		{
            nev_ = nev;
            residuals_.resize(nev_);
            Lambda_.resize(nev_);

            if (map_.root())
				*os_ << "Starting LOPCG eigensolver..."
					<< std::endl << std::endl;

            // open file for convergence logging
			if (map_.root())
				f_conv_log_.open("eigenvalues.dat");

            // reset timers
            matvec_time_ = 0.0;
            bcast_time_ = 0.0;
            local_matvec_time_ = 0.0;
            reduce_time_ = 0.0;
            symmetric_time_ = 0.0;
            iterations_time_ = 0.0;
            iterations_.resize(nev_,0.0);

            chrono_timer solve_timer(chrono_timer::start_now);

            if (map_.root())
				sye_ = std::make_shared< symmetric_eigensolver<T> >(1);

            matrix_times_vector<T> matvec(map_);

            // main outer loop for calculations of all required eigenvalues
            for (int i = 0; i < nev_; i++)
            {
                chrono_timer iterations_timer(chrono_timer::start_now);

                // path for not diagonal processes
                if (!map_.diag())
                {
                    solve_not_diag(matvec_operator,maxit,matvec);
                    iterations_timer.stop();
                    iterations_time_ += iterations_timer.seconds();
                    iterations_[i] = iterations_timer.seconds();
                    continue;
                }
                diagonal_vector<T> x(map_);
                if (Initial_.size() - 1 >= i)
                    x = std::move(Initial_[i]);
                else
                    x.random();
				x.normalize();

                chrono_timer matvec_timer(chrono_timer::start_now);

                // Ax = A * x
                diagonal_vector<T> Ax(map_);
			    matvec.diag_setup_xy(x,Ax);
                matvec_op(matvec_operator,matvec);

                matvec_timer.stop();
                matvec_time_ += matvec_timer.seconds();

                // xtheta = x * ( x' * A * x )
                T theta = x.dot_product(Ax);
                diagonal_vector<T> xtheta(x);
                xtheta.scale(theta);


                diagonal_vector<T> r(Ax);
                diagonal_vector<T> p(map_);

                // r = A * x - x * ( x' * A * x )
                r.subtract(xtheta);

                bool stop = false;
                int j = 1;
                // inner loop for calculation one eigenvalue
                for(; j <= maxit ; j++)
                {
                    // orthonormalization of x, r, p
                    Converged_.add_diagonal(x);
                    Converged_.add_diagonal(r);
                    if (j != 1)
                        Converged_.add_diagonal(p);
                    for (int k = i; k < Converged_.size(); k++)
                        Converged_.orthonormalize(k);

                    block_diagonal_vector<T> ZT(map_);
                    ZT.add_diagonal(Converged_[i]);
                    ZT.add_diagonal(Converged_[i + 1]);
                    if (j != 1)
                        ZT.add_diagonal(Converged_[i + 2]);
                    for (int k = Converged_.size(); k > i; k--)
                        Converged_.remove_last();

                    matvec_timer.start();

                    // Ar = A * r
                    diagonal_vector<T> Ar(map_);
			        matvec.diag_setup_xy(ZT[1],Ar);
                    matvec_op(matvec_operator,matvec);

                    diagonal_vector<T> Ap(map_);
                    if (j != 1)
                    {
                        // Ap = A * p
			            matvec.diag_setup_xy(ZT[2],Ap);
                        matvec_op(matvec_operator,matvec);  
                    }

                    matvec_timer.stop();
                    matvec_time_ += matvec_timer.seconds();

                    block_diagonal_vector<T> Z(map_);
                    Z.add_diagonal(Ax);
                    Z.add_diagonal(Ar);
                    if (j != 1)
                        Z.add_diagonal(Ap);

                    // Teig = XRP' * A * XRP
                    std::vector<T> Teig;
                    Teig = ZT.transposed_times_other_symmetric(Z);

                    x = std::move(ZT[0]);
                    r = std::move(ZT[1]);
                    if (j != 1)
                        p = std::move(ZT[2]);


                    // solving eigenproblem for Teig
                    // Y - eigenvectors of Teig
                    std::vector<T> Y;
                    int size_of_vector = (j == 1) ? 2: 3;
                    if (map_.root())
                    {
                        chrono_timer symmetric_timer(chrono_timer::start_now);

                        // starts LAPACK solver
                        sye_->solve(Teig);

                        symmetric_timer.stop();
                        symmetric_time_ += symmetric_timer.seconds();

                        span<T> Temp = sye_->X();
                        Y.assign(Temp.begin(), Temp.end());
                        assert( Y.size() == size_of_vector);
                    }
                    else
                        Y.resize(size_of_vector);
                    MPI_Bcast(Y.data(), size_of_vector, mdt_, 0, map_.dcomm());

                    // calculates p for next iteration
                    // r = r * Y[1]
                    // r = r + Y[2]*p
                    r.scale(Y[1]);
                    if (j != 1)
                        r.scaled_add(Y[2],p);
                    p = std::move(r);

                    x.scale(Y[0]);
                    x.add(p);

                    // get eigenvalue to Lambda_ and send it to diagonal processes
                    if (map_.root())
                    {
                        Lambda_[i] = sye_->lambda(0);
                    }
                    MPI_Bcast(&Lambda_[i], 1, mdt_, 0, map_.dcomm());

                    matvec_timer.start();

                    // Ax = A * x;
                    Ax = std::move(Z[0]);
                    matvec.diag_setup_xy(x,Ax);
                    matvec_op(matvec_operator,matvec);

                    matvec_timer.stop();
                    matvec_time_ += matvec_timer.seconds();

                    xtheta = x;
                    xtheta.scale(Lambda_[i]);

                    // r = Ax - x lambda
                    r = Ax;
                    r.subtract(xtheta);

                    residuals_[i] = r.norm();

                    stop = true;
                    if (residuals_[i] > eps)
						stop = false;

                    if (map_.root())
                    {
                        print_Lambda(j, i);
                        log_Lambda(j, i);
                    }

                    MPI_Bcast(&stop, 1, MPI_CXX_BOOL, 0, map_.hcomm());
                    if (stop)
                        break;

                }

                // add calculated eigenvector to converged eigenvectors
                Converged_.add_diagonal(x);

                iterations_timer.stop();
                iterations_time_ += iterations_timer.seconds();
                iterations_[i] = iterations_timer.seconds();
            }

            solve_timer.stop();
            solve_time_ = solve_timer.seconds();

            if (map_.root())
                *os_ << std::endl << "...LOPCG eigensolver finished." << std::endl;

        }

        void setStream(std::ostream & os)
        {
            os_ = &os;
        }

        template <typename U = T>
	    void setInitialVectors(std::vector<std::string> & filenames, uint64_t vector_size)
	    {
	        if(!map_.diag())
	        	return;
	
	        span<U> data;
	        MPI_Datatype mdt;
	        std::vector<U> temp;
	        mdt = mpi_datatype<U>::get();
	        uint64_t offset;
	        uint64_t n = map_.n();
	        MPI_Scan(&n, &offset, 1, MPI_UINT64_T, MPI_SUM, map_.dcomm());
	        offset -= n;
	
			Initial_.clear();
	
	        for (uint i = 0; i < filenames.size(); i++)
	        {
	            MPI_File f;
	            MPI_File_open(map_.dcomm(), filenames[i].c_str(),
	               	MPI_MODE_RDONLY, MPI_INFO_NULL, &f);
	
	            if(offset < vector_size)
	            {
	               	temp.resize(n,0);
	               	data = span<U>(temp.data(),temp.size());
	
	               	MPI_File_read_at(f, offset * sizeof(U), data.data(), std::min(n,vector_size - offset), mdt, MPI_STATUS_IGNORE);
	               	Initial_.add_span(data);
	            }
                else
                    Initial_.add_zero();
	            MPI_File_close(&f);
	        }
	    }

        // final residual norms, they are stored in residuals_
        void residuals(std::ostream & os = std::cout)
        {
            if(!map_.root())
                return;
            os << std::endl;
            for (int i = 0; i < nev_; i++)
            {
                os << "Ev. " << std::right << std::setw(4) << i + 1 << " value = "
                    << std::right << std::setw(14) << std::setprecision(8) << std::fixed << Lambda_[i]
                    << ", res = " << std::scientific << std::setprecision(3) << residuals_[i] << std::endl;
            }
        }

        template <typename U = T>
        void store_eigenvectors(const std::string& fileprefix, const std::string& extension = "dat", int num_width = 3)
        {
            if (map_.diag())
                Converged_.template store_to_files<U>(fileprefix, extension, num_width);
        }

        void print_times(std::ostream & os = std::cout)
        {
            double temp[3] = { bcast_time_, reduce_time_, local_matvec_time_ };
            if (map_.root())
            {
                MPI_Reduce(MPI_IN_PLACE, temp, 2, MPI_DOUBLE, MPI_MIN, 0, map_.allcomm());
                MPI_Reduce(MPI_IN_PLACE, temp + 2, 1, MPI_DOUBLE, MPI_MAX, 0, map_.allcomm());
            }
            else
            {
                MPI_Reduce(temp, nullptr, 2, MPI_DOUBLE, MPI_MIN, 0, map_.allcomm());
                MPI_Reduce(temp + 2, nullptr, 1, MPI_DOUBLE, MPI_MAX, 0, map_.allcomm());
            }

            if (map_.root())
            {
                os << std::endl << "Root process:" << std::endl;
                os << "  Solve time: ................................... "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << solve_time_ << " [s]" << std::endl;
                os << "  Total iterations time: ........................ "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << iterations_time_ << " [s]" << std::endl;
                if (iterations_.size() == nev_)
                {
                    for (int i = 0; i < nev_; i++)
                        os << "  Iterations time for " << i+1 << ". eigenvalue: ............ "
                            << std::right << std::setw(10) << std::setprecision(2) << std::fixed << iterations_[i] << " [s]" << std::endl;
                }
                os << "  Total matvec time: ............................ "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << matvec_time_ << " [s]" << std::endl;
                os << "  Total symmetric solver time: .................. "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << symmetric_time_ << " [s]" << std::endl;


                os << "All processes:" << std::endl;
                os << "  Total maximal local matvec time: .............. "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[2] << " [s]" << std::endl;
                os << "  Total minimal broadcast communicatoin time: ... "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[0] << " [s]" << std::endl;
                os << "  Total minimal reduction communicatoin time: ... "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[1] << " [s]" << std::endl;
            }
        }

    private:
        mapping map_;   // mapping of process
        int nev_;   // number of wanted eigenvalues
        block_diagonal_vector<T> Converged_;    // eigenvectors of calculated eigenvalues
        block_diagonal_vector<T> Initial_;  // initial vectors if method setInitialVectors is used
        std::vector<T> residuals_;  // residuals of eigenvalues in Lambda_

        std::vector<T> Lambda_; // aproximations of eigenvalues, after method solve final eignevalues

        std::shared_ptr< symmetric_eigensolver<T> > sye_;   // LAPACK eigenvalues and eigenvectors solver

        MPI_Datatype mdt_;

        std::ofstream f_conv_log_;

        std::ostream * os_;

        double solve_time_;
        double iterations_time_;
        std::vector<double> iterations_;
        double matvec_time_;
        double bcast_time_;
        double local_matvec_time_;
        double reduce_time_;
        double symmetric_time_;

        // for cycle for non-diagonal processes, all operations with are matvec operator
        template <typename U>
        void solve_not_diag(U&& matvec_operator, int maxit,
                            matrix_times_vector<T> & matvec)
        {
            chrono_timer matvec_timer(chrono_timer::start_now);
            matvec_op(matvec_operator,matvec);
            matvec_timer.stop();
            matvec_time_ += matvec_timer.seconds();

            bool stop = false;
            int j = 1;
            for( ; j <= maxit; j++)
            {
                matvec_timer.start();
                matvec_op(matvec_operator,matvec);

                if (j != 1)
                {
                    matvec_op(matvec_operator,matvec);
                }

                matvec_op(matvec_operator,matvec);

                matvec_timer.stop();
                matvec_time_ += matvec_timer.seconds();

                MPI_Bcast(&stop, 1, MPI_CXX_BOOL, 0, map_.hcomm());
                if (stop)
                    break;
            }
        }

        template <typename U>
        void matvec_op(U&& matvec_operator, matrix_times_vector<T> & matvec)
        {
            chrono_timer bcast_timer(chrono_timer::start_now);
            matvec.broadcast_x();
            bcast_timer.stop();
            bcast_time_ += bcast_timer.seconds();
            chrono_timer local_matvec_timer(chrono_timer::start_now);
            matvec.multiply(matvec_operator);
            local_matvec_timer.stop();
            local_matvec_time_ += local_matvec_timer.seconds();
            chrono_timer reduce_timer(chrono_timer::start_now);
            matvec.reduce_y();
            reduce_timer.stop();
            reduce_time_ += reduce_timer.seconds();
        }

        // implementation member functions:

        void log_Lambda(int j, int nev)
        {
            // log convergence
            f_conv_log_ << "It. " << std::right << std::setw(4) << j << " - Ev. " << nev + 1 << " : ";
                log_lambda_res(Lambda_[nev], residuals_[nev]);
            f_conv_log_ << "\n";
        }

        void print_Lambda(int j, int nev)
        {
        // print currently calculating eigenvalue:

            *os_ << "It. " << std::right << std::setw(4) << j << " - Ev. " << nev + 1<< " : ";
                                        print_lambda_res(Lambda_[nev], residuals_[nev]);

            *os_ << std::endl;
        }

        void print_lambda_res(T lambda, T res)
        {
            *os_
                << std::right << std::setw(8) << std::setprecision(4) << std::fixed << lambda
                << " (" << std::scientific << std::setprecision(3) << res << ")   ";
        }

        void log_lambda_res(T lambda, T res)
        {
            f_conv_log_
                << std::right << std::setw(8) << std::setprecision(4) << std::fixed << lambda
                << " (" << std::scientific << std::setprecision(3) << res << ")   ";
        }

};
}
#endif