#ifndef OMPILANCZ_LOBPCG_EIGENSOLVER_H
#define OMPILANCZ_LOBPCG_EIGENSOLVER_H

#include <mpi.h>

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>

#include "detail/block_diagonal_vector.h"
#include "detail/chrono_timer.h"
#include "detail/lapack_symmetric_eigensolver.h"
#include "detail/mapping.h"
#include "detail/matrix_times_block_vector.h"
#include "detail/mpi_datatype.h"
#include "detail/restart.h"
#include "detail/reorthogonalization.h"

namespace ompilancz
{

template <typename T>
class LOBPCG_eigensolver
{
    public:
        LOBPCG_eigensolver(
                int I, int J, int N,    // process coordinates, number of diagonal processes
                uint64_t n, uint64_t m,  // process-local matrix block dimensions
                std::ostream & os = std::cout
            )
            : map_(I, J, N, n, m), mdt_( mpi_datatype<T>::get() ), X_(map_), os_(&os),
                Converged_(map_)
        {}

        template <typename U>
        void solve(
			U&& matvec_operator,    // process-local matrix block x block vector operator
			int nev,                // number of required eigenvalues
			int maxit,              // maximum number of iterations
			int s,                  // number of vectors in block
			T eps)                  // required residual accuracy
		{
            nev_ = nev;
            assert(s >= nev);
            s_ = s;
            residuals_.resize(nev_);
            Lambda_.resize(s_);
            cnt_converged = 0;

            if (map_.root())
				*os_ << "Starting LOBPCG eigensolver..."
					<< std::endl << std::endl;

            // open file for convergence logging
			if (map_.root())
				f_conv_log_.open("eigenvalues.dat");

            // reset timers
            matvec_time_ = 0.0;
            bcast_time_ = 0.0;
            local_matvec_time_ = 0.0;
            reduce_time_ = 0.0;
            symmetric_time_ = 0.0;

            chrono_timer solve_timer(chrono_timer::start_now);

            if (map_.diag() && X_.size() == 0)
			{

				// setup initial Lanczos vectors:
				X_.add_random();
				X_.normalize_last();

				for (int k = 1; k < s_; k++)
				{
					X_.add_random();
					X_.orthonormalize_last();
				}
			}
            else if (map_.diag() && X_.size() != 0)
			{
				assert(X_.size() <= s_);
                for (int k = 0; k < X_.size(); k++)
                    X_.orthonormalize(k);
                for (int k = X_.size(); k < s_; k++)
				{
					X_.add_random();
					X_.orthonormalize_last();
				}
			}

            if (map_.root())
				sye_ = std::make_shared< symmetric_eigensolver<T> >(s_);

            // setup block sizes for matvec
            // after first iteration size for matvecRP will be set to s_ * 2
            matrix_times_block_vector<T> matvecX(map_);
			matvecX.set_block_size(s_);
            matrix_times_block_vector<T> matvecRP(map_);
			matvecRP.set_block_size(s_);

            // path for not diagonal processes
            if (!map_.diag())
            {
                solve_not_diag(matvec_operator,maxit,matvecX,matvecRP);

                solve_timer.stop();
                solve_time_ = solve_timer.seconds();
                return;
            }

            chrono_timer iterations_timer(chrono_timer::start_now);

            chrono_timer matvec_timer(chrono_timer::start_now);

            // AX = A * X
            block_diagonal_vector<T> AX(map_,s_);
            AX.add_multiple_zero(s_);
			matvecX.diag_setup_xy(&X_,&AX);
            matvec_op(matvec_operator,matvecX);

            matvec_timer.stop();
            matvec_time_ += matvec_timer.seconds();


            // XTheta = X * ( X' * A * X )
            std::vector<T> Theta(s_ * s_);
            Theta = X_.transposed_times_other_symmetric(AX);
            block_diagonal_vector<T> XTheta(map_,s_);
            XTheta = X_.right_multiply_by_nxq(Theta);
            

            block_diagonal_vector<T> R(map_);
            block_diagonal_vector<T> P(map_);

            // R = A * X - X * ( X' * A * X )
            R = AX;
            R.subtract(XTheta);


            bool stop = false;
            int j = 1;
            // main loop
            for( ; j <= maxit; j++)
            {
                
                std::vector<block_diagonal_vector<T> > mix;
                mix.push_back(std::move(X_));
                mix.push_back(std::move(R));
                mix.push_back(std::move(P));
                block_diagonal_vector<T> Z(map_);
                Z.linearization_vector_of_blocks(mix);
                mix.clear();

                // orthonormalization of X, R, P
                Z.QR_factorization();

                if (Converged_.size() != 0)
                {
                    std::vector<T> temp;
                    temp = Converged_.transposed_times_other(Z);
				    Z.block_scaled_subtract(temp, Converged_);
                }

                block_diagonal_vector<T> RP(map_);
                Z.createBlocks(mix,(s_ - cnt_converged));
                Z.clear();
                
                RP.linearization_vector_of_blocks(mix,1);
                X_ = std::move(mix[0]);
                mix.clear();

                matvec_timer.start();

                // ARP = A * [R P]
                block_diagonal_vector<T> ARP(map_);
                ARP.add_multiple_zero((j == 1) ? (s_ - cnt_converged) : (s_ - cnt_converged) * 2);
                matvecRP.diag_setup_xy(&RP,&ARP);
                matvec_op(matvec_operator,matvecRP);

                matvec_timer.stop();
                matvec_time_ += matvec_timer.seconds();

                mix.push_back(std::move(AX));
                mix.push_back(std::move(ARP));

                // AXARP = A * XRP
                block_diagonal_vector<T> AXARP(map_);
                AXARP.linearization_vector_of_blocks(mix);
                mix.clear();

                mix.push_back(std::move(X_));
                mix.push_back(std::move(RP));

                Z.linearization_vector_of_blocks(mix);
                mix.clear();

                // Teig = XRP' * A * XRP
                std::vector<T> Teig;
                Teig = Z.transposed_times_other_symmetric(AXARP);

                Z.createBlocks(mix,(s_ - cnt_converged));
                Z.clear();

                X_ = std::move(mix[0]);
                RP.linearization_vector_of_blocks(mix,1);
                mix.clear();

                // solving eigenproblem for Teig
                // Y - eigenvectors of Teig
                std::vector<T> Y;
                int size_of_vector = (j == 1) ? 2 * (s_ - cnt_converged) : 3 * (s_ - cnt_converged);
                if (map_.root())
                {
                    chrono_timer symmetric_timer(chrono_timer::start_now);

                    // starts LAPACK solver
                    sye_->solve(Teig);

                    symmetric_timer.stop();
                    symmetric_time_ += symmetric_timer.seconds();

                    span<T> Temp = sye_->X();
                    Y.assign(Temp.begin(), Temp.end());

                    assert( Y.size() == size_of_vector * (s_ - cnt_converged));
                }
                else
                    Y.resize((s_ - cnt_converged) * size_of_vector);
                MPI_Bcast(Y.data(), (s_ - cnt_converged) * size_of_vector, mdt_, 0, map_.dcomm());

                // P = RP * last rows of Y (corresponding to R and P)
                P = RP.right_multiply_by_nxq_last_rows(Y,size_of_vector);
                // X = X * Y
                // first uncalculated part of Y and then adding P
                X_ = X_.right_multiply_by_nxq_first_rows(Y,size_of_vector);
                X_.add(P);


                // get eigenvalues to Lambda_ and send it to diagonal processes
                if (map_.root())
                    for (int i = 0; i < (s_ - cnt_converged); i++)
                        Lambda_[i + cnt_converged] = sye_->lambda(i);
                MPI_Bcast(Lambda_.data() + cnt_converged, (s_ - cnt_converged), mdt_, 0, map_.dcomm());

                // XTheta = X * diagonal matrix with eigenvalues
                XTheta = X_;
                for (int i = 0; i < (s_ - cnt_converged); i++)
                    XTheta[i].scale(Lambda_[i + cnt_converged]);
                
                matvec_timer.start();

                // AX = A * X;
                AX.add_multiple_zero((s_ - cnt_converged));
                matvecX.diag_setup_xy(&X_,&AX);
                matvec_op(matvec_operator,matvecX);

                matvec_timer.stop();
                matvec_time_ += matvec_timer.seconds();

                // R = A * X - X * diagonal matrix with eigenvalues
                R = AX;
                R.subtract(XTheta);

                // calculating residuals
                for (int i = 0; i < nev_ - cnt_converged; i++)
                {
                    residuals_[i + cnt_converged] = R[i].norm();
                }

                // check convergence:
				stop = true;
				for (int i = cnt_converged; i < nev_; i++)
					if (residuals_[i] > eps)
						stop = false;

                if (map_.root())
                {
                    print_Lambda(j);
                    log_Lambda(j);
                }

                // computes locking
                if (locking(P,R,AX,eps))
                {
                    matvecX.set_block_size(s_ - cnt_converged);
                    matvecRP.set_block_size((s_ - cnt_converged) * 2);
                    if (map_.root())
                        sye_->reset_size(s_ - cnt_converged);
                }
                MPI_Bcast(&cnt_converged, 1, MPI_INT, 0, map_.hcomm());

                // stop iterating if convergence has been reached:
                MPI_Bcast(&stop, 1, MPI_CXX_BOOL, 0, map_.hcomm());
                if (stop)
                    break;

                if (j == 1)
                    matvecRP.set_block_size((s_ - cnt_converged) * 2);
            }

            iterations_timer.stop();
            iterations_time_ = iterations_timer.seconds();

            for (int i = Lambda_.size(); i > nev_; i--)
                Lambda_.pop_back();
            X_ = std::move(Converged_);

            
            solve_timer.stop();
            solve_time_ = solve_timer.seconds();

            if (map_.root())
                *os_ << std::endl << "...LOBPCG eigensolver finished." << std::endl;

        }

        void setStream(std::ostream & os)
        {
            os_ = &os;
        }

        template <typename U = T>
	    void setInitialBlock(std::vector<std::string> & filenames, uint64_t vector_size)
	    {
	        if(!map_.diag())
	        	return;
	
	        span<U> data;
	        MPI_Datatype mdt;
	        std::vector<U> temp;
	        mdt = mpi_datatype<U>::get();
	        uint64_t offset;
	        uint64_t n = map_.n();
	        MPI_Scan(&n, &offset, 1, MPI_UINT64_T, MPI_SUM, map_.dcomm());
	        offset -= n;
	
            X_.clear();
	
	        for (uint i = 0; i < filenames.size(); i++)
	        {
	            MPI_File f;
	            MPI_File_open(map_.dcomm(), filenames[i].c_str(),
	               	MPI_MODE_RDONLY, MPI_INFO_NULL, &f);

	            if(offset < vector_size)
	            {
	               	temp.resize(n,0);
	               	data = span<U>(temp.data(),temp.size());
	
	               	MPI_File_read_at(f, offset * sizeof(U), data.data(), std::min(n,vector_size - offset), mdt, MPI_STATUS_IGNORE);
	               	X_.add_span(data);
	            }
                else
                    X_.add_zero();
	            MPI_File_close(&f);
	        }

	    }

        // final residual norms, they are stored in residuals_
        void residuals(std::ostream & os = std::cout)
        {
            if(!map_.root())
                return;
            os << std::endl;
            for (int i = 0; i < nev_; i++)
            {
                os << "Ev. " << std::right << std::setw(4) << i + 1 << " value = "
                    << std::right << std::setw(14) << std::setprecision(8) << std::fixed << Lambda_[i]
                    << ", res = " << std::scientific << std::setprecision(3) << residuals_[i] << std::endl;
            }
        }

        template <typename U = T>
        void store_eigenvectors(const std::string& fileprefix, const std::string& extension = "dat", int num_width = 3)
        {
            if (map_.diag())
                X_.template store_to_files<U>(fileprefix, extension, num_width);
        }

        void print_times(std::ostream & os = std::cout)
        {
            double temp[3] = { bcast_time_, reduce_time_, local_matvec_time_ };
            if (map_.root())
            {
                MPI_Reduce(MPI_IN_PLACE, temp, 2, MPI_DOUBLE, MPI_MIN, 0, map_.allcomm());
                MPI_Reduce(MPI_IN_PLACE, temp + 2, 1, MPI_DOUBLE, MPI_MAX, 0, map_.allcomm());
            }
            else
            {
                MPI_Reduce(temp, nullptr, 2, MPI_DOUBLE, MPI_MIN, 0, map_.allcomm());
                MPI_Reduce(temp + 2, nullptr, 1, MPI_DOUBLE, MPI_MAX, 0, map_.allcomm());
            }

            if (map_.root())
            {
                os << std::endl << "Root process:" << std::endl;
                os << "  Solve time: ................................... "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << solve_time_ << " [s]" << std::endl;
                os << "  Total iterations time: ........................ "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << iterations_time_ << " [s]" << std::endl;
                os << "  Total matvec time: ............................ "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << matvec_time_ << " [s]" << std::endl;
                os << "  Total symmetric solver time: .................. "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << symmetric_time_ << " [s]" << std::endl;


                os << "All processes:" << std::endl;
                os << "  Total maximal local matvec time: .............. "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[2] << " [s]" << std::endl;
                os << "  Total minimal broadcast communicatoin time: ... "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[0] << " [s]" << std::endl;
                os << "  Total minimal reduction communicatoin time: ... "
                    << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[1] << " [s]" << std::endl;
            }
        }

    private:
        mapping map_; // mapping of process
        int nev_;  // number of wanted eigenvalues
        int s_;  // size of block
        block_diagonal_vector<T> Converged_; // eigenvectors of converged eigenvalues
        int cnt_converged;  // number of currently converged eignevalues
        block_diagonal_vector<T> X_; // after method solve holds final eigenvectors
        std::vector<T> residuals_; // residuals of eigenvalues in Lambda_

        std::vector<T> Lambda_; // aproximations of eigenvalues, after method solve final eignevalues

        std::shared_ptr< symmetric_eigensolver<T> > sye_; // LAPACK eigenvalues and eigenvectors solver

        MPI_Datatype mdt_;

        std::ofstream f_conv_log_;

        std::ostream * os_;

        double solve_time_;
        double iterations_time_;
        double matvec_time_;
        double bcast_time_;
        double local_matvec_time_;
        double reduce_time_;
        double symmetric_time_;

        // removes converged eignevalues and eigenvectors from active calculations
        bool locking(block_diagonal_vector<T> & P, block_diagonal_vector<T> & R,
                    block_diagonal_vector<T> & AX, T eps)
        {
            int locks = 0;
            for (int i = cnt_converged; i < nev_; i++)
					if (residuals_[i] <= eps)
                        locks++;
                    else
                        break;
            if (locks == 0)
                return false;

            for (int i = 0; i < locks; i++)
            {
                Converged_.add_diagonal(X_[i]);
                Converged_[cnt_converged + i].normalize();
            }
            
            clear_first_vectors(X_,locks);
            clear_first_vectors(P,locks);
            clear_first_vectors(R,locks);
            clear_first_vectors(AX,locks);
            
            cnt_converged += locks;
            return true;
        }

        void clear_first_vectors(block_diagonal_vector<T> & X, int num)
        {
            block_diagonal_vector<T> Temp(map_);
            Temp = std::move(X);
            X.clear();
            for (int i = num; i < s_ - cnt_converged; i++)
                X.add_diagonal(Temp[i]);
        }


        // for cycle for non-diagonal processes, all operations are with matvec operator
        template <typename U>
        void solve_not_diag(U&& matvec_operator, int maxit,
                            matrix_times_block_vector<T> & matvecX, matrix_times_block_vector<T> & matvecRP)
        {
            chrono_timer iterations_timer(chrono_timer::start_now);

            chrono_timer matvec_timer(chrono_timer::start_now);
            matvec_op(matvec_operator,matvecX);
            matvec_timer.stop();
            matvec_time_ += matvec_timer.seconds();

            bool stop = false;
            int j = 1;
            for( ; j <= maxit; j++)
            {
                matvec_timer.start();
                matvec_op(matvec_operator,matvecRP);
                matvec_timer.stop();
                matvec_time_ += matvec_timer.seconds();

                matvec_timer.start();
                matvec_op(matvec_operator,matvecX);
                matvec_timer.stop();
                matvec_time_ += matvec_timer.seconds();

                int before = cnt_converged;
                MPI_Bcast(&cnt_converged, 1, MPI_INT, 0, map_.hcomm());
                if (before != cnt_converged)
                {
                    matvecX.set_block_size(s_ - cnt_converged);
                    matvecRP.set_block_size((s_ - cnt_converged) * 2);
                }

                MPI_Bcast(&stop, 1, MPI_CXX_BOOL, 0, map_.hcomm());
                if (stop)
                    break;

                if (j == 1)
                    matvecRP.set_block_size((s_ - cnt_converged) * 2);
            }

            iterations_timer.stop();
            iterations_time_ = iterations_timer.seconds();
        }

        template <typename U>
        void matvec_op(U&& matvec_operator, matrix_times_block_vector<T> & matvec)
        {
            chrono_timer bcast_timer(chrono_timer::start_now);
            matvec.broadcast_X();
            bcast_timer.stop();
            bcast_time_ += bcast_timer.seconds();
            chrono_timer local_matvec_timer(chrono_timer::start_now);
            matvec.multiply(matvec_operator);
            local_matvec_timer.stop();
            local_matvec_time_ += local_matvec_timer.seconds();
            chrono_timer reduce_timer(chrono_timer::start_now);
            matvec.reduce_Y();
            reduce_timer.stop();
            reduce_time_ += reduce_timer.seconds();
        }

        // implementation member functions:

        void log_Lambda(int j)
        {
            // log convergence
            f_conv_log_ << "It. " << std::right << std::setw(4) << j << "  ";
            for (int i = 0; i < nev_; i++)
                log_lambda_res(Lambda_[i], residuals_[i]);
            f_conv_log_ << "\n";
        }

        void print_Lambda(int j)
        {
        // print current 1st, 2nd, and nev-th eigenvalues:

            *os_ << "It. " << std::right << std::setw(4) << j << " - Ev. (from " << cnt_converged + 1<<"): ";
                                        print_lambda_res(Lambda_[0 + cnt_converged], residuals_[0 + cnt_converged]);
            if (nev_ > 1 + cnt_converged) print_lambda_res(Lambda_[1 + cnt_converged], residuals_[1 + cnt_converged]);
            if (nev_ > 2 + cnt_converged) print_lambda_res(Lambda_[nev_ - 1], residuals_[nev_ - 1]);

            *os_ << std::endl;
        }

        void print_lambda_res(T lambda, T res)
        {
            *os_
                << std::right << std::setw(8) << std::setprecision(4) << std::fixed << lambda
                << " (" << std::scientific << std::setprecision(3) << res << ")   ";
        }

        void log_lambda_res(T lambda, T res)
        {
            f_conv_log_
                << std::right << std::setw(8) << std::setprecision(4) << std::fixed << lambda
                << " (" << std::scientific << std::setprecision(3) << res << ")   ";
        }

};
}
#endif