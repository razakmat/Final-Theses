#ifndef OMPILANCZ_BLOCK_EIGENSOLVER_H
#define OMPILANCZ_BLOCK_EIGENSOLVER_H

#include <mpi.h>

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>

#include "detail/block_diagonal_vector.h"
#include "detail/chrono_timer.h"
#include "detail/lapack_block_tridiagonal_eigensolver.h"
#include "detail/mapping.h"
#include "detail/matrix_times_block_vector.h"
#include "detail/mpi_datatype.h"
#include "detail/restart.h"
#include "detail/reorthogonalization.h"

namespace ompilancz
{

// block Lanczos eigensolver:

template <typename T>
class Lanczos_block_eigensolver
{
	public:
		Lanczos_block_eigensolver(
            	int I, int J, int N,    // process coordinates, number of diagonal processes
            	uint64_t n, uint64_t m,  // process-local matrix block dimensions
				std::ostream & os = std::cout
        	)
         	: map_(I, J, N, n, m), mdt_( mpi_datatype<T>::get() ), X_(map_) , os_(&os)
      	{ 
			restart_ = nullptr;
			ortho_ = std::make_shared< fullOrtho<T> >(I,J,N,n,m);
			bv_.clear();
		}

      	template <typename U>
		void solve(
			U&& matvec_operator,	// process-local matrix block x block vector operator
			int nev, 				// number of required eigenvalues
			int maxit,				// maximum number of iterations
			int s,  				// number of vectors in block
			T eps)					// required residual accuracy
		{
			nev_ = nev;
			s_ = s;

			if (map_.root())
				*os_ << "Starting OMPILancz block-vector eigensolver..."
					<< std::endl << std::endl;
			
			// open file for convergence logging
			if (map_.root())
				f_conv_log_.open("eigenvalues.dat");

			// reset timers
         	matvec_time_ = 0.0;
         	bcast_time_ = 0.0;
         	local_matvec_time_ = 0.0;
         	reduce_time_ = 0.0;
         	reorthog_time_ = 0.0;
         	restart_time_ = 0.0;
         	tridiag_time_ = 0.0;

			chrono_timer solve_timer(chrono_timer::start_now);

			// setup data structure for Lanczos diagonal vectors:
			if (map_.diag() && bv_.empty())
			{
				bv_.emplace_back(map_,s_);

				// setup initial Lanczos vectors:
				bv_.back().add_random();
				bv_.back().normalize_last();

				for (int k = 1; k < s_; k++)
				{
					bv_.back().add_random();
					bv_.back().orthonormalize_last();
				}
			}
			else if (map_.diag() && !bv_.empty())
			{
				assert(bv_.size() == 1);
				assert(bv_[0].size() == s_);
			}

			if (map_.root())
				btde_ = std::make_shared< block_tridiagonal_eigensolver<T> >(s_, maxit);
			
			// setup of restart
			if (map_.diag() && restart_ != nullptr)
         	{
         	   restart_->setup(eps,nev_,locking_,s_);
         	}
			// setup of ortogonalization
			if (map_.root())
				ortho_->setup(btde_);


			matrix_times_block_vector<T> matvec(map_);
			matvec.set_block_size(s_);

			bool stop = false;

			chrono_timer iterations_timer(chrono_timer::start_now);

			int j = 1;
			int iter = 1;
			// without restart j and iter are same
			// main loop
			for( ; iter <= maxit; iter++, j++)
			{
				// additional Lanczos vectors (block)
				if (map_.diag())
                {
                    bv_.emplace_back(map_, s_);
                    bv_.back().add_multiple_zero(s_);
                }

				// U_j <- A * V_(j-1):

				chrono_timer matvec_timer(chrono_timer::start_now);

				if (map_.diag())
					matvec.diag_setup_xy(&bv_.operator[](j-1),&bv_.operator[](j));
				
				chrono_timer bcast_timer(chrono_timer::start_now);
				matvec.broadcast_X();
				bcast_timer.stop();
				bcast_time_ += bcast_timer.seconds();

				chrono_timer local_matvec_timer(chrono_timer::start_now);
				matvec.multiply(matvec_operator);
				local_matvec_timer.stop();
				local_matvec_time_ += local_matvec_timer.seconds();

				chrono_timer reduce_timer(chrono_timer::start_now);
				matvec.reduce_Y();
				reduce_timer.stop();
				reduce_time_ += reduce_timer.seconds();

				matvec_timer.stop();
				matvec_time_ += matvec_timer.seconds();

				// only for diag processes
				if (map_.diag())
				{

					// reorthogonalization:
					chrono_timer reorthog_timer(chrono_timer::start_now);
					std::vector<T> Alpha;
					std::vector<T> Beta(s_ * s_);
					ortho_->orthonormalize(bv_,Alpha,Beta);

					reorthog_timer.stop();
					reorthog_time_ += reorthog_timer.seconds();

					// solve projected tridiagonal eigenproblem:
					bool block_converged = false;
					if (map_.root())
					{

						chrono_timer tridiag_timer(chrono_timer::start_now);

						// starts LAPACK solver
						btde_->append_AlphaBeta(Alpha,Beta);
						btde_->solve(nev);

						tridiag_timer.stop();
						tridiag_time_ += tridiag_timer.seconds();

						// check convergence:
						if (j * s_ >= nev)
						{
							stop = true;

							for (int i = 0; i < nev; i++)
								if (btde_->res(i) > eps)
									stop = false;
						}
						// checks if first s eigenvalues are converged for restart
						if (j >= s_)
						{
							block_converged = true;
							for (int i = 0; i < s_; i++)
								if (btde_->res(i) > eps)
									block_converged = false;
						}

						print_block_lambda(*btde_, j, s_, iter, nev); // log

						log_Lambda(j,s_,iter, nev);
					}

					MPI_Bcast(&stop, 1, MPI_CXX_BOOL, 0, map_.dcomm());
					MPI_Bcast(&block_converged, 1, MPI_CXX_BOOL, 0, map_.dcomm());

					// checks if restart could be called
					if (restart_ != nullptr && stop == false && iter != maxit)
               		{
						chrono_timer restart_timer(chrono_timer::start_now);
						// checks if restart should be called
						if ((locking_ && block_converged) || j == restart_iteration_)
						{
							restart_->execute(bv_, btde_, j);
							nev = restart_->getNewNev();
						}
						//resets iteration step after restart
               		    j = bv_.size() - 1;

						restart_timer.stop();
                  		restart_time_ += restart_timer.seconds();
               		}
				}

				// stop iterating if convergence has been reached:
				MPI_Bcast(&stop, 1, MPI_CXX_BOOL, 0, map_.allcomm());
				if (stop)
					break;
			}

			// last iteration index:
         	assert(iter <= maxit + 1);
			n_ = j * s_;

			iterations_timer.stop();
         	iterations_time_ = iterations_timer.seconds();


			// obtain resulting eigenpairs on diagonal processes:
            if (map_.diag())
            {
				if (bv_.size() == j)
               		j--;
				n_ = j * s_;

                assert(bv_.size() == j + 1);
                bv_.pop_back();  // not needed anymore
                assert(bv_.size() == j);

				chrono_timer reconstr_timer(chrono_timer::start_now);

                diags_get_eigenvalues();
                diags_get_eigenvectors(nev);

				reconstr_timer.stop();
				reconstr_time_ = reconstr_timer.seconds();
            }

			solve_timer.stop();
			solve_time_ = solve_timer.seconds();

            if (map_.root())
                *os_ << "...block-vector eigensolver finished." << std::endl;

		}

		void setStream(std::ostream & os)
      	{
			os_ = &os;
      	}

		void setupRestart(std::shared_ptr< restart<T> > restart, int start_iteration, bool locking)
      	{
      	   	restart_ = restart;
		   	restart_iteration_ = start_iteration;
        	locking_ = locking;
      	}

		void setupReorthogonalization(std::shared_ptr< reorthogonalization<T> > ortho)
      	{
      		ortho_ = ortho;
      	}

	    template <typename U = T>
	    void setInitialBlock(std::vector<std::string> & filenames, uint64_t vector_size)
	    {
	        if(!map_.diag())
	        	return;
	
	        span<U> data;
	        MPI_Datatype mdt;
	        std::vector<U> temp;
	        mdt = mpi_datatype<U>::get();
	        uint64_t offset;
	        uint64_t n = map_.n();
	        MPI_Scan(&n, &offset, 1, MPI_UINT64_T, MPI_SUM, map_.dcomm());
	        offset -= n;
	        offset *= sizeof(U);
	
			bv_.emplace_back(map_,filenames.size());
	
	        for (uint i = 0; i < filenames.size(); i++)
	        {
	            MPI_File f;
	            MPI_File_open(map_.dcomm(), filenames[i].c_str(),
	               	MPI_MODE_RDONLY, MPI_INFO_NULL, &f);
	
	            if(offset < vector_size)
	            {
	               	temp.resize(n,0);
	               	data = span<U>(temp.data(),temp.size());
	
	               	MPI_File_read_at(f, offset, data.data(), std::min(n,vector_size - offset), mdt, MPI_STATUS_IGNORE);
	               	bv_.back().add_span(data);
					bv_.back().orthonormalize(i);
	            }
				else
					bv_.back().emplace_back(map_);
	            MPI_File_close(&f);
	        }
	    }

		// final residual norms ||A X_i - Lambda_i X_i||_2 for i=1,...,nev
        template <typename U>
        void residuals(U&& matvec_operator, std::ostream & os = std::cout)
        {
			chrono_timer residuals_timer(chrono_timer::start_now);

			std::unique_ptr< block_diagonal_vector<T> > R;
			if (map_.diag())
			{
				R = std::make_unique< block_diagonal_vector<T> >(map_);
				R->add_multiple_zero(nev_);
			}
		

            matrix_times_block_vector<T> matvec(map_);

            if (map_.root())
                os << std::endl;
            
			// R_i <- A * X_i :
            matvec.set_block_size(nev_);
            if (map_.diag())
                matvec.diag_setup_xy(&X_,R.get());
            matvec.broadcast_X();
            matvec.multiply(matvec_operator);
            matvec.reduce_Y();

            if (!map_.diag())
                return;
            
            // R <- R - Lambda * X :
            R->scaled_subtract(Lambda_.data(), X_);

            for (int i = 0; i < nev_; i++)
            {
                T r_norm = (*R)[i].norm();

                if (map_.root())
                    os << "Ev. " << std::right << std::setw(4) << i + 1 << " value = "
                        << std::right << std::setw(14) << std::setprecision(8) << std::fixed << Lambda_[i]
                        << ", res = " << std::scientific << std::setprecision(3) << r_norm << std::endl;
            }
			residuals_timer.stop();
			residuals_time_ = residuals_timer.seconds();
        }

		template <typename U = T>
      	void store_eigenvectors(const std::string& fileprefix, const std::string& extension = "dat", int num_width = 3)
      	{
         	if (map_.diag())
            	X_.template store_to_files<U>(fileprefix, extension, num_width);
      	}

		void print_times(std::ostream & os = std::cout)
      	{
	        double temp[3] = { bcast_time_, reduce_time_, local_matvec_time_ };
	        if (map_.root())
	        {
	        	MPI_Reduce(MPI_IN_PLACE, temp, 2, MPI_DOUBLE, MPI_MIN, 0, map_.allcomm());
	            MPI_Reduce(MPI_IN_PLACE, temp + 2, 1, MPI_DOUBLE, MPI_MAX, 0, map_.allcomm());
	        }
	        else
	        {
	            MPI_Reduce(temp, nullptr, 2, MPI_DOUBLE, MPI_MIN, 0, map_.allcomm());
	            MPI_Reduce(temp + 2, nullptr, 1, MPI_DOUBLE, MPI_MAX, 0, map_.allcomm());
	        }

	        if (map_.root())
	        {
	            os << std::endl << "Root process:" << std::endl;
	            os << "  Solve time: ................................... "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << solve_time_ << " [s]" << std::endl;
	            os << "  Total iterations time: ........................ "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << iterations_time_ << " [s]" << std::endl;
	            os << "  Total matvec time: ............................ "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << matvec_time_ << " [s]" << std::endl;
	            os << "  Total reorthogonalization time: ............... "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << reorthog_time_ << " [s]" << std::endl;
	            if (restart_time_ > 0.0)
	               	os << "  Total restart time: ........................... "
	                  	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << restart_time_ << " [s]" << std::endl;
	            os << "  Total tridiagonal solver time: ................ "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << tridiag_time_ << " [s]" << std::endl;
	            os << "  Eigenvectors reconstruction time: ............. "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << reconstr_time_ << " [s]" << std::endl;

	            if (residuals_time_ > 0.0)
	               	os << "  Residual evaluation time: ..................... "
	                  	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << reconstr_time_ << " [s]" << std::endl;

	            os << "All processes:" << std::endl;
	            os << "  Total maximal local matvec time: .............. "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[2] << " [s]" << std::endl;
	            os << "  Total minimal broadcast communicatoin time: ... "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[0] << " [s]" << std::endl;
	            os << "  Total minimal reduction communicatoin time: ... "
	               	<< std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[1] << " [s]" << std::endl;
        	}
      	}

	private:
		mapping map_; // mapping of process
		
		int nev_; // number of wanted eigenvalues

		int s_; // size of block

		int n_; // final number of Lanczos vectors

		std::vector< block_diagonal_vector<T> > bv_;  // Lanczos vectors

		std::shared_ptr< block_tridiagonal_eigensolver<T> > btde_; // LAPACK eigenvalues and eigenvectors solver

		std::vector<T> Lambda_; // final eigenvalues
		block_diagonal_vector<T> X_; // must be placed after map_, final eigenvectors

		MPI_Datatype mdt_;

		std::shared_ptr< restart<T> > restart_;
		std::shared_ptr< reorthogonalization<T> > ortho_;

		double solve_time_;
      	double iterations_time_;
      	double matvec_time_;
      	double bcast_time_;
      	double local_matvec_time_;
      	double reduce_time_;
      	double reorthog_time_;
      	double restart_time_;
      	double tridiag_time_;
      	double reconstr_time_;
      	double residuals_time_ = 0.0;

		int restart_iteration_;
		bool locking_;

		std::ofstream f_conv_log_;
		std::ostream * os_;

		void log_Lambda(int j, int s, int iter, int nev)
      	{
      	   	// log convergence
      	   	f_conv_log_ << "It. " << std::right << std::setw(4) << iter << "  ";
      	   	for (int i = 0; i < std::min(j * s, nev) - (nev_ - nev); i++)
      	      	log_lambda_res(btde_->lambda(i), btde_->res(i));
      	   	f_conv_log_ << "\n";
      	}

		void log_lambda_res(T lambda, T res)
      	{
      	   	f_conv_log_
      	      	<< std::right << std::setw(8) << std::setprecision(4) << std::fixed << lambda
      	      	<< " (" << std::scientific << std::setprecision(3) << res << ")   ";
      	}

    	void print_block_lambda(block_tridiagonal_eigensolver<T>& btde, int j, int s, int iter, int nev)
      	{
			if (nev_ - nev == 0)
         		*os_ << "It. " << std::right << std::setw(4) << iter << " - Ev.: ";
			else
				*os_ << "It. " << std::right << std::setw(4) << iter << " - Ev. (from " << nev_ - nev + 1 <<"): ";

         	print_lambda_res_ith(btde, j, 0);
         	if (j * s > 1 && nev > 1)
            	print_lambda_res_ith(btde, j, 1); 
         	if ((j * s >= nev + (nev_ - nev)) && (nev > 2))
            	print_lambda_res_ith(btde, j, nev - 1);

         	*os_ << std::endl;
      	}

      	void print_lambda_res_ith(block_tridiagonal_eigensolver<T>& btde, int j, int i)
      	{
         	*os_ << std::right << std::setw(8) << std::setprecision(4) << std::fixed << btde.lambda(i)
            	<< " (" << std::scientific << std::setprecision(3) << btde.res(i) << ")   ";
      	}

        void diags_get_eigenvalues()
        {
            assert (map_.diag());

            if (map_.root())
            {
				if (restart_ != nullptr)
               		restart_->getEigenvalues(Lambda_);

                span<T> Lambda = btde_->Lambda();
				for (auto & x : Lambda)
					Lambda_.push_back(x);

                assert(Lambda_.size() == nev_);
            }
            else
                Lambda_.resize(nev_);
            
            MPI_Bcast(Lambda_.data(), nev_, mdt_, 0, map_.dcomm());

        }
        void diags_get_eigenvectors(int nev)
        {
            assert (map_.diag());

			// broadcast projected eigenvectors to diagonal processes:

			int size_of_Y = nev * (n_ - (nev_ - nev));

            std::vector<T> Y;
            if (map_.root())
            {
                span<T> Temp = btde_->X();
                Y.assign(Temp.begin(), Temp.end());

                assert( Y.size() == size_of_Y );
            }
            else
                Y.resize(size_of_Y);

            MPI_Bcast(Y.data(), size_of_Y, mdt_, 0, map_.dcomm());
			
			// X <- Lanczos vectors * Y:

            block_diagonal_vector<T> Tmp(map_);

			Tmp.linearization_vector_of_blocks(bv_);

            assert( Tmp.size() == n_);

			// dealing with the already locked and computed vectors in v_
			if (restart_ != nullptr)
			{
				// keep already locked vectors in tmp and move active ones to active
				block_diagonal_vector<T> active(map_);
				for (int i = nev_ - nev; i < n_; i++)
                	active.add_diagonal(Tmp[i]);
				for (int i = nev_ - nev; i < n_; i++)
					Tmp.remove_last();

				std::vector<block_diagonal_vector<T> > temp;
            	temp.push_back(map_);

				// X <- active Lanczos vectors * Y 
				temp[0] = std::move(active.right_multiply_by_nxq(Y));

				// linearization of locked and active Lanczos vectors
				Tmp.linearization_vector_of_blocks(temp);
				X_ = std::move(Tmp);
			}
			else
				X_ = Tmp.right_multiply_by_nxq(Y);

            assert( X_.size() == nev_);
        }

};

}  // namespace ompilancz

#endif
