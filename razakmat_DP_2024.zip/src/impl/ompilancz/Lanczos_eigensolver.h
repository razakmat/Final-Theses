#ifndef OMPILANCZ_EIGENSOLVER_H
#define OMPILANCZ_EIGENSOLVER_H

#include <mpi.h>

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <cmath>

#include "detail/block_diagonal_vector.h"
#include "detail/chrono_timer.h"
#include "detail/lapack_tridiagonal_eigensolver.h"
#include "detail/mapping.h"
#include "detail/matrix_times_vector.h"
#include "detail/mpi_datatype.h"
#include "detail/restart.h"
#include "detail/reorthogonalization.h"

namespace ompilancz
{

// single-vector Lanczos eigensolver:

template <typename T>
class Lanczos_eigensolver
{
   public:
      Lanczos_eigensolver(
            int I, int J, int N,    // process coordinates, number of diagonal processes
            uint64_t n, uint64_t m,  // process-local matrix block dimensions
            std::ostream & os = std::cout)
         : map_(I, J, N, n, m), mdt_( mpi_datatype<T>::get() ), X_(map_), os_(&os)
      {
         restart_ = nullptr;
         ortho_ = std::make_shared< fullOrtho<T> >(I,J,N,n,m);
         tde_ = nullptr;
         v_ = nullptr;
      }

      template <typename U>
      void solve(
            U&& matvec_operator,  // process-local matrix block x vector operator
            int nev,              // number of required eigenvalues
            int maxit,            // maximum number of iterations
            T eps)                // required residual accuracy
      {
         nev_ = nev;

         if (map_.root())
            *os_ << "Starting OMPILancz single-vector eigensolver..."
               << std::endl << std::endl;

         // open file for convergence logging

         if (map_.root())
            f_conv_log_.open("eigenvalues.dat");

         // reset timers
         matvec_time_ = 0.0;
         bcast_time_ = 0.0;
         local_matvec_time_ = 0.0;
         reduce_time_ = 0.0;
         reorthog_time_ = 0.0;
         restart_time_ = 0.0;
         tridiag_time_ = 0.0;

         chrono_timer solve_timer(chrono_timer::start_now);

         // setup data structure for Lanczos diagonal vectors:
         if (map_.diag() && v_ == nullptr)
         {
            v_ = std::make_shared< block_diagonal_vector<T> >(map_);

            // setup initial Lanczos vector:
            v_->add_random();
            v_->normalize_last();
         }

         // setup tridiagonal eigensolver on root:
         if (map_.root())
            tde_ = std::make_shared< tridiagonal_eigensolver<double> >(maxit);

         if (map_.diag() && restart_ != nullptr)
         {
            restart_->setup(eps,nev_,locking_);
         }
         if (map_.root())
         {
            ortho_->setup(tde_);
         }


         // setup matrix-vector multiplication wrapper:
         matrix_times_vector<T> matvec(map_);

         bool stop = false;  // stop flag

         // eigensolver iterations (indexed from 1):

         chrono_timer iterations_timer(chrono_timer::start_now);

         int j = 1;
         int iter = 1;
         // without restart j and iter are same
         // main loop
         for ( ; iter <= maxit; iter++,j++)
         {
            // additional Lanczos vector
            if (map_.diag())
               v_->add_zero();

            // u_j <- A * v_(j-1):

            chrono_timer matvec_timer(chrono_timer::start_now);

            if (map_.diag())
               matvec.diag_setup_xy(v_->ith_vector(j - 1), v_->ith_vector(j));

            chrono_timer bcast_timer(chrono_timer::start_now);
            matvec.broadcast_x();
            bcast_timer.stop();
            bcast_time_ += bcast_timer.seconds();

            chrono_timer local_matvec_timer(chrono_timer::start_now);
            matvec.multiply(matvec_operator);
            local_matvec_timer.stop();
            local_matvec_time_ += local_matvec_timer.seconds();

            chrono_timer reduce_timer(chrono_timer::start_now);
            matvec.reduce_y();
            reduce_timer.stop();
            reduce_time_ += reduce_timer.seconds();

            matvec_timer.stop();
            matvec_time_ += matvec_timer.seconds();

            // only for diag processes
            if (map_.diag())
            {
               // reorthogonalization:
               chrono_timer reorthog_timer(chrono_timer::start_now);
               T alpha, beta;
               std::tie(alpha, beta) = ortho_->orthonormalize(v_);

               reorthog_timer.stop();
               reorthog_time_ += reorthog_timer.seconds();

               // solve projected tridiagonal eigenproblem:

               bool first_value_converged = false;
               if (map_.root())
               {
                  chrono_timer tridiag_timer(chrono_timer::start_now);

                  // starts LAPACK solver
                  tde_->append_alphabeta(alpha, beta);
                  tde_->solve(nev);

                  tridiag_timer.stop();
                  tridiag_time_ += tridiag_timer.seconds();

                  // check convergence:
                  if (j >= nev)
                  {
                     stop = true;  // may stop

                     for (int i = 0; i < nev; i++)
                        if (tde_->res(i) > eps)
                           stop = false;

                  }
                  // checks if first eigenvalue is converged for restart
                  if (tde_->res(0) < eps)
                        first_value_converged = true;

                  print_Lambda(j, iter, nev);

                  log_Lambda(j,iter, nev);
               }

               MPI_Bcast(&stop, 1, MPI_CXX_BOOL, 0, map_.dcomm());
               MPI_Bcast(&first_value_converged, 1, MPI_CXX_BOOL, 0, map_.dcomm());

               // checks if restart could be called
               if (restart_ != nullptr && stop == false && iter != maxit)
               {
                  chrono_timer restart_timer(chrono_timer::start_now);
                  // checks if restart should be called
                  if ((locking_ && first_value_converged) || j == restart_iteration_)
                  {
                     restart_->execute(v_, tde_, j);
                     nev = restart_->getNewNev();
                  }
                  //resets iteration step after restart
                  j = v_->size() - 1;

                  restart_timer.stop();
                  restart_time_ += restart_timer.seconds();
               }

            }

            // stop iterating if convergence has been reached:
            MPI_Bcast(&stop, 1, MPI_CXX_BOOL, 0, map_.allcomm());
            if (stop)
               break;
         }

         // last iteration index:
         assert(iter <= maxit + 1);
         n_ = j;

         iterations_timer.stop();
         iterations_time_ = iterations_timer.seconds();

         // obtain resulting eigenpairs on diagonal processes:
         if (map_.diag())
         {
            if (v_->size() == j)
               n_--;

            assert(v_->size() == n_ + 1);
            v_->remove_last();  // not needed anymore
            assert(v_->size() == n_);

            chrono_timer reconstr_timer(chrono_timer::start_now);

            diags_get_eigenvalues();
            diags_get_eigenvectors(nev);

            reconstr_timer.stop();
            reconstr_time_ = reconstr_timer.seconds();
         }

         solve_timer.stop();
         solve_time_ = solve_timer.seconds();

         if (map_.root())
            *os_ << std::endl << "...eigensolver finished." << std::endl;
      }

      void setStream(std::ostream & os)
      {
         os_ = &os;
      }

      void setupRestart(std::shared_ptr< restart<T> > restart, int start_iteration, bool locking)
      {
         restart_ = restart;
         restart_iteration_ = start_iteration;
         locking_ = locking;
      }

      void setupReorthogonalization(std::shared_ptr< reorthogonalization<T> > ortho)
      {
         ortho_ = ortho;
      }

      template <typename U = T>
      void setInitialVector(std::vector<std::string> & filenames, uint64_t vector_size)
      {
         if(!map_.diag())
            return;

         v_ = std::make_shared< block_diagonal_vector<T> >(map_);
         span<U> data;
         MPI_Datatype mdt;
         std::vector<U> temp;
         mdt = mpi_datatype<U>::get();
         uint64_t offset;
         uint64_t n = map_.n();
         MPI_Scan(&n, &offset, 1, MPI_UINT64_T, MPI_SUM, map_.dcomm());
         offset -= n;
         offset *= sizeof(U);

         v_->add_zero();

         for (uint i = 0; i < filenames.size(); i++)
         {
            MPI_File f;
            MPI_File_open(map_.dcomm(), filenames[i].c_str(),
               MPI_MODE_RDONLY, MPI_INFO_NULL, &f);
            
            if(offset < vector_size)
            {
               temp.resize(n,0);
               data = span<U>(temp.data(),temp.size());

               MPI_File_read_at(f, offset, data.data(), std::min(n,vector_size - offset), mdt, MPI_STATUS_IGNORE);
               (*v_)[0].add_span(data);
               
               
            }
            MPI_File_close(&f);
         }

         v_->normalize_last();
      }

      // final residual norms ||A x_i - lambda_i x_i||_2 for i=1,...,nev
      template <typename U>
      void residuals(U&& matvec_operator, std::ostream & os = std::cout)
      {
         chrono_timer residuals_timer(chrono_timer::start_now);

         std::unique_ptr< diagonal_vector<T> > r;
         if (map_.diag())
            r = std::make_unique< diagonal_vector<T> >(map_);

         matrix_times_vector<T> matvec(map_);

         if (map_.root())
            os << std::endl;

         for (int i = 0; i < nev_; i++)
         {
            // r_i <- A * x_i :

            if (map_.diag())
               matvec.diag_setup_xy(X_[i], *r);
            matvec.broadcast_x();
            matvec.multiply(matvec_operator);
            matvec.reduce_y();

            if (!map_.diag())
               continue;

            // r_i <- r_i - lambda_i * x_i :
            r->scaled_subtract(Lambda_[i], X_[i]);

            // norm:
            T r_norm = r->norm();

            residuals_timer.stop();
            residuals_time_ = residuals_timer.seconds();

            if (map_.root())
               os << "Ev. " << std::right << std::setw(4) << i + 1 << " value = "
                  << std::right << std::setw(14) << std::setprecision(8) << std::fixed << Lambda_[i]
                  << ", res = " << std::scientific << std::setprecision(3) << r_norm << std::endl;
         }
      }

      template <typename U = T>
      void store_eigenvectors(const std::string& fileprefix, const std::string& extension = "dat", int num_width = 3)
      {
         if (map_.diag())
            X_.template store_to_files<U>(fileprefix, extension, num_width);
      }

      void print_times(std::ostream & os = std::cout)
      {
         double temp[3] = { bcast_time_, reduce_time_, local_matvec_time_ };
         if (map_.root())
         {
            MPI_Reduce(MPI_IN_PLACE, temp, 2, MPI_DOUBLE, MPI_MIN, 0, map_.allcomm());
            MPI_Reduce(MPI_IN_PLACE, temp + 2, 1, MPI_DOUBLE, MPI_MAX, 0, map_.allcomm());
         }
         else
         {
            MPI_Reduce(temp, nullptr, 2, MPI_DOUBLE, MPI_MIN, 0, map_.allcomm());
            MPI_Reduce(temp + 2, nullptr, 1, MPI_DOUBLE, MPI_MAX, 0, map_.allcomm());
         }

         if (map_.root())
         {
            os << std::endl << "Root process:" << std::endl;
            os << "  Solve time: ................................... "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << solve_time_ << " [s]" << std::endl;
            os << "  Total iterations time: ........................ "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << iterations_time_ << " [s]" << std::endl;
            os << "  Total matvec time: ............................ "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << matvec_time_ << " [s]" << std::endl;
            os << "  Total reorthogonalization time: ............... "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << reorthog_time_ << " [s]" << std::endl;
            if (restart_time_ > 0.0)
               os << "  Total restart time: ........................... "
                  << std::right << std::setw(10) << std::setprecision(2) << std::fixed << restart_time_ << " [s]" << std::endl;
            os << "  Total tridiagonal solver time: ................ "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << tridiag_time_ << " [s]" << std::endl;
            os << "  Eigenvectors reconstruction time: ............. "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << reconstr_time_ << " [s]" << std::endl;

            if (residuals_time_ > 0.0)
               os << "  Residual evaluation time: ..................... "
                  << std::right << std::setw(10) << std::setprecision(2) << std::fixed << reconstr_time_ << " [s]" << std::endl;

            os << "All processes:" << std::endl;
            os << "  Total maximal local matvec time: .............. "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[2] << " [s]" << std::endl;
            os << "  Total minimal broadcast communicatoin time: ... "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[0] << " [s]" << std::endl;
            os << "  Total minimal reduction communicatoin time: ... "
               << std::right << std::setw(10) << std::setprecision(2) << std::fixed << temp[1] << " [s]" << std::endl;
         }
      }

   private:
      mapping map_; // mapping of process

      int nev_; // number of wanted eigenvalues

      int n_; // final number of Lanczos vectors

      std::shared_ptr< block_diagonal_vector<T> > v_; // Lanczos vectors

      std::shared_ptr< tridiagonal_eigensolver<double> > tde_; // LAPACK eigenvalues and eigenvectors solver

      std::vector<T> Lambda_; // final eigenvalues
      block_diagonal_vector<T> X_;  // must be placed after map_, final eigenvectors

      std::shared_ptr< restart<T> > restart_;
      std::shared_ptr< reorthogonalization<T> > ortho_;

      double solve_time_;
      double iterations_time_;
      double matvec_time_;
      double bcast_time_;
      double local_matvec_time_;
      double reduce_time_;
      double reorthog_time_;
      double restart_time_;
      double tridiag_time_;
      double reconstr_time_;
      double residuals_time_ = 0.0;

      int restart_iteration_;
      bool locking_;

      MPI_Datatype mdt_;

      std::ofstream f_conv_log_; 
      std::ostream * os_;

      // implementation member functions:

      void log_Lambda(int j, int iter, int nev)
      {
         // log convergence
         f_conv_log_ << "It. " << std::right << std::setw(4) << iter << "  ";
         for (int i = 0; i < std::min(j, nev) - (nev_ - nev); i++)
            log_lambda_res(tde_->lambda(i), tde_->res(i));
         f_conv_log_ << "\n";
      }

      void print_Lambda(int j, int iter, int nev)
      {
         // print current 1st, 2nd, and nev-th eigenvalues:

         if (nev_ - nev == 0)
            *os_ << "It. " << std::right << std::setw(4) << iter << " - Ev.: ";
         else
            *os_ << "It. " << std::right << std::setw(4) << iter << " - Ev. (from " << nev_ - nev + 1<<"): ";
                                      print_lambda_res(tde_->lambda(      0), tde_->res(      0));
         if ((j > 1) && (nev > 1))    print_lambda_res(tde_->lambda(      1), tde_->res(      1));
         if ((j >= nev + (nev_ - nev)) && (nev > 2)) print_lambda_res(tde_->lambda(nev - 1), tde_->res(nev - 1));

         *os_ << std::endl;
      }

      void print_lambda_res(T lambda, T res)
      {
         *os_
            << std::right << std::setw(8) << std::setprecision(4) << std::fixed << lambda
            << " (" << std::scientific << std::setprecision(3) << res << ")   ";
      }

      void log_lambda_res(T lambda, T res)
      {
         f_conv_log_
            << std::right << std::setw(8) << std::setprecision(4) << std::fixed << lambda
            << " (" << std::scientific << std::setprecision(3) << res << ")   ";
      }

      void diags_get_eigenvalues()
      {
         assert (map_.diag());

         // broadcase eigenvalues to diagonal processes:

         if (map_.root())
         {
            // get already calculated values from restart
            if (restart_ != nullptr)
               restart_->getEigenvalues(Lambda_);

            span<double> Lambda = tde_->Lambda();
            for (int i = 0; i < Lambda.size(); i++)
               Lambda_.push_back(Lambda[i]);

            assert(Lambda_.size() == nev_);
         }
         else
            Lambda_.resize(nev_);

         MPI_Bcast(Lambda_.data(), nev_, mdt_, 0, map_.dcomm());
      }

      void diags_get_eigenvectors(int nev)
      {
         assert (map_.diag());

         // broadcast projected eigenvectors to diagonal processes:

         int size_of_Y =  nev * (n_ - (nev_ - nev));

         std::vector<T> Y;
         if (map_.root())
         {
            span<double> Temp = tde_->X();
            Y.assign(Temp.begin(), Temp.end());

            assert( Y.size() == size_of_Y );
         }
         else
            Y.resize(size_of_Y);

         MPI_Bcast(Y.data(), size_of_Y, mdt_, 0, map_.dcomm());

         // X <- Lanczos vectors * Y:

         assert( v_->size() == n_ );

         // dealing with the already locked and computed vectors in v_
         if (restart_ != nullptr)
         {
            // keep already locked vectors in v_ and move active ones to active
            block_diagonal_vector<T>  active(map_);
            for (int i = nev_ - nev; i < n_; i++)
            {
                active.add_diagonal((*v_)[i]);
            }
            for (int i = nev_ - nev; i < n_; i++)
            {
                v_->remove_last();
            }

            std::vector<block_diagonal_vector<T> > tmp;
            tmp.push_back(map_);

            // X <- active Lanczos vectors * Y 
            tmp[0] = std::move(active.right_multiply_by_nxq(Y));

            // linearization of locked and active Lanczos vectors
            v_->linearization_vector_of_blocks(tmp);
            X_ = std::move(*v_);
            
         }
         else
            X_ = v_->right_multiply_by_nxq(Y);

         assert( X_.size() == nev_ );
      }
};

}  // namespace ompilancz

#endif
