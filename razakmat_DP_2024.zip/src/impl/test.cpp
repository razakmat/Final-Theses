#include <cassert>
#include <cstdlib>
#include <iostream>
#include <tuple>
#include <unistd.h>

#include <mpi.h>

#include "ompilancz/Lanczos_eigensolver.h"
#include "ompilancz/Lanczos_block_eigensolver.h"
#include "ompilancz/LOBPCG_eigensolver.h"
#include "ompilancz/LOPCG_eigensolver.h"
#include "ompilancz/span.h"
#include "ompilancz/detail/reorthogonalization.h"
#include "ompilancz/detail/restart.h"


// initial matrix = -1 in non-diagonal elements, on diagonal - 1,2,3,...
class matvec_operator
{
   public:
      matvec_operator(int I, int J, int m, int n) : I_(I), J_(J), m_(m), n_(n) { }

      template <typename T>
      void operator()(T&& x, T&& y, T&& xt, T&& yt) const
      {

         if (I_ == J_)
         {
            // diagonal process:
            for (int i = 0; i < m_; i++)
               for (int j = i; j < n_; j++)
               {
                  if (i == j)
                     // diagonal elements:
                     y[i] += (double)(I_ * m_ + i + 1) * x[j];
                  else
                  {
                     // off-diagonal elements:
                     y[i] += -1.0 * x[j];
                     yt[j] += -1.0 * xt[i];
                  }
               }
         }
         else
         {
            // off-diagonal process:
            for (int i = 0; i < m_; i++)
               for (int j = 0; j < n_; j++)
               {
                  y[i] += -1.0 * x[j];
                  yt[j] += -1.0 * xt[i];
               }
         }
      }

   private:
      int I_, J_;
      int m_, n_;
};

// initial matrix = -1 in non-diagonal elements, on diagonal - 1,2,3,...
class block_matvec_operator
{
   public:
      block_matvec_operator(int I, int J, int m, int n) : I_(I), J_(J), m_(m), n_(n) { }

      template <typename T>
      void operator()(T&& x, T&& y, T&& xt, T&& yt, int s) const
      {

         if (I_ == J_)
         {
            // diagonal process:
            for (int i = 0; i < m_; i++)
               for (int j = i; j < n_; j++)
               {
                  if (i == j)
                     // diagonal elements:
                     for (int k = 0; k < s; k++)
                        y[s * i + k] += (double)(I_ * m_ + i + 1) * x[s * j + k];
                  else
                  {
                     // off-diagonal elements:
                     for (int k = 0; k < s; k++)
                     {
                        y[s * i + k] += -1.0 * x[s * j + k];
                        yt[s * j + k] += -1.0 * xt[s * i + k];
                     }
                  }
               }
         }
         else
         {
            // off-diagonal process:
            for (int i = 0; i < m_; i++)
               for (int j = 0; j < n_; j++)
               {
                  for (int k = 0; k < s; k++)
                  {
                     y[s * i + k] += -1.0 * x[s * j + k];
                     yt[s * j + k] += -1.0 * xt[s * i + k];
                  }
               }
         }
      }

   private:
      int I_, J_;
      int m_, n_;
};


std::tuple<int, int, int> get_IJN(int, int);

int main(int argc, char* argv[])
{    
   int i = 0;

   MPI_Init(&argc, &argv);

   int rank, nprocs;
   MPI_Comm_rank(MPI_COMM_WORLD, &rank);
   MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

   // process coordinates:

   int I, J, N;
   std::tie(I, J, N) = get_IJN(rank, nprocs);

   // matrix:

   uint64_t n;
   if (argc < 2)
      n = 100;
   else
      n = atol(argv[1]);

   omp_set_num_threads(1);

   // wrapping in a block to clean up communicaotrs in destructors before MPI_Finalize:
   {
      using F = double;
      //std::ofstream f;
      //f.open("text.txt",std::ios::out);
      //std::ostream os(f.rdbuf());
      int block_size = 5;

      std::shared_ptr<ompilancz::implicitRestart<F>> res = std::make_shared< ompilancz::implicitRestart<F> >(I,J,N,n,n);
      std::shared_ptr<ompilancz::fullMultiBlockOrtho<F>> ort1 = std::make_shared< ompilancz::fullMultiBlockOrtho<F> >(I,J,N,n,n);
      std::shared_ptr<ompilancz::PartialOrtho<F>> ort2 = std::make_shared< ompilancz::PartialOrtho<F> >(I,J,N,n,n);
      std::shared_ptr<ompilancz::PartialOrtho<F>> ort3 = std::make_shared< ompilancz::PartialOrtho<F> >(I,J,N,n,n,block_size);
      std::shared_ptr<ompilancz::thickRestart<F>> res2 = std::make_shared< ompilancz::thickRestart<F> >(I,J,N,n,n);
      std::shared_ptr<ompilancz::thickRestart<F>> res3 = std::make_shared< ompilancz::thickRestart<F> >(I,J,N,n,n);

      matvec_operator mv(I, J, n, n);
      block_matvec_operator bmv(I, J, n, n);

      ompilancz::Lanczos_eigensolver<F> es(I, J, N, n, n);
      ompilancz::Lanczos_block_eigensolver<F> bes(I, J, N, n, n);
      ompilancz::LOBPCG_eigensolver<F> les(I, J, N, n, n);
      ompilancz::LOPCG_eigensolver<F> sles(I, J, N, n, n);

      // LOPCG method
      //sles.solve(mv,2,500,1.0e-6);
      //sles.residuals();
      //sles.print_times();

      // LOBPCG method
      //les.solve(bmv,5,1000,block_size,1.0e-6);
      //les.residuals();
      //les.print_times();

      // Lanczos - single vector
      es.solve(mv, 5, 5000, 1.0e-6);
      es.residuals(mv);
      es.print_times();

      // Block Lanczos
      //bes.solve(bmv, 5, 1000, block_size, 1.0e-6);
      //bes.residuals(bmv);
      //bes.print_times();
   }

   MPI_Finalize();
}

std::tuple<int, int, int>get_IJN(int rank, int nprocs)
{
   // get nubmer of diagonal processes N: 

   int N = 1;
   while (true)
   {
      int temp = N * (N + 1) / 2;

      if (temp == nprocs)
         break;

      if (temp > nprocs)
      {
         if (rank == 0)
            std::cerr << "Incorrect number of MPI processes; must be N*(N+1)/2 for some i." << std::endl;

         MPI_Abort(MPI_COMM_WORLD, -1);
      }

      N++;
   }

   // get process coordinates (I, J):

   int I = 0;
   int J = 0;

   int r = 0;
   for ( ; r < nprocs; r++)
   {
      if (r == rank)
         break;

      I++;
      J++;

      if (J >= N)
      {
         J = N - I + 1;
         I = 0;
      }
   }

   assert(r == rank);
   assert(r < nprocs);

   return { I, J, N };
}
