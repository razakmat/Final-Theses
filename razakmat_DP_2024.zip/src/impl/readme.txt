test.cpp obsahuje základní testovací funkci společně s operátory na násobení matice vektorem (blokový i jedno-vektorový) a primitivní vstupní maticí.

Skript run.sh se spouští se dvěmi argumenty:
1 - počet procesů
2 - velikost matice pro jeden proces

