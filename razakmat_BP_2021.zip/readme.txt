Struktura CD:
1) readme.txt				popis obsahu paměťové karty
2) exe					
	2A) DCPP			spustitelný exe soubor
	2B) config			soubor s konfigurací programu
3) src
	3A) impl : 	-src		zdrojové kódy implementace
			-makefile	makefile
			-config		soubor s konfigurací programu
	3B) thesis			zdrojová forma práce ve formátu LATEX
4) text					
	4A) Zadání_BP.pdf		zadání práce ve fromátu PDF
	4B) BP_Razak_Matej_2021.pdf	text práce ve formátu PDF
