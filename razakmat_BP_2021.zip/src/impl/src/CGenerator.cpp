#include "CGenerator.h"

// constructor
// prepares random number generator
CGenerator::CGenerator()
:m_numVertex(0),m_rndEngine((random_device())())
{
	// sets max weight of edge to 100
	m_maxWeight = 100;
}

// destructor
CGenerator::~CGenerator()
{
	Deallocation();
}

// deallocates memory
void CGenerator::Deallocation()
{
	if (m_numVertex != 0)
	{
		for (int i = 0; i < m_numVertex; i++)
			delete [] m_matrix[i];
		delete [] m_matrix;
		delete [] m_startTime;
		delete [] m_low;
		delete [] m_inverseST;
	}
}

// returns random number from given range
int CGenerator::GetRandomNumber(int from, int to)
{
	return uniform_int_distribution<>{from,to}(m_rndEngine);
}

// resets values before every calculation
void CGenerator::Reset()
{
	for (int i = 0; i < m_numVertex; i++)
		for (int j = 0; j < m_numVertex; j++)
			m_matrix[i][j] = 0;
	for (int i = 0; i < m_numVertex; i++)
		m_startTime[i] = -1;
	m_globalTime = 0;
}

// sets number of vertices and edges of resulting graph for method GetGraph
// allocates neccesary memory
void CGenerator::SetGenerator(int vertices, int edges)
{
	Deallocation();
	m_numVertex = vertices;
	m_numEdge = edges;

	m_matrix = new int*[m_numVertex];
	for (int i = 0 ; i < m_numVertex; i++)
		m_matrix[i] = new int[m_numVertex];
	m_startTime = new int[m_numVertex];
	m_low = new int[m_numVertex];
	m_inverseST = new int[m_numVertex];
}

// adds rest of the given number of edges to strongly connected graph
void CGenerator::AddEdges(CGraph * graph)
{
	vector<pair<int,int>> edges;
	edges.reserve(m_numVertex * m_numVertex - m_numVertex);

	// adds every unused edge in vector edges
	for (int i = 0; i < m_numVertex; i++)
		for (int j = 0; j < m_numVertex; j++)
			if (m_matrix[i][j] == 0 && i != j)
				edges.push_back(make_pair(i,j));

	// randomly shuffles edges in vector
	shuffle(edges.begin(),edges.end(),m_rndEngine);

	// adds edges from back of vector edges to graph till graph has desired number of edges  
	while (m_cntEdge < m_numEdge && !edges.empty())
	{
		pair<int,int> tmp = edges.back();
		graph->AddEdge(tmp.first,tmp.second,GetRandomNumber(1,m_maxWeight));
		edges.pop_back();
		m_cntEdge++;
	}
}

// creates and adds edge into graph
void CGenerator::CreatingEdge(CGraph * graph, int vertex)
{
	// 2 random numbers, bigger/equal than m_startTime of vertex and
	// smaller than m_startTime of vertex
	int randomX = GetRandomNumber(m_startTime[vertex],m_globalTime - 1);
	int randomY = GetRandomNumber(0,m_startTime[vertex] - 1);
	// finds which vertices corresponds with specific m_startTime
	int vertexX = m_inverseST[randomX];
	int vertexY = m_inverseST[randomY];
	int weight = GetRandomNumber(1,m_maxWeight);
	graph->AddEdge(vertexX,vertexY,weight);
	// raises number of edges in graph
	m_cntEdge++;
	m_matrix[vertexX][vertexY] = weight;
	m_low[vertex] = randomY;
}

// creates from spanning tree strongly connected graph
// using modified Tarjan algorithm
void CGenerator::CreateStrongCon(CGraph * graph, int vertex)
{
	// m_startTime[vertex] - first time vertex seen
	m_startTime[vertex] = m_globalTime;
	// low[vertex] - lowest m_startTime that can be reached from vertex
	m_low[vertex] = m_globalTime;
	// inverse m_startTime
	m_inverseST[m_globalTime] = vertex;
	// with every recursion global time grows by 1
	m_globalTime++;

	vector<Edge> & edges = graph->GetVertex(vertex);
	// goes throught every edge of vertex
	for (auto & x : edges)
	{
		// if x.name was not visited before
		if (m_startTime[x.name] == -1)
		{
			CreateStrongCon(graph,x.name);
			// if somewhere in recursion was visited vertex with lower m_startTime
			if (m_low[x.name] < m_low[vertex])
				m_low[vertex] = m_low[x.name];
		} 
		// if x.name has lowest m_startTime from all the visited vertices from this vertex
		if (m_startTime[x.name] < m_low[vertex])
			m_low[vertex] = m_startTime[x.name];
	}

	// this part is modified from Tarjan algorithm,
	// here instead of detecting new strongly connected component
	// algorithm adds edge which prevents forming of new component
	if (m_low[vertex] == m_startTime[vertex] && vertex != 0)
	{
		CreatingEdge(graph,vertex);
	}
}

// creates spanning tree
void CGenerator::CreateSpanningTree(CGraph * graph)
{
	// one by one connects vertices to current spanning tree by edge 
	for (int i = 1; i < m_numVertex; i++)
	{
		int random = GetRandomNumber(0,i-1);
		int weight = GetRandomNumber(1,m_maxWeight);
		graph->AddEdge(random,i,weight);
		// m_matrix corresponds to graph
		// m_matrix is used during building for easier reach of edges 
		m_matrix[random][i] = weight;
	}
}

// creates new graph
CGraph * CGenerator::GetGraph()
{
	Reset();
	CGraph * graph;
	graph = new CGraph();
	graph->SetNumVertex(m_numVertex);
	// first creates spanning tree
	CreateSpanningTree(graph);
	// current number of edges in graph
	m_cntEdge = m_numVertex - 1;
	// creates from spanning tree strongly connected graph
	CreateStrongCon(graph,0);
	// adds random edges till graph have desired amount of edges
	AddEdges(graph);

	return graph;
}