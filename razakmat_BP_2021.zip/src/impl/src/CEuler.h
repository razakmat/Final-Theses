#ifndef CEULER_H
#define CEULER_H

#include <list>
#include <stack>
#include "CGraph.h"


using namespace std;


// class holding Hieholzer algorithm for finding Eulerian cycle
class CHierholzer
{
	public:
		// finds Eulerian cycle in Eulerian graph
		void	Calculate	(CGraph * graph, list<int> & Euler); 
};


#endif // CEULER_H