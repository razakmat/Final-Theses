#ifndef CPATHFINDING_H
#define CPATHFINDING_H

#include <list>
#include <vector>
#include <omp.h>
#include <boost/heap/fibonacci_heap.hpp>
#include "CGraph.h"
#include "Dijkstra.h"
#include "CInputAssignment.h"


using namespace std;

// Abstract class containing classes finding shortest paths
class CPathFinding
{
	public:
						CPathFinding		(CGraph * graph); // constructor
		virtual			~CPathFinding		() = 0; // destructor
		virtual	void	Calculate			(CInputAssignment * InAssign) = 0; // abstract method
		virtual void	FindPathFromIndex	(int indexI, int indexJ, list<int> & path, int & cost) = 0; // abstract method
	protected:
		void			FillOutputIndex		(); // fills attributs m_outpuIndexRow and m_outputIndexCol with unbalanced vertices
		const int MAX = numeric_limits<int>::max(); // max integer
		CGraph * m_graph; // holds graph
		int ** m_distMatrix; // matrix of distances of shortest paths
		int ** m_pathMatrix; // matrix for reconstuction of shortest paths
		vector<int> m_outputIndexRow; // contains vertices with negative degree
		vector<int> m_outputIndexCol; // contains vertices with positive degree
};

// Class finding shortest paths by using Dijkstra algorithm
class CDijkstra : public CPathFinding
{
	public:
					CDijkstra				(CGraph * graph); // constructor
					~CDijkstra				(); // destructor
		// starts calculation, returns InAssign filled with values of distances of shortest paths
		void		Calculate				(CInputAssignment * InAssign);
		// returns shortest path (saved in m_pathMatrix) (from indexI to indexJ) and it's weight
		void		FindPathFromIndex		(int indexI, int indexJ, list<int> & path, int & cost);
	private:
		void		CreateOutputStructure	(CInputAssignment * InAssign); // fills resulting InAssign with distances of shortest paths
		// allocates necessary memory and fills m_startPoints with vertices from which class needs to start Dijkstra algorithm
		bool *		Prepare					(int & cntEnd);
		int m_oddVertex; // size of m_startPoints
		vector<int> m_startPoints; // vertices from which class finds shortest paths
};

// Class finding shortest paths by using Floyd-Warshall algorithm
class CFloydWarshall : public CPathFinding
{
	public:
					CFloydWarshall			(CGraph * graph); // constructor
					~CFloydWarshall			(); // destructor
		// starts calculation, returns InAssign filled with values of distances of shortest paths
		void		Calculate				(CInputAssignment * InAssign);
		// returns shortest path (saved in m_pathMatrix) (from indexI to indexJ) and it's weight
		void		FindPathFromIndex		(int indexI, int indexJ, list<int> & path, int & cost);

	private:
		void 		Allocate				(); // allocates necessary memory
		void		CreateOutputStructure	(CInputAssignment * InAssign); // fills resulting InAssign with distances of shortest paths
		void		Algorithm				(int numVertex); // Floyd-Warshall algorithm
};

#endif // CPATHFINDING_H