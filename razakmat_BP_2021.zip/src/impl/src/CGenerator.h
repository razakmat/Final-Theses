#ifndef CGENERATOR_H
#define CGENERATOR_H

#include <vector>
#include <list>
#include <random>
#include <algorithm>
#include "CGraph.h"

using namespace std;

// Class used for creating random strongly connected graph
class CGenerator
{
	public:
					CGenerator			(); // constructor
					~CGenerator			(); // destructor
		// sets number of vertices and edges of resulting graph for method GetGraph
		void		SetGenerator		(int vertices, int edges);
		CGraph *	GetGraph			(); // creates new graph
	private:
		void		Deallocation		(); // deallocates memory
		void		Reset				(); // resets values before every calculation
		void		CreateSpanningTree	(CGraph * graph); // creates spanning tree
		void		CreatingEdge		(CGraph * graph, int vertex); // creates and adds edge into graph
		// creates from spanning tree strongly connected graph
		void		CreateStrongCon		(CGraph * graph, int vertex);
		// adds rest of the given number of edges to strongly connected graph
		void		AddEdges			(CGraph * graph);
		int			GetRandomNumber		(int from, int to); // returns random number
		int m_numVertex; // number of vertices in final graph
		int m_numEdge; // number of edges in final graph
		int ** m_matrix; // matrix holding weight of edges, zero indicates absence of edge
		int m_maxWeight; // max weight of any edge
		int * m_startTime; // array used in creating strongly connected graph
		int m_globalTime; // integer used in creating strongly connected graph
		int * m_low; // array used in creating strongly connected graph
		int * m_inverseST; // array used in creating strongly connected graph
		int m_cntEdge; // current number of edges in graph
		std::mt19937 m_rndEngine; // random number generator
};


#endif // CGENERATOR_H