#ifndef CINPUTASSIGNMENT_H
#define CINPUTASSIGNMENT_H

#include <list>
#include <stack>
#include <vector>
#include "CGraph.h"


using namespace std;

// Class holding structure used as input for assignment problem
class CInputAssignment
{
	public:
						CInputAssignment	(int size); // constructor
		virtual			~CInputAssignment	() = 0; // destructor
		virtual void	AddElement			(int i,int j,int weight) = 0; // abstract method
		CGraph *		GetNetwork			(); // returns graph stored in m_graph
		int **			GetMatrix			(); // returns matrix stored in m_matrix
		int				GetSize				(); // returns value in m_size
	protected:
		int m_size; // size of m_matrix (number of rows), or size of m_graph (number of vertices in m_graph)
		int ** m_matrix; // matrix holding lengths of shortest paths
		CGraph * m_graph; // complete bipartite graph + source + sink, weights of edges are lengths of shortest paths

};


class CHoldMatrix : public CInputAssignment
{
	public:
						CHoldMatrix			(int size); // constructor
						~CHoldMatrix		(); // destructor
		void			AddElement			(int i,int j,int weight); // adds value to position in m_matrix 
	private:
};

class CHoldNetwork : public CInputAssignment
{
	public:
						CHoldNetwork		(int size); // constructor
						~CHoldNetwork		(); // destructor
		void			AddElement			(int i,int j,int weight); // adds edge to m_graph
	private:
};



#endif // CINPUTASSIGNMENT_H