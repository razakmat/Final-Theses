#include <fstream>
#include <iostream>
#include <list>
#include <omp.h>
#include "CDCPP.h"
#include "CGraph.h"
#include "CGenerator.h"
#include "CPathFinding.h"

using namespace std;

Algorithm path;
Algorithm assign;


// function reads config file
// returns true if everything is okay in config
bool ConfigFile()
{
	ifstream config;
	config.open("config");
	if (config.fail())
		return false;

	int threads = 0;
	// reads number of threads used in program from config file
	config >> threads;	
	int first = 0;
	// reads which subclass to use in CPathFinding from config file
	// 1 - CFloydWarshall, 2 - CDijkstra
	config >> first;
	int second = 0;
	// reads which subclass to use in CAssigment from config file
	// 1 - CHungarian, 2 - CBipartiteMatching, 3 - CNaive
	config >> second;

	if (threads < 1)
		return false;
	omp_set_num_threads(threads);

	if (first < 1 || first > 2)
		return false;
	path = static_cast<Algorithm>(first);

	if (second < 1 || second > 3)
		return false;
	assign = static_cast<Algorithm>(second + 2);

	config.close();
	return true;
}


int main (int argc, char *argv[])
{
	if (!ConfigFile())
	{
		cout << "Mistake with config file" << endl;
		return 0;
	}

	CGraph * graph;

	switch(argc)
	{
		// in case where entrence graph is given by file
		case 2:
			graph = new CGraph();
			if (!graph->NewGraph(argv[1]))
			{
				cout << "Incorrect file or graph in it" << endl;
				delete graph;
				return 0;
			}
			break;
		// in case where entrence graph is given by number of vertices and edges
		case 3:
		{
			long verticle;
			long edges;
			char * endptr = NULL;
			verticle = strtol(argv[1],&endptr,10);
			if (*endptr || verticle < 2)
			{
				cout << "Incorrect first argument" << endl;
				return 0;
			}
			edges = strtol(argv[2],&endptr,10);
			if (*endptr || edges < 1)
			{
				cout << "Incorrect second argument" << endl;
				return 0;
			}

			// creates generator with set parameters and then creates graph
			CGenerator * gen = new CGenerator();
			gen->SetGenerator(verticle,edges);
			graph = gen->GetGraph();
			delete gen;
		}
			break;
		default:
		{
			cout << "Incorrect number of arguments" << endl;
			return 0;
		}
	}


	// creates instance of class CDCPP and calculates path into list result and weight into length
	CDCPP * problem = new CDCPP(graph);
	problem->SetAlgorithms(path,assign);
	int length;
	list<int> result;
	problem->Calculate(result,length);

	// prints resulting path and weight of that path
	problem->PrintResult(result);


	delete graph;
	delete problem;
	
	return 0;
}