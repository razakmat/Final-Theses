#include "Dijkstra.h"

// constructor
Dijkstra::Dijkstra(CGraph * graph)
:m_graph(graph)
{
	m_iterators = new vector<Edge>::iterator[m_graph->GetNumVertex()];
}

// destructor
Dijkstra::~Dijkstra()
{
	delete [] m_iterators;
}

// returns attribut m_iterators
vector<Edge>::iterator * Dijkstra::GetPointers()
{
	return m_iterators;
}


using HEAP = boost::heap::fibonacci_heap<pair<int,int>, boost::heap::compare<Dijkstra::CompareMin>>;

// Dijkstra algorithm with use of fibonacciho_heap
// int start - starting vertex
// int * distance - array of shortest distances from vertex start
// int * parent - array of previous vertices in shortest paths
// bool * endVertices - to which vertices shortest paths must be calculated
// int cndEnd - count of endVertices
void Dijkstra::Calculate(int *& distance,int *& parent,int start,bool * endVertices,int cntEnd)
{
	HEAP queue;
	std::vector<HEAP::handle_type> handles;
	int numVertex = m_graph->GetNumVertex();
	distance[start] = 0;

	// inicialization + put every vertex into heap
	for (int i = 0; i < numVertex; i++)
	{
		if (i != start)
			distance[i] = MAX;
		parent[i] = -1;
		HEAP::handle_type handle = queue.push(make_pair(distance[i],i));
		handles.push_back(handle);
	}

	// main while cycle
	while(!queue.empty())
	{
		// extract min
		int vertex = queue.top().second;
		queue.pop();

		// next 2 ifs help end algorithm if paths to all neccesary vertices were calculated 
		if (endVertices[vertex] == true)
			cntEnd--;
		if (cntEnd == 0)
			break;

		vector<Edge> & edges = m_graph->GetVertex(vertex);
		for (uint i = 0; i < edges.size(); i++)
		{
			if (distance[edges[i].name] > distance[vertex] + edges[i].weight)
			{
				distance[edges[i].name] = distance[vertex] + edges[i].weight;
				parent[edges[i].name] = vertex;
				// saves which edge was used to get from vertex to edges[i] 
				m_iterators[edges[i].name] = edges.begin() + i;

				// uses method increase instead of decrease because this heap was build as max heap
				// and now is used as min heap, so we have to switch methods
				queue.increase(handles[edges[i].name],make_pair(distance[edges[i].name],edges[i].name));
			}
		}
	}
}
