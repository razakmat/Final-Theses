#include "CEuler.h"

// finds Eulerian cycle in Eulerian graph
// resulting sequence of vertices is stored in list Euler
void CHierholzer::Calculate (CGraph * graph, list<int> & Euler)
{
	stack<int> current_path;
	// starting with vertex 0
	current_path.push(0);
	int vertex = 0;

	while( !current_path.empty() )
	{
		vector<Edge> & edges = graph->GetVertex(vertex);
		// till current vertex has outgoing edge, we go forward in trail
		if (!edges.empty())
		{
			current_path.push(vertex);
			int next = edges.back().name;
			edges.pop_back();
			vertex = next;
		}
		// when current vertex does not have outgoing edge,
		// we backtrack and put current vertex in list Euler
		else
		{
			Euler.push_front(vertex);
			vertex = current_path.top();
			current_path.pop();
		}
	}
}