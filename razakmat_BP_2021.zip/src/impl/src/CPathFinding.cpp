#include "CPathFinding.h"

// constructor
CPathFinding::CPathFinding(CGraph * graph)
:m_graph(graph),m_distMatrix(NULL),m_pathMatrix(NULL)
{

}

// destructor
CPathFinding::~CPathFinding()
{
}

// fills attributs m_outpuIndexRow and m_outputIndexCol with unbalanced vertices
void CPathFinding::FillOutputIndex()
{
	int numVertex = m_graph->GetNumVertex();
	int * degree = m_graph->GetDegree();

	for (int i = 0; i < numVertex; i++)
	{
		// if vertex i has positive degree(i), i is put into m_outputIndexCol degree(i)-times 
		if (degree[i] > 0)
		{
			for (int j = 0; j < degree[i]; j++)
				m_outputIndexCol.push_back(i);
		}
		// if vertex i has negative degree(i), i is put into m_outputIndexRow degree(i)-times 
		else if (degree[i] < 0)
			for (int j = 0; j > degree[i]; j--)
				m_outputIndexRow.push_back(i);
	}

}

// constructor
CDijkstra::CDijkstra(CGraph * graph)
:CPathFinding(graph)
{
}

// destructor
CDijkstra::~CDijkstra()
{
	if (m_distMatrix!=NULL)
	{
		for (int i = 0 ; i < m_oddVertex; i++)
		{
			delete [] m_distMatrix[i];
			delete [] m_pathMatrix[i];
		}
		delete [] m_distMatrix;
		delete [] m_pathMatrix;
	}
}

// returns shortest path (saved in m_pathMatrix) (from indexI to indexJ) and it's weight
// indexI - vertex in m_outputIndexRow
// indexJ - vertex in m_outputIndexCol
void CDijkstra::FindPathFromIndex(int indexI, int indexJ, list<int> & path, int & cost)
{
	// last vertex from path
	int current = m_outputIndexCol[indexJ];

	path.push_front(current);

	// while cyklus till it reaches first vertex in the path (m_startPoints[m_outputIndexRow[indexI]])
	while (current != m_startPoints[m_outputIndexRow[indexI]])
	{
		current = m_pathMatrix[m_outputIndexRow[indexI]][current];
		path.push_front(current);
	}
	cost = m_distMatrix[m_outputIndexRow[indexI]][m_outputIndexCol[indexJ]];
}

// fills resulting InAssign with distances of shortest paths
void CDijkstra::CreateOutputStructure(CInputAssignment * InAssign)
{
	// fills attributs m_outputIndexRow and m_outputIndexCol with unbalanced vertices
	FillOutputIndex();

	// we need to find at which position is specific value in m_startPoints in constant time
	// so we invert m_startPoints into inverseStartPoints
	int * inverseStartPoints = new int[m_graph->GetNumVertex()];
	for (uint i = 0; i < m_startPoints.size(); i++)
		inverseStartPoints[m_startPoints[i]] = i;

	// sending distances (from m_distMatrix) between vertices in m_outputIndexRow and m_outpuIndexCol to InAssign 
	for (uint i = 0; i < m_outputIndexRow.size(); i++)
	{
		for (uint j = 0; j < m_outputIndexCol.size(); j++)
		{
			InAssign->AddElement(i,j,m_distMatrix[inverseStartPoints[m_outputIndexRow[i]]][m_outputIndexCol[j]]);
		}
	}
	delete [] inverseStartPoints;

	// recalculates attribut m_outputIndexRow
	// x = m_outputIndexRow[i] --> row index in_distMatrix of vertex x 
	int newNum = 0;
	int oldNum = m_outputIndexRow[0];
	for (uint i = 0; i < m_outputIndexRow.size(); i++)
	{
		if (oldNum != m_outputIndexRow[i]) newNum++;
		oldNum = m_outputIndexRow[i];
		m_outputIndexRow[i] = newNum;
	}
}

// allocates necessary memory and fills m_startPoints with vertices from which class needs to start Dijkstra algorithm
bool * CDijkstra::Prepare(int & cntEnd)
{
	int numVertex = m_graph->GetNumVertex();
	int * degree = m_graph->GetDegree();
	// bool * endVertices - true if shortest distance needs to be calculated to that vertex 
	bool * endVertices = new bool[numVertex];

	// if vertex i has negative degree[i] it is put into m_startPoints
	for (int i = 0; i < numVertex; i++)
	{
		if (degree[i] < 0) m_startPoints.push_back(i);
		if (degree[i] > 0)
		{
			// distance to vertex i needs to be calculated
			endVertices[i] = true;
			cntEnd++;
		}
		else{
			// balanced vertex
			endVertices[i] = false;
		}
	}
	m_oddVertex = m_startPoints.size();

	m_distMatrix = new int*[m_oddVertex];
	m_pathMatrix = new int*[m_oddVertex];

	return endVertices;
}

// starts calculation, returns InAssign filled with values of distances of shortest paths
void CDijkstra::Calculate(CInputAssignment * InAssign)
{
	// number of vertices with positive degree (number of trues in endVertices)
	int cntEnd = 0;
	bool * endVertices = Prepare(cntEnd); 

	int numVertex = m_graph->GetNumVertex();

	Dijkstra * Calc = new Dijkstra(m_graph);

	// calculates shortest distances from vertices with negative degree
	#pragma omp parallel for schedule(dynamic) 
	for (int i = 0; i < m_oddVertex; i++)
	{
		int * dist = new int[numVertex];
		int * prev = new int[numVertex];

		Calc->Calculate(dist,prev,m_startPoints[i],endVertices,cntEnd);

		m_distMatrix[i]=dist;
		m_pathMatrix[i]=prev;
	}
	delete [] endVertices;
	delete Calc;

	// fills output structure InAssign with calculated distances
	CreateOutputStructure(InAssign);
}

// constructor
CFloydWarshall::CFloydWarshall(CGraph * graph)
:CPathFinding(graph)
{
}

// destructor
CFloydWarshall::~CFloydWarshall()
{
	if (m_distMatrix != NULL)
	{
		int numVertex = m_graph->GetNumVertex();
		for (int i = 0 ; i < numVertex ; i++)
		{
			delete [] m_distMatrix[i];
			delete [] m_pathMatrix[i];
		}
		delete [] m_distMatrix;
		delete [] m_pathMatrix;
	}
}

// allocates necessary memory
void CFloydWarshall::Allocate()
{
	int numVertex = m_graph->GetNumVertex();

	m_distMatrix = new int*[numVertex];
	m_pathMatrix = new int*[numVertex];
	for (int i = 0 ; i < numVertex ; i++)
	{
		m_distMatrix[i] = new int[numVertex];
		m_pathMatrix[i] = new int[numVertex];
	}
	// inicialization of m_distMatrix
	for (int i = 0 ; i < numVertex ; i++)
		for (int j = 0 ; j < numVertex ; j++)
		{
			if (i == j)
				m_distMatrix[i][j] = 0;
			else
				m_distMatrix[i][j] = MAX;
			m_pathMatrix[i][j] = j;
		}
}

// returns shortest path (saved in m_pathMatrix) (from indexI to indexJ) and it's weight
// indexI - vertex in m_outputIndexRow
// indexJ - vertex in m_outputIndexCol
void CFloydWarshall::FindPathFromIndex(int indexI, int indexJ, list<int> & path, int & cost)
{
	// start vertex
	int current = m_outputIndexRow[indexI];

	path.push_back(current);

	// while cyklus till it reaches ending vertex (m_outputIndexCol[indexJ])
	while (current != m_outputIndexCol[indexJ])
	{
		current = m_pathMatrix[current][m_outputIndexCol[indexJ]];
		path.push_back(current);
	}
	cost = m_distMatrix[m_outputIndexRow[indexI]][m_outputIndexCol[indexJ]];
}

// fills resulting InAssign with distances of shortest paths
void CFloydWarshall::CreateOutputStructure(CInputAssignment * InAssign)
{
	// fills attributs m_outputIndexRow and m_outputIndexCol with unbalanced vertices
	FillOutputIndex();

	// sending distances (from m_distMatrix) between vertices in m_outputIndexRow and m_outpuIndexCol to InAssign 
	int i = 0;
	int j;
	for (auto & x : m_outputIndexRow)
	{
		j = 0;
		for (auto & y : m_outputIndexCol)
		{
			InAssign->AddElement(i,j++,m_distMatrix[x][y]);
		}
		i++;
	}
}

// Floyd-Warshall algorithm
void CFloydWarshall::Algorithm(int numVertex)
{
	// calculates distances and matrix m_pathMatrix for path reconstruction
	for (int k = 0; k < numVertex; k++){
		#pragma omp parallel for
		for (int i = 0; i < numVertex; i++){
			for (int j = 0; j < numVertex; j++)
				if ( m_distMatrix[i][k] != MAX && m_distMatrix[k][j] != MAX &&
					 m_distMatrix[i][j] > m_distMatrix[i][k] + m_distMatrix[k][j] )
				{
					m_distMatrix[i][j] = m_distMatrix[i][k] + m_distMatrix[k][j];
					m_pathMatrix[i][j] = m_pathMatrix[i][k];
				}
		}
	}
}

// starts calculation, returns InAssign filled with values of distances of shortest paths
void CFloydWarshall::Calculate(CInputAssignment * InAssign)
{
	Allocate();
	int numVertex = m_graph->GetNumVertex();	

	//fills m_distMatrix with weights of edges
	for (int i = 0; i < numVertex; i++)
	{
		vector<Edge> & edges = m_graph->GetVertex(i);
		for (auto & x : edges)
		{
			if (m_distMatrix[i][x.name] > x.weight)
				m_distMatrix[i][x.name] = x.weight;
		}
	}
	// starts Floyd-Warshall algorithm
	Algorithm(numVertex);

	// fills output structure InAssign with calculated distances
	CreateOutputStructure(InAssign);
}
