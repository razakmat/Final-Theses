#ifndef CASSIGNMENT_H
#define CASSIGNMENT_H

#include <list>
#include <set>
#include <vector>
#include <iostream>
#include <omp.h>
#include <boost/heap/fibonacci_heap.hpp>
#include "CInputAssignment.h"
#include "CGraph.h"
#include "Dijkstra.h"


using namespace std;


// Abstract class containing classes solving assignment problem
class CAssignment
{
public:
					CAssignment(int size); // constructor
	virtual 		~CAssignment(); // destructor
	virtual void	Calculate(list <pair<int,int>> & resultIndexes) = 0; // abstract method
protected:
	const int MAX = numeric_limits<int>::max(); // max integer
	int m_size; // size of matrix
};


// Class solving assignment problem by naive recursive solution
class CNaive : public CAssignment
{
	public:
					CNaive(CInputAssignment * InAssign); //constructor
					~CNaive(); // destructor
		// starts calculation, returns optimal matching
		void		Calculate(list <pair<int,int>> & resultIndexes);
	private:
		// ending condition of recursion
		bool		EndingCondition(int count, int * array,int k);
		// creates array and fills it with values for next iteration
		int * 		CreateArray(int * array, int i, int k, int & pos);
		// recursive method
		void		Algorithm(int array[],int k, int count);
		int ** m_matrix; // matrix holding values
		int m_bestScore; // sum of matching in m_bestPairs
		int * m_bestPairs; // current best matching

};

// Class solving assignment problem by Munkres modification of Hungarian method
class CHungarian : public CAssignment
{
	public:
					CHungarian(CInputAssignment * InAssign); // constructor
					~CHungarian(); // destructor
		// starts calculation, returns optimal matching
		void		Calculate(list <pair<int,int>> & resultIndexes);
	private:
		int ** m_matrix; // matrix holding values
		int ** m_mask; // information about values in m_matrix
		int * m_col; // indicates present of starred zeroes in columns
		int * m_row; // indicates present of starred zeroes in rows
		int m_zeroX; // row of current zero
		int m_zeroY; // column of current zero
		int * m_min; // minimal uncovered value in row
		int * m_ptr; // column of minimal uncovered value in row
		int * m_rowAdjust; // changes to be made to every row in matrix
		int * m_colAdjust; // changes to be made to every column in matrix
		void		SubtractMin(); // subtracts min from every row and column
		void		SetMask(); // sets m_mask for starred zeros in m_matrix
		bool		CountStarredZeros(); // counts starred zeros in m_matrix
		void		FindZero(); // searches for uncovered zero in m_matrix
		void		AugmentingPath(); // tries better combination of starred zeros
		// saves changes to m_matrix to m_rowAdjust and m_colAdjust
		void		AdjustValues();
		void		CalcMMin(); // calculating m_min
		// method is called if we find noncovered zero in method FindZero
		bool		FoundNoncovZero(int row, int col);
		bool		FindStarRow(int row, int & column); // finds starred zero in row
		bool		FindStarCol(int & row, int column); // finds starred zero in col
		void		FindPrimeRow(int row, int & column); // finds primed zero in row
		void		ClearIndex(); // clean attributes m_col and m_row
		// erases prime zeroes from mask and adjusts m_col based on starred zeros
		void		ErasePrimeAddCols();
		// switches starred and primed zeros from list starPrime from method AugmentingPath
		void 		SwitchZeros(list<pair<int,int>> & starPrime);
		//recalculates matrix using attributes m_rowAdjust and m_colAdjust
		void		Recalculate();
};


// Class solving assignment problem as network flow in bipartite weighted graph
class CBipartiteMatching : public CAssignment
{
	public:
					CBipartiteMatching(CInputAssignment * InAssign); // constructor
					~CBipartiteMatching(); // destructor
		// starts calculation, returns optimal matching
		void		Calculate(list <pair<int,int>> & resultIndexes);
	private:
		// recalibration of edges in m_graph so that all values are positive
		void		Recalibration(int *& distance,int from, int to);
		// updates current matching after finding augmenting path and changes orientation of edges from that path
		void		UpdateMatching(int *& matching, int *& parent,vector<Edge>::iterator * pointers);
		CGraph * m_graph; // bipartite graph + source and sink
};










#endif // CASSIGNMENT_H