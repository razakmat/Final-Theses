#ifndef CDCPP_H
#define CDCPP_H

#include <iostream>
#include <list>
#include "CPathFinding.h"
#include "CAssignment.h"
#include "CEuler.h"
#include "CGraph.h"
#include "CInputAssignment.h"

using namespace std;

// Enum class holding names for different sollution of specific problem
enum class Algorithm{Floyd = 1,Dijkstra = 2,Hungarian = 3,Bipartite = 4,Naive = 5};


// Class controling whole DCPP, calls individual classes
class CDCPP
{
	public:
							CDCPP			(CGraph * graph); // constuctor, creates deep copy of graph
							~CDCPP			(); // destructor
		void				Calculate		(list<int> & Euler,int & finalLength); // main calculation of DCPP
		void				SetAlgorithms	(const Algorithm path,const Algorithm assign); // sets which classes to use
		void				PrintResult		(list<int> & Euler) const; // prints final Eulerian cycle
	private:
		CInputAssignment *	Preparing		(int & sizeOfInAssign); // prepares structure going into assignment problem
		CPathFinding *		CalcPath		(CInputAssignment * InAssign); // calculates shortest paths
		// calculates assignment problem
		void				CalcAssignment	(CInputAssignment * InAssign, list<pair<int,int>> & indexes);
		// adds selected edges from assignment problem to graph
		void				AddingEdges		(list<pair<int,int>> & indexes,CPathFinding * path);
		CGraph * m_graph; // hold working graph
		Algorithm m_path; // which class is used for calculating shortest paths
		Algorithm m_assign; // which class is used for calculating assignment problem
};


#endif // CDCPP_H