#include "CGraph.h"

// constructor
CGraph::CGraph()
:m_totalWeight(0),m_Degree(NULL),m_Graph(NULL)
{
}

// deep copy constructor
CGraph::CGraph(const CGraph & x)
{
	if (x.m_Graph == NULL){
		m_totalWeight = 0;
		m_Degree = NULL;
		m_Graph = NULL;
	}
	m_Graph = NULL;
	SetNumVertex(x.m_numVertex);

	for (int i = 0; i < m_numVertex; i++)
	{
		m_Degree[i] = x.m_Degree[i];
		m_Graph[i] = x.m_Graph[i];
	}
	m_totalWeight = x.m_totalWeight;
}

// destructor
CGraph::~CGraph()
{
	DeleteTree();
}

// deletes graph
void CGraph::DeleteTree()
{
	if (m_Graph != NULL) 
	{
		delete [] m_Graph;
		delete [] m_Degree;
		m_Degree = NULL;
		m_Graph = NULL;
	}
}

// prints graph
void CGraph::PrintGraph(ostream & os) const
{
	os << m_numVertex << endl;
	for (int i = 0; i < m_numVertex; i++)
		for (auto & x : m_Graph[i])
			os << i << " " << x.name << " " << x.weight << endl;
}

// overloaded operator <<
ostream & operator << (ostream & os,const CGraph & x)
{
	x.PrintGraph(os);
	return os;
}

// sets number of vertices in graph
// and allocates neccesary memory
void CGraph::SetNumVertex(int vertices)
{
	DeleteTree();
	m_numVertex = vertices;
	m_Graph = new vector<Edge>[m_numVertex];
	// degree[i] = (outDegree(i) - inDegree(i))
	m_Degree= new int[m_numVertex];
	for (int i = 0 ; i < m_numVertex ; i++)
		m_Degree[i] = 0;
}

// returns array of degrees (outDegree - inDegree) of every vertices
int * CGraph::GetDegree() const
{
	return m_Degree;
}

// returns number of vertices in graph
int	CGraph::GetNumVertex() const
{
	return m_numVertex;
}

// return vector of edges of given vertex
vector<Edge> & CGraph::GetVertex(int vertex)
{
	return m_Graph[vertex];
}

// returns sum of weights of all edges
int CGraph::GetWeight() const
{
	return m_totalWeight;
}

// checks fails in input file containing graph
bool CGraph::FileCheck	(ifstream & file)
{
	if (file.fail()){
			cout << "False file" << endl;
			return false;
	}
	return true;
}

// adds edge into graph
void CGraph::AddEdge (int from, int to, int weight)
{
	Edge current;
	current.name=to;
	current.weight=weight;
	m_totalWeight += weight;
	m_Graph[from].push_back(current);

	m_Degree[from]++;
	m_Degree[to]--;
}

// Depth First Search (used in test for strong connectivity)
void CGraph::DFS(int vertex, vector<bool> & visited)
{
	visited[vertex] = true;
	for (auto & x : m_Graph[vertex])
	{
		if (visited[x.name] == false)
			DFS(x.name,visited);
	}
}

// creates graph with every edge inverted
CGraph * CGraph::GetTranspose()
{
	CGraph * graph = new CGraph();
	graph->SetNumVertex(m_numVertex);
	for (int i = 0; i < m_numVertex; i++)
	{
		for (auto & x : m_Graph[i])
		{
			graph->AddEdge(x.name,i,x.weight);
		}
	}
	return graph;
}

// checks strong connectivity in graph
bool CGraph::CheckStrongCon()
{
	vector<bool> visited(m_numVertex,false);

	// checks if every vertex in m_graph is reachable from vertex 0
	DFS(0,visited);
	for (int i = 0; i < m_numVertex; i++)
	{
		if (visited[i] == false)
			return false;
		visited[i] = false;
	}

	// creates graph from m_graph by inverting every edge
	CGraph * transpose = GetTranspose();

	// checks if every vertex in inverted graph is still reachable from vertex 0
	transpose->DFS(0,visited);
	delete transpose;

	for (int i = 0; i < m_numVertex; i++)
	{
		if (visited[i] == false)
			return false;
	}
	return true;
}

// creates new graph from file
bool CGraph::NewGraph(const char * name)
{
	DeleteTree();
	ifstream file;
	file.open( name );
	if ( !FileCheck(file) ) return false;

	int vertices;
	file >> vertices;
	if (vertices < 2)
		return false;
	// prepares m_graph with given number of vertices
	SetNumVertex(vertices);

	int from,to,weight;
	// adds edges from file to m_graph
	while (file >> from >> to >> weight)
	{
		if ( from < 0 || from >= vertices || to < 0 ||
			 to >= vertices || weight < 1)
			return false;
		AddEdge(from,to,weight);
	}

	// checks if m_graph is strongly connected
	if (!CheckStrongCon())
		return false;

	file.close();
	return true;
}