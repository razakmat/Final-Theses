#include "CDCPP.h"

// constuctor, creates deep copy of graph
// sets using classes CDijkstra and CHungarian, they can be changed in method SetAlgorithms 
CDCPP::CDCPP(CGraph * graph)
:m_path(Algorithm::Dijkstra),m_assign(Algorithm::Hungarian)
{
	m_graph = new CGraph(*graph);
}

// destructor
CDCPP::~CDCPP()
{
	delete m_graph;
}

// sets which subclasses are used in classes CPathFinding and CAssignment 
void CDCPP::SetAlgorithms(const Algorithm path,const Algorithm assign)
{
	m_path = path;
	m_assign = assign;
}

// prints final Eulerian cycle + it's length (sum of weights of edges in it)
void CDCPP::PrintResult(list<int> & Euler) const
{
	for (int x : Euler)
	{
		cout << x << " ";
	}
	cout << endl;
	cout << m_graph->GetWeight() << endl;
}

// prepares structure going into assignment problem
CInputAssignment * CDCPP::Preparing(int & sizeOfInAssign)
{
	CInputAssignment * InAssign = NULL;
	sizeOfInAssign = 0;
	int num_Vertex = m_graph->GetNumVertex();
	int * degree = m_graph->GetDegree();

	// calculates number of paths, we are looking for ( size of entry structure for assignment problem)
	for (int i = 0; i < num_Vertex; i++)
		if (degree[i] > 0)
			sizeOfInAssign += degree[i];

	// condition - make sure that m_graph is not already Eulerian
	if (sizeOfInAssign > 0)
	{
		// allocates instance of subclass based on, if we need
		// for assignment calculating matrix or bipartite graph as entry structure
		if (m_assign == Algorithm::Bipartite)
			// sizeOfInAssign - number of vertices in one partity * 2 of resulting bipartite graph
			InAssign = new CHoldNetwork(sizeOfInAssign * 2);
		else
			// sizeOfInAssign - size of resulting matrix (number of rows)
			InAssign = new CHoldMatrix(sizeOfInAssign);
	}
	return InAssign;
}

// calculates shortest paths
CPathFinding * CDCPP::CalcPath(CInputAssignment * InAssign)
{
	CPathFinding * path;

	// allocates instance of selected subclass
	if (m_path == Algorithm::Floyd)
		path = new CFloydWarshall(m_graph);
	else
		path = new CDijkstra(m_graph);

	path->Calculate(InAssign);

	return path;
}

// calculates assignment problem
void CDCPP::CalcAssignment(CInputAssignment * InAssign, list<pair<int,int>> & indexes)
{
	CAssignment * assign;

	// allocates instance of selected subclass
	if (m_assign == Algorithm::Hungarian)
		assign = new CHungarian(InAssign);
	else if (m_assign == Algorithm::Naive)
		assign = new CNaive(InAssign);
	else
		assign = new CBipartiteMatching(InAssign);

	assign->Calculate(indexes);

	delete assign;
}

// adds selected edges from assignment problem to graph
void CDCPP::AddingEdges(list<pair<int,int>> & indexes,CPathFinding * path)
{
	// going throught optimal matching from CAssingment
	for (auto & x : indexes)
	{
		int cost;
		list<int> vertices;
		// returns shortest path (which was calculated in CPathFinding) between two selected vertices (from list indexes)
		path->FindPathFromIndex(x.first,x.second,vertices,cost);

		// adding to m_graph all edges from current path 
		for (list<int>::const_iterator current = vertices.begin(); current != vertices.end(); ++current)
		{
			auto next = std::next(current);
			// cost is weight of whole path, so is added just once a path
			if ( *next == vertices.back())
			{
				m_graph->AddEdge(*current,*next,cost);
				break;
			}
			else
			{
				m_graph->AddEdge(*current,*next,0);
			}
		}
	}
}

// main calculation of DCPP
void CDCPP::Calculate(list<int> & Euler,int & finalLength)
{
	int sizeOfOddMatrix;
	// returns allocated InAssign, which holds 
	// Output (Input) structure for CPathFinding (CAssignment)
	// CHungarian,CNaive - matrix, CBipartiteMatching - bipartite graph
	CInputAssignment * InAssign = Preparing(sizeOfOddMatrix);

	// checks if given graph m_graph is not already Eulerian
	if (sizeOfOddMatrix > 0)
	{
		CPathFinding * path = CalcPath(InAssign);

		list<pair<int,int>> indexes;
		CalcAssignment(InAssign,indexes);

		delete InAssign;

		AddingEdges(indexes,path);

		delete path;
	}
	// here is m_graph always Eulerian
	// we can start Hierholzer algorithm
	CHierholzer Euler_Circ;
	Euler_Circ.Calculate(m_graph,Euler);

	finalLength = m_graph->GetWeight();

}