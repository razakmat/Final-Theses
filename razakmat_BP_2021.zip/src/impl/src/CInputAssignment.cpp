#include "CInputAssignment.h"

// constructor
CInputAssignment::CInputAssignment(int size)
:m_size(size)
{
	m_matrix = NULL;
	m_graph = NULL;
}

// destructor
CInputAssignment::~CInputAssignment()
{
}

// returns graph stored in m_graph
CGraph * CInputAssignment::GetNetwork()
{
	return m_graph;
}

// returns matrix stored in m_matrix
int **	CInputAssignment::GetMatrix()
{
	return m_matrix;
}

// returns value in m_size
int	CInputAssignment::GetSize()
{
	return m_size;
}

// constructor
// sizeofMatrix - number of rows in m_matrix
CHoldMatrix::CHoldMatrix(int sizeOfMatrix)
:CInputAssignment(sizeOfMatrix)
{
	m_matrix = new int*[m_size];
	for (int i = 0; i < m_size; i++)
		m_matrix[i] = new int[m_size];
}

// destructor
CHoldMatrix::~CHoldMatrix()
{
	for (int i = 0; i < m_size; i++)
		delete [] m_matrix[i];
	delete [] m_matrix;
}

// adds value to position in m_matrix 
void CHoldMatrix::AddElement(int i,int j,int weight)
{
	m_matrix[i][j] = weight;
}

// constructor
// numOfVertex - number of vertices in m_graph
// adds 2 to numOfVertex because of source and sink
CHoldNetwork::CHoldNetwork(int numOfVertex)
:CInputAssignment(numOfVertex + 2)
{
	m_graph = new CGraph();
	m_graph->SetNumVertex(numOfVertex + 2);
}

// destructor
CHoldNetwork::~CHoldNetwork()
{
	delete m_graph;
}

// adds edge to m_graph
void CHoldNetwork::AddElement(int i,int j,int weight)
{
	// i,j are coordinates in matrix, j has to be recalculated
	// to fit into network (bipartite graph + source,sink) m_graph
	// i - vertex in first partity, j - vertex in second partity
	m_graph->AddEdge(i,j + (m_size - 2)/2,weight);
}