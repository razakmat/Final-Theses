#include "CAssignment.h"

//constructor
CAssignment::CAssignment(int size)
:m_size(size)
{

}

// destructor
CAssignment::~CAssignment()
{

}

// constructor
CNaive::CNaive(CInputAssignment * InAssign)
:CAssignment(InAssign->GetSize()),m_bestScore(MAX)
{
	m_bestPairs = new int[m_size];
	m_matrix = InAssign->GetMatrix();
}

// destructor
CNaive::~CNaive()
{
	delete [] m_bestPairs;
}

// ending condition of recursion
bool CNaive::EndingCondition(int count, int * array,int k)
{
	int done = false;
	// no empty positions in int * array
	if (k == -1)
	{
		// current count is better than global best score
		if (count < m_bestScore)
		{
			for (int i = 0; i < m_size; i++)
				m_bestPairs[i] = array[i];
			m_bestScore = count;
		}
		done = true;
	}
	// current count is already worse than global best score
	if (count > m_bestScore)
		done = true;
	return done;
}

// creates array and fills it with values for next iteration
int * CNaive::CreateArray(int * array, int i, int k, int & pos)
{
	int * arr = new int[m_size];
    int l = 0;
    // copy array into arr
	// calculates int pos - i empty position in array
	for (int j = 0; j < m_size; j++){
           arr[j] = array[j];
           if (array[j] == -1 && l++ == i) pos = j;
	}
	// puts value of int k into pos position 
	arr[pos] = k;
	return arr;
}

// recursive method
void CNaive::Algorithm(int * array, int k, int count)
{
	// checks ending condition
	if (EndingCondition(count,array,k)){
		delete [] array;
		return;
	}

	int pos = 0;
	// every iteration puts value of k into different position (int pos) in int * arr
	// next recursion of Algorithm will be inserting value (k-1)
	for (int i = 0; i <= k; i++)
	{
		int * arr = CreateArray(array,i,k,pos);

		count += m_matrix[pos][k];
		Algorithm(arr,k-1,count);
		count -= m_matrix[pos][k];
	}
	delete [] array;
}

// starts calculation, returns optimal matching
void CNaive::Calculate(list <pair<int,int>> & resultIndexes)
{
	// current count
	int count = 0;
	int * array = new int[m_size];
	// creates array, -1 marks empty position
	for (int i = 0; i < m_size; i++)
		array[i] = -1;

	Algorithm(array,m_size-1,count);

	for (int i = 0; i < m_size; i++)
				resultIndexes.push_back(make_pair(i,m_bestPairs[i]));
}

// constructor
CHungarian::CHungarian(CInputAssignment * InAssign)
:CAssignment(InAssign->GetSize())
{
	// working matrix with values of shortest paths
	m_matrix = InAssign->GetMatrix();
	// indicates type of zeros
	m_mask = new int*[m_size];
	// indicates starred zero in column
	m_col = new int[m_size];
	// indicates starred zero in row
	m_row = new int[m_size];
	for (int i = 0; i < m_size; i++)
		m_mask[i] = new int[m_size];
	// minimum value in rows
	m_min = new int[m_size];
	// location of min value in rows
	m_ptr = new int[m_size];
	// adjustment to m_matrix in rows
	m_rowAdjust = new int[m_size];
	// adjustment to m_matrix in columns
	m_colAdjust = new int[m_size];
	for (int i = 0; i < m_size; i++)
	{
		m_rowAdjust[i] = 0;
		m_colAdjust[i] = 0;
	}
}

// destructor
CHungarian::~CHungarian()
{
	delete [] m_col;
	delete [] m_row;
	for (int i =0; i < m_size; i++)
		delete [] m_mask[i];
	delete [] m_mask;
	delete [] m_min;
	delete [] m_ptr;
	delete [] m_colAdjust;
	delete [] m_rowAdjust;
}

// starts calculation, returns optimal matching
void CHungarian::Calculate(list <pair<int,int>> & resultIndexes)
{
	// incialization
	for (int i = 0; i < m_size; i++){
		m_col[i] = 0;
		m_row[i] = 0;
	}
	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
			for (int j = 0; j < m_size; j++)
				m_mask[i][j] = 0;

	bool done;

	// subtracts min from every row and column
	SubtractMin();
	// sets m_mask for starred zeros in m_matrix
	SetMask();
	// checks if there are m_size starred zeros
	done = CountStarredZeros();

	// while cyklus till count of starred zeros equals m_size
	while (!done)
	{
		// searches for uncovered zero in m_matrix
		FindZero();
		done = CountStarredZeros();

	}
	// fills out output list resultIndexes with positions of starred zeros
	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
		for (int j = 0; j < m_size; j++)
			if (m_mask[i][j] == 1)
			{
				#pragma omp critical
				resultIndexes.push_back(make_pair(i,j));
			}
}

// subtracts min from every row and column
void CHungarian::SubtractMin()
{
	// subtracts min from every row
	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
	{
		int min = m_matrix[i][0];
		for (int j = 1; j < m_size; j++)
			if (m_matrix[i][j] < min)
				min = m_matrix[i][j];
		for (int j = 0; j < m_size; j++)
		{
			m_matrix[i][j] -= min;
		}
	}
	// subtracts min from every column
	#pragma omp parallel for
	for (int j = 0; j < m_size; j++)
	{
		int min = m_matrix[0][j];
		for (int i = 1; i < m_size; i++)
			if (m_matrix[i][j] < min)
				min = m_matrix[i][j];
		for (int i = 0; i < m_size; i++)
		{
			m_matrix[i][j] -= min;
		}
	}
}

// calculating m_min and m_ptr
void CHungarian::CalcMMin()
{
	// fills out attributes m_min and m_ptr with minimums of rows and their location
	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
	{
		m_min[i] = MAX;
		m_ptr[i] = -1;
		for (int j = 0; j < m_size; j++)
		{
			if (m_matrix[i][j] < m_min[i] && m_col[j] == 0)
			{
				m_min[i] = m_matrix[i][j];
				m_ptr[i] = j;
			}
		}
	}
}

// sets m_mask for starred zeros in m_matrix
void CHungarian::SetMask()
{
	// marks starred zeros in m_mask
	// checks if m_matrix[i][j] is zero and that there is no starred zero in the same column or row
	for (int i = 0; i < m_size; i++)
		for (int j = 0; j < m_size; j++)
		{
			if (m_matrix[i][j] == 0 && m_row[i] == 0 && m_col[j] == 0)
			{
				m_mask[i][j] = 1;
				m_row[i] = 1;
				m_col[j] = 1;
			} 
		}

	for (int i = 0; i < m_size; i++){
		m_row[i] = 0;
	}
	CalcMMin();
}

// counts starred zeros in m_matrix
bool CHungarian::CountStarredZeros()
{	
	// counts starred zeros (by going throught m_col) to check if algorithm is done
	int count = 0;
	for (int i = 0; i < m_size; i++)
		if (m_col[i] == 1)
			count++;
	if (count == m_size)
		return true;
	else
		return false;
}

// finds starred zero in row
bool CHungarian::FindStarRow(int row, int & column)
{
	for (int i = 0; i < m_size; i++)
		if (m_mask[row][i] == 1)
		{
			column = i;
			return true;
		}
	return false;
}

// method is called if we find noncovered zero in method FindZero
bool CHungarian::FoundNoncovZero(int row, int col)
{
	// primes zero at [row][col]
	m_mask[row][col] = 2;
	// searches for starred zero in the same row
	if (FindStarRow(row,col))
	{
		m_row[row] = 1;
		m_col[col] = 0;
		m_ptr[row] = -1;
		// recalculates m_min and m_ptr
		#pragma omp parallel for
		for (int i = 0; i < m_size; i++)
		{
			if (m_ptr[i] >= 0 && m_min[i] + m_rowAdjust[i] + m_colAdjust[m_ptr[i]] > 
								 m_matrix[i][col] + m_rowAdjust[i] + m_colAdjust[col])
			{
				m_min[i] = m_matrix[i][col];
				m_ptr[i] = col;
			}
		}
		return false;
	}
	else
	{
		m_zeroX = row;
		m_zeroY = col;
		return true;
	}
}

// searches for uncovered zero in m_matrix
void CHungarian::FindZero()
{
	bool done = false;
	bool found = false;
	int row = -1;
	int col = -1;

	// while till finds noncovered zero with no starred zero in same row
	while(!done)
	{
		for (int i = 0; i < m_size; i++)
		{
			if (m_ptr[i] >= 0 && m_min[i] + m_rowAdjust[i] + m_colAdjust[m_ptr[i]] == 0)
			{
				row = i;
				col = m_ptr[i];
				found = true;
				break;
			}
		}
		// found no noncover zero, so we have adjust values in m_matrix, which will produce noncovered zero
		if (found == false)
		{
			AdjustValues();
			row = -1;
			col = -1;
		}
		// found noncovered zero
		else
		{
			// have to check if there is starred zero in same row
			done = FoundNoncovZero(row,col);
			found = false;

			if (done)
				// exchanges starred zeros with primed zeros
				AugmentingPath();
		}
	}
}

// clean attributes m_col and m_row
void CHungarian::ClearIndex()
{
	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
	{
		m_row[i] = 0;
		m_col[i] = 0;
	}
}

// erases prime zeroes from mask and adjusts m_col based on starred zeros
void CHungarian::ErasePrimeAddCols()
{
	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
		for (int j = 0; j < m_size; j++)
		{
			if (m_mask[i][j] == 2)
				m_mask[i][j] = 0;
			else if (m_mask[i][j] == 1)
				m_col[j] = 1;
		}
}

// finds starred zero in column
bool CHungarian::FindStarCol(int & row, int column)
{
	for (int i = 0; i < m_size; i++)
		if (m_mask[i][column] == 1)
		{
			row = i;
			return true;
		}
	return false;
}

// finds primed zero in row
void CHungarian::FindPrimeRow(int row, int & column)
{
	for (int i = 0; i < m_size; i++)
		if (m_mask[row][i] == 2)
			column = i;
}

// switches starred and primed zeros from list starPrime from method AugmentingPath
void CHungarian::SwitchZeros(list<pair<int,int>> & starPrime)
{
	for (auto & x : starPrime)
	{
		if (m_mask[x.first][x.second] == 1)
		{
			m_mask[x.first][x.second] = 0;
		}
		else
		{
			m_mask[x.first][x.second] = 1;
			m_col[x.second] = 1;
		}
	}
}

//recalculates m_matrix using attributes m_rowAdjust and m_colAdjust
void CHungarian::Recalculate()
{
	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
		for (int j = 0; j < m_size; j++)
		{
			m_matrix[i][j] += m_rowAdjust[i] + m_colAdjust[j];
		}

	CalcMMin();

	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
	{
		m_rowAdjust[i] = 0;
		m_colAdjust[i] = 0;
	}
}

// tries better combination of starred zeros
void CHungarian::AugmentingPath()
{
	list<pair<int,int>> starPrime;
	starPrime.push_back(make_pair(m_zeroX,m_zeroY));
	bool done = false;
	int row;
	int column = 0;

	// fills list starPrime with starred and primed zeros
	while(!done)
	{
		if (FindStarCol(row,starPrime.back().second))
		{
			starPrime.push_back(make_pair(row,starPrime.back().second));
			FindPrimeRow(starPrime.back().first,column);
			starPrime.push_back(make_pair(starPrime.back().first,column));
		}
		else
			done = true;
	}
	// switches starred and primed zeros from list starPrime
	SwitchZeros(starPrime);
	ClearIndex();
	ErasePrimeAddCols();
	Recalculate();
}

// saves changes to m_matrix to m_rowAdjust and m_colAdjust
void CHungarian::AdjustValues()
{
	int minValue = MAX;

	for (int i = 0; i < m_size; i++)
	{
		if (m_ptr[i] >= 0 && m_min[i] + m_rowAdjust[i] + m_colAdjust[m_ptr[i]] < minValue)
			minValue = m_min[i] + m_rowAdjust[i] + m_colAdjust[m_ptr[i]];
	}
	#pragma omp parallel for
	for (int i = 0; i < m_size; i++)
	{
		if (m_row[i] == 1)
			m_rowAdjust[i] += minValue;
		if (m_col[i] == 0)
			m_colAdjust[i] -= minValue;
	}
}


// constructor
CBipartiteMatching::CBipartiteMatching(CInputAssignment * InAssign)
:CAssignment(InAssign->GetSize())
{
	m_graph = InAssign->GetNetwork();

	// adds edges from source and to sink
	for (int i = 0; i < (m_size - 2)/2; i++)
	{
		m_graph->AddEdge(m_size - 2,i,0);
		m_graph->AddEdge(i + (m_size - 2)/2,m_size - 1,0);
	}
}

// destructor
CBipartiteMatching::~CBipartiteMatching()
{
}

// recalibration of edges in m_graph (from (int from ) vertex to (int to) vertex) so that all values are positive
// int * distance - distances calculated in Dijkstra algorithm
void CBipartiteMatching::Recalibration(int *& distance,int from, int to)
{
	#pragma omp parallel for
	for (int i = from; i < to; i++)
	{
		vector<Edge> & edges = m_graph->GetVertex(i);
		for (auto & x : edges)
		{
			x.weight += distance[i] - distance[x.name];
		}
	}
}

// updates current matching after finding augmenting path and changes orientation of edges from that path
// int * matching - current matching
// int * parent - predecessors in shortest paths
// vector pointers - pointers to edges used in shortest paths
void CBipartiteMatching::UpdateMatching(int *& matching, int *& parent,vector<Edge>::iterator * pointers)
{
	int index = m_size - 1;

	// while till parent[index] is source (start vertex)
	while (parent[index] != -1)
	{
		vector<Edge> & edges = m_graph->GetVertex(parent[index]);
		pointers[index]->name = edges.back().name;
		pointers[index]->weight = edges.back().weight;
		// deletes edge from shortest path from m_graph
		edges.pop_back();

		// if edge is not from source or to sink inserts edge with opposite orientation with weight 0
		if (index != m_size - 1 && parent[index] != m_size - 2)
		{
			m_graph->AddEdge(index,parent[index],0);
		}

		// updates matching - updates edge in matching going from second partity to first
		if (parent[index] < (m_size - 2)/2)
		{
			matching[parent[index]] = index - (m_size - 2)/2;
		}

		index = parent[index];
	}
}

// starts calculation, returns optimal matching
void CBipartiteMatching::Calculate(list <pair<int,int>> & resultIndexes)
{
	// shortest distances
	int * distance = new int[m_size];
	// predecessors in shortest path
	int * parent = new int[m_size];
	// matching size of one partity
	int * matching = new int[(m_size - 2)/2];
	// algorithm needs shortest distances for every vertex (Recalibration)
	bool * endVertices = new bool[m_size];
	for (int i = 0; i < m_size; i++)
		endVertices[i] = true;

	Dijkstra * Calc = new Dijkstra(m_graph);

	for (int k = 0; k < (m_size - 2)/2; k++)
	{
		// calculates shortest distances using Dijkstra algorithm
		Calc->Calculate(distance,parent,m_size-2,endVertices,m_size);

		// recalibrates weights of edges in m_graph (no negative weights)
		// split in two for paralelism (difference in number of edges from first and second partity)
		Recalibration(distance,0,(m_size - 2)/2);
		Recalibration(distance,(m_size - 2)/2,m_size - 2);

		// updates matching and changes orientation of used edges
		UpdateMatching(matching,parent,Calc->GetPointers());
	}

	delete Calc;

	for (int i = 0; i < (m_size - 2)/2; i++)
		resultIndexes.push_back(make_pair(i,matching[i]));

	delete [] endVertices;
	delete [] distance;
	delete [] parent;
	delete [] matching;
}









