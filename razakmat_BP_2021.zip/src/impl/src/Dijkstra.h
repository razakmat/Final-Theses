#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include <list>
#include <stack>
#include <vector>
#include <omp.h>
#include <boost/heap/fibonacci_heap.hpp>
#include "CGraph.h"


using namespace std;


// class holding Dijkstra algorithm for finding shortest paths from given vertex
class Dijkstra
{
	public:
									Dijkstra		(CGraph * graph); // constructor
									~Dijkstra		(); // destructor
		vector<Edge>::iterator *	GetPointers		(); // returns attribut m_iterators
		// Dijkstra algorithm with use of fibonacciho_heap
		void						Calculate		(int *& distance,int *& parent,int start,bool * endVertices,int cntEnd);
		// struct compare for fibonacciho_heap
		struct CompareMin
		{
    		bool operator()				(const pair<int,int> & a, const pair<int,int> & b) const
    		{
        		return a.first > b.first;
    		}
		};
	protected:
		const int MAX = numeric_limits<int>::max(); // max integer
		CGraph * m_graph; // graph
		// pointers to edges, which are used in calculated shortest paths, corresponds to array parent
		// it is used in class CBipartiteMatching
		vector<Edge>::iterator * m_iterators; 
};

#endif // DIJKSTRA_H