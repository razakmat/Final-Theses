#ifndef CGRAPH_H
#define CGRAPH_H

#include <fstream>
#include <iostream>
#include <list>
#include <vector>

using namespace std;

// Struct holding information about edge
struct Edge{
    int name;
    int weight;
};

// Class holding information about graph
class CGraph
{
	public:
						CGraph			(); // constructor
						CGraph			(const CGraph & x); // deep copy constructor
						~CGraph			(); // destructor
		bool			NewGraph		(const char * name); // creates new graph from file
		void			SetNumVertex	(int vertices); // sets number of vertices in graph
		int *			GetDegree		() const; // returns array of degrees (outDegree - inDegree) of vertices
		int				GetNumVertex	() const; // returns number of vertices in graph
		vector<Edge> &	GetVertex		(int vertex); // return vector of edges of given vertex
		int 			GetWeight		() const; // returns sum of weights of all edges
		void			AddEdge			(int from, int to, int weight); // adds edge into graph
		void			PrintGraph		(ostream & os) const; // prints graph
		friend ostream & operator << 	(ostream & os,const CGraph & x); // operator <<
	private:
		int m_numVertex; // number of vertices
		int m_totalWeight; // total weight of graph
		int * m_Degree; // array of degrees (outDegree - inDegree) of all vertices
		vector<Edge> * m_Graph; // holds all edges as array of vectors
		// Depth First Search (used in test for strong connectivity)
		void 			DFS				(int vertex, vector<bool> & visited); 
		CGraph *		GetTranspose	(); // creates graph with every edge inverted
		bool			CheckStrongCon	(); // checks strong connectivity in graph
		bool			FileCheck		(ifstream & file); // checks fails in input file containing graph
		void			DeleteTree		(); // deletes graph

};


#endif // CGRAPH_H